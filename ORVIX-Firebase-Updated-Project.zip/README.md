# ORVIX — Free Web Hosting & Website Marketplace Platform

> **Build • Host • Grow**

ORVIX is a full-stack, responsive web hosting and website marketplace platform built for creators, businesses, and developers.

---

## 🌟 Core Platform Features

### 1. Free Static Website Hosting
- **Upload Supported**: Single HTML files or ZIP archives (Max 5 MB).
- **Subdomains**: Automatic instant subdomain allocation (`yourname.orvix`).
- **Real-Time Deployment**: Pipeline with upload validation, malicious file filtering (blocks `.php`, `.exe`, `.sh`, etc.), and edge publishing.
- **Same-URL Updates**: Upload new code anytime; the public URL remains unchanged.
- **Instant Rollback**: Revert to earlier versions (v1, v2) with one click without altering the URL.
- **Custom Domains**: Configure external domains with DNS records (CNAME `@ orvix.network` and A Record `199.36.158.100`).
- **Interactive Live Preview**: Built-in responsive device switcher (Desktop, Tablet, Mobile) and standalone tab launcher.

### 2. Website & App Marketplace
- 10+ Categories: Business Websites, Portfolios, E-commerce, SaaS Web Apps, Android App Conversion Services, and Custom Development.
- BDT (৳) Pricing, feature lists, technology tags, live demo previews, and instant ordering.

### 3. bKash Manual Payment System
- **Provider**: bKash Personal ("Send Money")
- **Account Number**: `01344495081`
- **Workflow**:
  1. Customer sends money to `01344495081` with Order ID as reference.
  2. Customer submits sender bKash number and Transaction ID (TrxID).
  3. Status updates to `Submitted for Verification`.
  4. Platform Admin reviews the transaction in the Admin Panel and Approves or Rejects with verification remarks.
  5. Upon approval, deliverable download links are instantly unlocked.

### 4. Custom Website & App Engineering
- Form for requesting tailor-made websites or Android APK conversions.
- Generates unique Order IDs, trackable in customer and admin dashboards.

### 5. Multi-Language & Modern Theming
- **Languages**: Bengali (`বাংলা` - Default) and English (`EN`) with full translation dictionary.
- **Themes**: Deep futuristic dark mode (`#070b14` with cyan and purple neon glow) and crisp light mode.
- **Mobile First**: Fixed 5-tab mobile bottom navigation (Home, Host Site, Orders, Profile, Support).

### 6. Administration Control Center
- Restricted to Super Admin (`businessforworld678@gmail.com`).
- Metrics overview (Users, projects, storage, pending verifications).
- Project moderation and live previews.
- bKash transaction approvals and rejections with audit logs.
- Support ticket reply system.

---

## 🚀 Quick Evaluation & Demo Accounts

The platform includes convenient demo shortcuts in the User dropdown and Login modal:
- **Admin**: `businessforworld678@gmail.com` (Full system access & bKash approvals)
- **User**: `creator@orvix.io` (Standard hosting & customer purchases)

---

## 📞 Support Channels
- **WhatsApp**: `01344495081`
- **Email**: `businessforworld678@gmail.com`
- **Telegram**: `https://t.me/jubayerahamed8`


---

## Firebase setup (updated)

1. In Firebase Console, open project `orvix-6198e` (or your own project).
2. Authentication → Sign-in method: enable **Email/Password** and **Google**.
3. Authentication → Settings → Authorized domains: add the domain where you deploy ORVIX.
4. Firestore Database → Create database, then paste `firestore.rules` into the Rules tab and publish.
5. Create `.env.local` from `.env.example`; set the `VITE_FIREBASE_*` values from Project settings → Your apps → Web app.
6. Install and run:
   - `npm install`
   - `npm run dev`

### Admin role (important)

The frontend never grants admin access based on a typed email or a client-editable Firestore field. Set the Firebase Authentication custom claim `admin: true` for your own UID using a trusted server with Firebase Admin SDK. Never put a Firebase Admin service-account key in frontend code or in this ZIP. After the claim is set, sign out and back in (or refresh the ID token).

### Integration scope

Firebase Email/Password registration, login, Google sign-in, password reset, user profile sync, ID-token state, and custom-claim-based admin detection are integrated in the frontend. The existing hosting/order/payment API routes in `server.ts` were originally built around the project's legacy server-side auth and JSON database; they still need a backend migration to verify Firebase ID tokens and persist those features in Firestore before those operations can be considered Firebase-backed. Do not deploy with legacy demo-login shortcuts or treat frontend checks as security.
