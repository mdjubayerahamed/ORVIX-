import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';
import { db, HostingProject, DeploymentRecord } from './db.js';

const SITES_DIR = path.resolve(process.cwd(), 'data/sites');

export function ensureSitesDir() {
  if (!fs.existsSync(SITES_DIR)) {
    fs.mkdirSync(SITES_DIR, { recursive: true });
  }
}

// Block executable and dangerous server scripts
const FORBIDDEN_EXTENSIONS = [
  '.php', '.phtml', '.php3', '.php4', '.php5', '.phps',
  '.exe', '.sh', '.bash', '.bat', '.cmd', '.com', '.msi',
  '.cgi', '.pl', '.py', '.rb', '.jsp', '.asp', '.aspx',
  '.vbs', '.ps1', '.jar', '.env'
];

export interface FileItem {
  path: string;
  content: string; // text or base64
  isBase64?: boolean;
}

export interface DeploymentInput {
  projectId?: string;
  projectName: string;
  slug: string;
  userId: string;
  userEmail: string;
  files: FileItem[];
  notes?: string;
}

// MIME types lookup
export const MIME_TYPES: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.eot': 'application/vnd.ms-fontobject',
  '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml; charset=utf-8',
};

// Seed initial demo sites if not present
export function seedDefaultHostingProjects() {
  ensureSitesDir();

  const currentDb = db.get();
  if (currentDb.hostingProjects.length > 0) return;

  const demoSites = [
    {
      name: 'DevNova Portfolio',
      slug: 'devnova-portfolio',
      desc: 'Modern Developer & Designer Portfolio with dynamic projects grid and glowing tech badges.',
      html: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DevNova — Senior Frontend Architect</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    @keyframes pulseGlow { 0%, 100% { opacity: 0.4; } 50% { opacity: 0.8; } }
    .glow-cyan { text-shadow: 0 0 20px rgba(6,182,212,0.8); }
    .glow-bg { animation: pulseGlow 4s infinite ease-in-out; }
  </style>
</head>
<body class="bg-[#090d16] text-slate-100 min-h-screen font-sans selection:bg-cyan-500 selection:text-black">
  <div class="fixed inset-0 pointer-events-none overflow-hidden">
    <div class="absolute -top-40 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl glow-bg"></div>
    <div class="absolute bottom-10 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl glow-bg"></div>
  </div>

  <div class="max-w-4xl mx-auto px-6 py-16 relative z-10">
    <header class="flex justify-between items-center border-b border-slate-800/80 pb-6 mb-12">
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-400 to-purple-600 flex items-center justify-center font-bold text-white shadow-lg shadow-cyan-500/20">
          DN
        </div>
        <span class="text-xl font-bold tracking-tight bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent">DevNova</span>
      </div>
      <div class="flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-xs font-medium text-cyan-300">
        <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
        Hosted on ORVIX Free Cloud
      </div>
    </header>

    <main class="space-y-16">
      <section class="space-y-6">
        <div class="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-purple-500/10 border border-purple-500/30 text-purple-300 text-xs font-semibold uppercase tracking-wider">
          Available for Freelance & Custom Web
        </div>
        <h1 class="text-4xl sm:text-6xl font-extrabold tracking-tight leading-tight">
          Crafting high-octane web apps that <span class="bg-gradient-to-r from-cyan-400 via-sky-300 to-purple-400 bg-clip-text text-transparent">scale to millions</span>.
        </h1>
        <p class="text-lg text-slate-400 max-w-2xl leading-relaxed">
          I specialize in building lightning-fast reactive web experiences, clean API integrations, and aesthetic SaaS user interfaces with Tailwind CSS and React.
        </p>
        <div class="flex flex-wrap gap-4 pt-2">
          <a href="#projects" class="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold hover:brightness-110 shadow-lg shadow-cyan-500/25 transition">View Case Studies</a>
          <a href="mailto:businessforworld678@gmail.com" class="px-6 py-3 rounded-xl border border-slate-700 bg-slate-900/60 hover:bg-slate-800 text-white font-medium transition">Get In Touch</a>
        </div>
      </section>

      <section id="projects" class="space-y-8">
        <h2 class="text-2xl font-bold border-l-4 border-cyan-400 pl-3">Featured Deployments</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div class="p-6 rounded-2xl bg-slate-900/40 border border-slate-800 hover:border-cyan-500/50 transition group">
            <span class="text-xs font-mono text-cyan-400">FINTECH • 2026</span>
            <h3 class="text-xl font-bold mt-2 text-white group-hover:text-cyan-300 transition">PayFlow Dashboard</h3>
            <p class="text-slate-400 text-sm mt-2 leading-relaxed">Real-time payment analytics for bKash merchants with transaction verification charts.</p>
          </div>
          <div class="p-6 rounded-2xl bg-slate-900/40 border border-slate-800 hover:border-purple-500/50 transition group">
            <span class="text-xs font-mono text-purple-400">E-COMMERCE • 2026</span>
            <h3 class="text-xl font-bold mt-2 text-white group-hover:text-purple-300 transition">Aura Commerce</h3>
            <p class="text-slate-400 text-sm mt-2 leading-relaxed">Headless store with zero layout shift, sub-second page loads, and mobile drawer cart.</p>
          </div>
        </div>
      </section>

      <footer class="pt-12 border-t border-slate-800/80 flex flex-col sm:flex-row justify-between items-center text-slate-500 text-sm gap-4">
        <p>© 2026 DevNova. Hosted with ⚡ on ORVIX.</p>
        <div class="flex gap-4">
          <a href="#" class="hover:text-cyan-400 transition">GitHub</a>
          <a href="#" class="hover:text-cyan-400 transition">Twitter</a>
          <a href="#" class="hover:text-cyan-400 transition">LinkedIn</a>
        </div>
      </footer>
    </main>
  </div>
</body>
</html>`
    },
    {
      name: 'CyberPulse Agency',
      slug: 'cyberpulse-agency',
      desc: 'High-tech creative digital agency showcase with dark neon styling and interactive service breakdown.',
      html: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CyberPulse — Digital Product Studio</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#050811] text-slate-200 min-h-screen">
  <nav class="border-b border-slate-800/80 backdrop-blur-md sticky top-0 z-50 bg-[#050811]/90">
    <div class="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
      <div class="flex items-center gap-2 text-cyan-400 font-extrabold text-xl tracking-wider">
        CYBER<span class="text-purple-400">PULSE</span>
      </div>
      <div class="flex items-center gap-4 text-sm">
        <span class="text-slate-400">Build • Host • Grow</span>
        <a href="#services" class="px-4 py-1.5 rounded-lg bg-cyan-500 text-slate-950 font-semibold hover:bg-cyan-400 transition">Services</a>
      </div>
    </div>
  </nav>

  <header class="max-w-6xl mx-auto px-6 py-20 text-center space-y-6">
    <span class="px-3 py-1 rounded-full text-xs font-semibold bg-cyan-950/60 border border-cyan-800/60 text-cyan-300">
      PREMIUM WEB ARCHITECTURE & SOFTWARE
    </span>
    <h1 class="text-4xl sm:text-7xl font-black tracking-tight text-white max-w-4xl mx-auto">
      We build brands that define tomorrow.
    </h1>
    <p class="text-slate-400 max-w-2xl mx-auto text-lg leading-relaxed">
      From custom responsive websites to native Android apps and high-conversion e-commerce engines in Bangladesh.
    </p>
  </header>

  <section id="services" class="max-w-6xl mx-auto px-6 pb-24">
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div class="p-8 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-cyan-500/40 transition">
        <div class="w-12 h-12 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center font-bold text-xl mb-4">01</div>
        <h3 class="text-xl font-bold text-white mb-2">Web Development</h3>
        <p class="text-slate-400 text-sm leading-relaxed">Static & dynamic web platforms deployed with CDN speed and custom subdomains.</p>
      </div>
      <div class="p-8 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-purple-500/40 transition">
        <div class="w-12 h-12 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center font-bold text-xl mb-4">02</div>
        <h3 class="text-xl font-bold text-white mb-2">bKash Integration</h3>
        <p class="text-slate-400 text-sm leading-relaxed">Seamless merchant checkout, invoice generation, and real-time transaction verification.</p>
      </div>
      <div class="p-8 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-pink-500/40 transition">
        <div class="w-12 h-12 rounded-xl bg-pink-500/10 text-pink-400 flex items-center justify-center font-bold text-xl mb-4">03</div>
        <h3 class="text-xl font-bold text-white mb-2">Android Applications</h3>
        <p class="text-slate-400 text-sm leading-relaxed">Native APK conversion with push notifications, offline support, and Play Store readiness.</p>
      </div>
    </div>
  </section>

  <footer class="border-t border-slate-800/80 py-8 text-center text-xs text-slate-500">
    Powered by ORVIX Platform Cloud Engine • Free Static Hosting Infrastructure
  </footer>
</body>
</html>`
    }
  ];

  db.update(draft => {
    for (const site of demoSites) {
      const sitePath = path.resolve(SITES_DIR, site.slug, 'current');
      const v1Path = path.resolve(SITES_DIR, site.slug, 'v1');
      fs.mkdirSync(sitePath, { recursive: true });
      fs.mkdirSync(v1Path, { recursive: true });

      fs.writeFileSync(path.resolve(sitePath, 'index.html'), site.html, 'utf-8');
      fs.writeFileSync(path.resolve(v1Path, 'index.html'), site.html, 'utf-8');

      const sizeBytes = Buffer.byteLength(site.html, 'utf-8');
      const depRecord: DeploymentRecord = {
        id: `dep_${site.slug}_1`,
        projectId: `proj_${site.slug}`,
        version: 1,
        status: 'Published',
        fileCount: 1,
        totalSizeBytes: sizeBytes,
        deployedAt: new Date().toISOString(),
        notes: 'Initial production launch',
      };

      const project: HostingProject = {
        id: `proj_${site.slug}`,
        userId: 'usr_admin_01',
        userEmail: 'businessforworld678@gmail.com',
        name: site.name,
        slug: site.slug,
        subdomain: `${site.slug}.orvix`,
        status: 'Published',
        currentVersion: 1,
        totalSizeBytes: sizeBytes,
        fileCount: 1,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        deployments: [depRecord],
        publicUrl: `/sites/${site.slug}/`,
      };

      draft.hostingProjects.push(project);
    }
  });
}

// Deploy files to a project
export async function deployProjectFiles(input: DeploymentInput): Promise<{
  success: boolean;
  project?: HostingProject;
  error?: string;
}> {
  ensureSitesDir();

  // Validate slug
  const cleanSlug = input.slug.toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
  if (!cleanSlug || cleanSlug.length < 3) {
    return { success: false, error: 'Subdomain/slug must be at least 3 characters long and alphanumeric.' };
  }

  // Check reserved slugs
  const RESERVED_SLUGS = ['api', 'admin', 'auth', 'sites', 'dashboard', 'static', 'assets', 'system', 'root'];
  if (RESERVED_SLUGS.includes(cleanSlug)) {
    return { success: false, error: `The name "${cleanSlug}" is reserved by the platform.` };
  }

  // Unlimited Storage Mode - No 5MB restriction
  let totalBytes = 0;

  // Validate files and structure - strictly HTML based
  let hasIndexHtml = false;
  const processedFiles: Array<{ relPath: string; buffer: Buffer }> = [];

  for (const file of input.files) {
    // Sanitize path to prevent traversal
    const normalizedPath = path.normalize(file.path).replace(/^(\.\.(\/|\\|$))+/, '').replace(/^[/\\]+/, '');
    if (normalizedPath.includes('..') || path.isAbsolute(file.path)) {
      return { success: false, error: 'Path traversal is strictly prohibited.' };
    }

    // Check extension
    const ext = path.extname(normalizedPath).toLowerCase();
    if (FORBIDDEN_EXTENSIONS.includes(ext)) {
      return { success: false, error: `Forbidden file detected: ${normalizedPath} (${ext})` };
    }

    if (normalizedPath.toLowerCase() === 'index.html' || normalizedPath.toLowerCase().endsWith('/index.html') || ext === '.html' || ext === '.htm') {
      hasIndexHtml = true;
    }

    let buf: Buffer;
    if (file.isBase64) {
      buf = Buffer.from(file.content, 'base64');
    } else {
      buf = Buffer.from(file.content, 'utf-8');
    }

    totalBytes += buf.length;
    processedFiles.push({ relPath: normalizedPath, buffer: buf });
  }

  if (!hasIndexHtml) {
    return {
      success: false,
      error: 'Upload package must include an "index.html" file at the root or main entry.'
    };
  }

  // Find or create project in DB
  const currentDb = db.get();
  let existingProject = currentDb.hostingProjects.find(p => p.slug === cleanSlug);

  if (existingProject && existingProject.userId !== input.userId && input.userEmail !== 'businessforworld678@gmail.com') {
    return { success: false, error: `The subdomain "${cleanSlug}.orvix" is already taken by another creator.` };
  }

  const nextVersion = existingProject ? existingProject.currentVersion + 1 : 1;
  const projectDir = path.resolve(SITES_DIR, cleanSlug);
  const versionDir = path.resolve(projectDir, `v${nextVersion}`);
  const currentDir = path.resolve(projectDir, 'current');

  try {
    fs.mkdirSync(versionDir, { recursive: true });

    // Write all files into version directory
    for (const item of processedFiles) {
      const destFile = path.resolve(versionDir, item.relPath);
      const destDir = path.dirname(destFile);
      if (!fs.existsSync(destDir)) {
        fs.mkdirSync(destDir, { recursive: true });
      }
      fs.writeFileSync(destFile, item.buffer);
    }

    // Update 'current' directory atomically: clear and copy versionDir contents
    if (fs.existsSync(currentDir)) {
      fs.rmSync(currentDir, { recursive: true, force: true });
    }
    fs.mkdirSync(currentDir, { recursive: true });

    // Copy files from version to current
    for (const item of processedFiles) {
      const destFile = path.resolve(currentDir, item.relPath);
      const destDir = path.dirname(destFile);
      if (!fs.existsSync(destDir)) {
        fs.mkdirSync(destDir, { recursive: true });
      }
      fs.writeFileSync(destFile, item.buffer);
    }

    const deploymentRecord: DeploymentRecord = {
      id: `dep_${Date.now()}_v${nextVersion}`,
      projectId: existingProject ? existingProject.id : `proj_${Date.now()}`,
      version: nextVersion,
      status: 'Published',
      fileCount: processedFiles.length,
      totalSizeBytes: totalBytes,
      deployedAt: new Date().toISOString(),
      notes: input.notes || (nextVersion === 1 ? 'Initial launch' : `Updated deployment v${nextVersion}`),
      log: `Successfully verified and deployed ${processedFiles.length} static assets with zero errors.`,
    };

    let targetProject: HostingProject;

    db.update(draft => {
      if (existingProject) {
        const found = draft.hostingProjects.find(p => p.id === existingProject!.id);
        if (found) {
          found.name = input.projectName || found.name;
          found.status = 'Published';
          found.currentVersion = nextVersion;
          found.totalSizeBytes = totalBytes;
          found.fileCount = processedFiles.length;
          found.updatedAt = new Date().toISOString();
          found.deployments.unshift(deploymentRecord);
          targetProject = found;
        } else {
          targetProject = existingProject!;
        }
      } else {
        const newProj: HostingProject = {
          id: `proj_${Date.now()}`,
          userId: input.userId,
          userEmail: input.userEmail,
          name: input.projectName || cleanSlug,
          slug: cleanSlug,
          subdomain: `${cleanSlug}.orvix`,
          status: 'Published',
          currentVersion: 1,
          totalSizeBytes: totalBytes,
          fileCount: processedFiles.length,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          deployments: [deploymentRecord],
          publicUrl: `/sites/${cleanSlug}/`,
        };
        draft.hostingProjects.unshift(newProj);
        targetProject = newProj;
      }

      // Add in-app notification
      draft.notifications.unshift({
        id: `notif_${Date.now()}`,
        userId: input.userId,
        title: 'Deployment Successful!',
        titleBn: 'সাইট সফলভাবে হোস্ট করা হয়েছে!',
        message: `Your site "${targetProject.name}" is now live at ${targetProject.subdomain}.`,
        messageBn: `আপনার সাইট "${targetProject.name}" এখন ${targetProject.subdomain}-এ লাইভ আছে।`,
        type: 'success',
        link: targetProject.publicUrl,
        isRead: false,
        createdAt: new Date().toISOString(),
      });
    });

    return { success: true, project: targetProject! };
  } catch (err: any) {
    console.error('Deployment error:', err);
    return { success: false, error: err?.message || 'Failed to extract and publish static files.' };
  }
}

// Roll back project to an earlier deployment version
export async function rollbackProject(projectId: string, targetVersion: number, userId: string, isAdmin: boolean): Promise<{ success: boolean; error?: string }> {
  const currentDb = db.get();
  const proj = currentDb.hostingProjects.find(p => p.id === projectId);
  if (!proj) return { success: false, error: 'Project not found.' };

  if (proj.userId !== userId && !isAdmin) {
    return { success: false, error: 'Permission denied.' };
  }

  const versionDir = path.resolve(SITES_DIR, proj.slug, `v${targetVersion}`);
  if (!fs.existsSync(versionDir)) {
    return { success: false, error: `Version v${targetVersion} files do not exist on disk.` };
  }

  const currentDir = path.resolve(SITES_DIR, proj.slug, 'current');

  try {
    // Copy target version files to current
    if (fs.existsSync(currentDir)) {
      fs.rmSync(currentDir, { recursive: true, force: true });
    }
    fs.cpSync(versionDir, currentDir, { recursive: true });

    db.update(draft => {
      const found = draft.hostingProjects.find(p => p.id === projectId);
      if (found) {
        found.currentVersion = targetVersion;
        found.updatedAt = new Date().toISOString();
        found.deployments.unshift({
          id: `dep_rb_${Date.now()}`,
          projectId: found.id,
          version: targetVersion,
          status: 'Published',
          fileCount: found.fileCount,
          totalSizeBytes: found.totalSizeBytes,
          deployedAt: new Date().toISOString(),
          notes: `Rolled back to version v${targetVersion}`,
        });
      }
    });

    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

// Unpack ZIP archive buffer
export async function unpackZipArchive(buffer: Buffer): Promise<FileItem[]> {
  const zip = await JSZip.loadAsync(buffer);
  const files: FileItem[] = [];

  for (const [relativePath, zipEntry] of Object.entries(zip.files)) {
    if (zipEntry.dir) continue;
    // Skip OS junk like __MACOSX, .DS_Store
    if (relativePath.includes('__MACOSX') || relativePath.includes('.DS_Store')) continue;

    const contentBuffer = await zipEntry.async('nodebuffer');
    const ext = path.extname(relativePath).toLowerCase();
    const isText = ['.html', '.htm', '.css', '.js', '.mjs', '.json', '.svg', '.txt', '.xml'].includes(ext);

    if (isText) {
      files.push({
        path: relativePath,
        content: contentBuffer.toString('utf-8'),
        isBase64: false,
      });
    } else {
      files.push({
        path: relativePath,
        content: contentBuffer.toString('base64'),
        isBase64: true,
      });
    }
  }

  return files;
}
