import fs from 'fs';
import path from 'path';

export interface User {
  id: string;
  email: string;
  displayName: string;
  role: 'admin' | 'user';
  status: 'active' | 'suspended';
  avatarUrl: string;
  createdAt: string;
  quotaMB: number;
  usedStorageBytes: number;
  language: 'bn' | 'en';
  theme: 'dark' | 'light';
  passwordHash?: string;
  isVerified: boolean;
}

export interface DeploymentRecord {
  id: string;
  projectId: string;
  version: number;
  status: 'Building' | 'Published' | 'Failed';
  fileCount: number;
  totalSizeBytes: number;
  deployedAt: string;
  notes?: string;
  log?: string;
}

export interface HostingProject {
  id: string;
  userId: string;
  userEmail: string;
  name: string;
  slug: string;
  subdomain: string;
  status: 'Published' | 'Building' | 'Failed' | 'Draft' | 'Suspended';
  currentVersion: number;
  totalSizeBytes: number;
  fileCount: number;
  customDomain?: string;
  customDomainVerified?: boolean;
  createdAt: string;
  updatedAt: string;
  deployments: DeploymentRecord[];
  publicUrl: string;
}

export interface MarketplaceProduct {
  id: string;
  title: string;
  titleBn: string;
  category: string;
  priceBdt: number;
  shortDesc: string;
  shortDescBn: string;
  fullDesc: string;
  fullDescBn: string;
  features: string[];
  featuresBn: string[];
  techStack: string[];
  demoUrl?: string;
  deliveryTime: string;
  deliveryTimeBn: string;
  imageUrl: string;
  isPublished: boolean;
  downloadUrl?: string;
  createdAt: string;
}

export interface CustomWebsiteRequest {
  id: string;
  orderId: string;
  userId: string;
  customerName: string;
  email: string;
  whatsapp?: string;
  siteType: string;
  features: string;
  designPreferences: string;
  referenceUrl?: string;
  budgetBdt: number;
  preferredDeadline: string;
  additionalInstructions?: string;
  status: 'Requested' | 'Quotation Sent' | 'Awaiting Payment' | 'In Progress' | 'Waiting for Customer' | 'Delivered' | 'Completed' | 'Cancelled' | 'Refunded';
  quotationAmountBdt?: number;
  adminNotes?: string;
  deliverableLink?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Order {
  id: string;
  orderId: string;
  userId: string;
  userEmail: string;
  productId?: string;
  productTitle: string;
  orderType: 'marketplace' | 'custom_service';
  amountBdt: number;
  paymentStatus: 'Awaiting Payment' | 'Submitted for Verification' | 'Verified' | 'Rejected' | 'Refunded';
  fulfillmentStatus: 'Pending' | 'In Progress' | 'Delivered' | 'Completed' | 'Cancelled';
  bKashTxId?: string;
  bKashSenderNumber?: string;
  paymentSubmittedAt?: string;
  adminVerificationNotes?: string;
  deliverableLink?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PaymentSubmission {
  id: string;
  orderId: string;
  userId: string;
  userEmail: string;
  amountBdt: number;
  senderNumber: string;
  transactionId: string;
  submittedAt: string;
  status: 'Submitted for Verification' | 'Verified' | 'Rejected';
  notes?: string;
  verifiedAt?: string;
  verifiedBy?: string;
}

export interface SupportTicket {
  id: string;
  ticketId: string;
  userId: string;
  userEmail: string;
  userName: string;
  subject: string;
  category: 'Hosting' | 'Marketplace' | 'Payment' | 'Custom Request' | 'Other';
  orderId?: string;
  status: 'Open' | 'In Progress' | 'Answered' | 'Closed';
  createdAt: string;
  updatedAt: string;
  messages: Array<{
    id: string;
    sender: 'user' | 'admin';
    senderName: string;
    message: string;
    timestamp: string;
  }>;
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  titleBn: string;
  message: string;
  messageBn: string;
  type: 'info' | 'success' | 'warning' | 'error';
  link?: string;
  isRead: boolean;
  createdAt: string;
}

export interface Announcement {
  id: string;
  title: string;
  titleBn: string;
  message: string;
  messageBn: string;
  badge: string;
  isActive: boolean;
  createdAt: string;
}

export interface AuditLog {
  id: string;
  adminEmail: string;
  action: string;
  targetType: string;
  targetId: string;
  details: string;
  timestamp: string;
}

export interface DatabaseSchema {
  users: User[];
  hostingProjects: HostingProject[];
  marketplaceProducts: MarketplaceProduct[];
  customRequests: CustomWebsiteRequest[];
  orders: Order[];
  payments: PaymentSubmission[];
  supportTickets: SupportTicket[];
  notifications: NotificationItem[];
  announcements: Announcement[];
  auditLogs: AuditLog[];
  platformSettings: {
    freeTierLimitMB: number;
    maxProjectsPerUser: number;
    bKashNumber: string;
    supportEmail: string;
    supportPhone: string;
    telegramUrl: string;
  };
}

const DB_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.resolve(DB_DIR, 'orvix_db.json');

function ensureDbDirectory() {
  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }
}

// Initial seed data with authentic details
const INITIAL_DB: DatabaseSchema = {
  users: [
    {
      id: 'usr_admin_01',
      email: 'businessforworld678@gmail.com',
      displayName: 'ORVIX Admin',
      role: 'admin',
      status: 'active',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      createdAt: new Date().toISOString(),
      quotaMB: 50,
      usedStorageBytes: 1024 * 1024 * 3.4,
      language: 'bn',
      theme: 'dark',
      isVerified: true,
    },
    {
      id: 'usr_demo_user',
      email: 'creator@orvix.io',
      displayName: 'Tahmid Hasan',
      role: 'user',
      status: 'active',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      createdAt: new Date().toISOString(),
      quotaMB: 5,
      usedStorageBytes: 1024 * 420,
      language: 'bn',
      theme: 'dark',
      isVerified: true,
    }
  ],
  hostingProjects: [],
  marketplaceProducts: [
    {
      id: 'prod_saas_apex',
      title: 'Apex SaaS Landing & Dashboard Template',
      titleBn: 'অ্যাপেক্স সাস ল্যান্ডিং ও ড্যাশবোর্ড টেমপ্লেট',
      category: 'Web Applications',
      priceBdt: 4500,
      shortDesc: 'Production-ready modern SaaS landing page and dark theme admin dashboard with analytics charts.',
      shortDescBn: 'আধুনিক ডার্ক মোড সাস ল্যান্ডিং পেজ এবং অ্যানালিটিক্স চার্ট সমৃদ্ধ প্রিমিয়াম অ্যাডমিন ড্যাশবোর্ড।',
      fullDesc: 'Apex is a cutting-edge SaaS template built with React, Tailwind CSS, and Lucide icons. Includes authentication UI, billing page, activity logs, customizable widgets, and responsive layout for mobile & desktop.',
      fullDescBn: 'অ্যাপেক্স একটি আধুনিক সাস টেমপ্লেট। এতে রয়েছে অথেনটিকেশন পেজ, বিলিং ইন্টারফেস, অ্যাক্টিভিটি লগ ও মোবাইল অপ্টিমাইজড ড্যাশবোর্ড।',
      features: ['Modern Dark Mode UI', '15+ Prebuilt Components', 'Chart.js / Tailwind Ready', 'bKash Payment Gateway UI', 'Full Source Code'],
      featuresBn: ['মডার্ন ডার্ক মোড ডিজাইন', '১৫+ রেডিমেড কম্পোনেন্ট', 'চার্ট ও অ্যানালিটিক্স', 'বিকাশ পেমেন্ট ইন্টারফেস', 'সম্পূর্ণ সোর্স কোড'],
      techStack: ['React', 'Tailwind CSS', 'Vite', 'TypeScript'],
      demoUrl: 'https://demo.orvix.network/apex-saas',
      deliveryTime: 'Instant Download',
      deliveryTimeBn: 'তাৎক্ষণিক ডাউনলোড',
      imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&auto=format&fit=crop&q=80',
      isPublished: true,
      downloadUrl: '#',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'prod_ecom_nova',
      title: 'Nova E-Commerce Storefront',
      titleBn: 'নোভা ই-কমার্স অনলাইন শপ',
      category: 'E-commerce Websites',
      priceBdt: 7500,
      shortDesc: 'High-converting online store with product catalog, cart system, and bKash manual checkout.',
      shortDescBn: 'প্রোডাক্ট ক্যাটালগ, কার্ট ও বিকাশ চেকআউট সহ হাই-কনভার্টিং অনলাইন স্টোর।',
      fullDesc: 'Nova E-Commerce provides everything you need to sell products in Bangladesh and worldwide. Features product filters, customer reviews, order tracking, responsive cart drawer, and WhatsApp direct order integration.',
      fullDescBn: 'বাংলাদেশে অনলাইন ব্যবসার জন্য পারফেক্ট ই-কমার্স প্ল্যাটফর্ম। ফিল্টার, কার্ট, অর্ডার ট্র্যাকিং এবং বিকাশ পেমেন্ট ইন্টিগ্রেশন অন্তর্ভুক্ত।',
      features: ['Product Catalog & Search', 'Shopping Cart & Checkout', 'bKash & COD Ready', 'WhatsApp Quick Order', 'SEO Optimized'],
      featuresBn: ['প্রোডাক্ট ক্যাটালগ ও সার্চ', 'শপিং কার্ট ও চেকআউট', 'বিকাশ ও সিওডি সাপোর্ট', 'হোয়াটসঅ্যাপ অর্ডার বাটন', 'এসইও ফ্রেন্ডলি'],
      techStack: ['HTML5', 'Tailwind CSS', 'JavaScript', 'Responsive UI'],
      demoUrl: 'https://demo.orvix.network/nova-shop',
      deliveryTime: 'Instant Download',
      deliveryTimeBn: 'তাৎক্ষণিক ডাউনলোড',
      imageUrl: 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=800&auto=format&fit=crop&q=80',
      isPublished: true,
      downloadUrl: '#',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'prod_agency_studio',
      title: 'Studio Minimal Portfolio for Creatives',
      titleBn: 'স্টুডিও মিনিমাল ক্রিয়েটিভ পোর্টফোলিও',
      category: 'Portfolio Websites',
      priceBdt: 2800,
      shortDesc: 'Sleek, award-winning dark minimalist portfolio for designers, developers, and creators.',
      shortDescBn: 'ডিজাইনার ও ডেভেলপারদের জন্য পুরস্কারজয়ী ডার্ক মিনিমালিস্ট ব্যক্তিগত পোর্টফোলিও।',
      fullDesc: 'Showcase your best projects, client testimonials, resume, and skills with smooth interactions and micro-animations. Lightning fast loading and mobile-first layout.',
      fullDescBn: 'আপনার সেরা কাজ, অভিজ্ঞতা ও ক্লায়েন্ট রিভিউ চমৎকারভাবে প্রদর্শনের জন্য সেরা পোর্টফোলিও ওয়েবসাইট।',
      features: ['Interactive Case Studies', 'Resume Download Button', 'Contact Form UI', 'Custom Cursor Effect', '100 Google Lighthouse Score'],
      featuresBn: ['ইন্টারেক্টিভ কেস স্টাডি', 'সিভি ডাউনলোড বাটন', 'কন্টাক্ট ফর্ম', 'মসৃণ অ্যানিমেশন', '১০০% লাইটহাউস স্কোর'],
      techStack: ['HTML5', 'CSS3', 'Modern JS', 'Framer Motion Style'],
      demoUrl: 'https://demo.orvix.network/studio-folio',
      deliveryTime: 'Instant Download',
      deliveryTimeBn: 'তাৎক্ষণিক ডাউনলোড',
      imageUrl: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=800&auto=format&fit=crop&q=80',
      isPublished: true,
      downloadUrl: '#',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'prod_eduspark_lms',
      title: 'EduSpark Online Academy Portal',
      titleBn: 'এডুস্পার্ক অনলাইন একাডেমি পোর্টাল',
      category: 'Educational Websites',
      priceBdt: 6200,
      shortDesc: 'Course selling and student learning portal with lecture player, quiz cards, and certificate template.',
      shortDescBn: 'কোর্স বিক্রি ও অনলাইন ক্লাসের জন্য লেকচার প্লেয়ার ও কুইজ সিস্টেম সমৃদ্ধ লার্নিং পোর্টাল।',
      fullDesc: 'Complete educational website for coaching centers, instructors, and training institutes. Easily organize video lessons, PDF materials, and enrollments.',
      fullDescBn: 'কোচিং সেন্টার ও অনলাইন শিক্ষকদের জন্য পূর্ণাঙ্গ লার্নিং ম্যানেজমেন্ট ওয়েবসাইট।',
      features: ['Course Curriculum Grid', 'Video Lesson Layout', 'Instructor Profile Page', 'Student Review System', 'Certificate Preview'],
      featuresBn: ['কোর্স সিলেবাস গ্রিড', 'ভিডিও লেকচার লেআউট', 'শিক্ষক প্রোফাইল পেজ', 'স্টুডেন্ট রিভিউ', 'সার্টিফিকেট প্রিভিউ'],
      techStack: ['React', 'Tailwind CSS', 'Vite'],
      demoUrl: 'https://demo.orvix.network/eduspark',
      deliveryTime: 'Instant Download',
      deliveryTimeBn: 'তাৎক্ষণিক ডাউনলোড',
      imageUrl: 'https://images.unsplash.com/photo-1501504905252-473c47e087f8?w=800&auto=format&fit=crop&q=80',
      isPublished: true,
      downloadUrl: '#',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'prod_android_app_service',
      title: 'Website to Android App Development',
      titleBn: 'ওয়েবসাইট থেকে অ্যান্ড্রয়েড অ্যাপ রূপান্তর',
      category: 'Android App Development Services',
      priceBdt: 3500,
      shortDesc: 'Convert any responsive website into a high-performance native Android APK & AAB file.',
      shortDescBn: 'যেকোনো ওয়েবসাইটকে প্রিমিয়াম অ্যান্ড্রয়েড অ্যাপে (APK/AAB) রূপান্তর সার্ভিস।',
      fullDesc: 'We turn your existing website or ORVIX-hosted site into a production-ready Android App with offline caching, splash screen, push notification capability, and Play Store submission readiness.',
      fullDescBn: 'আপনার ওয়েবসাইটকে গুগল প্লে স্টোর উপযোগী অ্যান্ড্রয়েড অ্যাপে কনভার্ট করুন। পুশ নোটিফিকেশন ও স্প্ল্যাশ স্ক্রিন সহ।',
      features: ['Signed APK & AAB Files', 'Custom App Icon & Splash', 'OneSignal Push Ready', 'Pull to Refresh Support', 'Play Store Ready'],
      featuresBn: ['সাইনড APK ও AAB ফাইল', 'কাস্টম অ্যাপ আইকন ও স্প্ল্যাশ', 'পুশ নোটিফিকেশন সাপোর্ট', 'পুল টু রিফ্রেশ ফিচার', 'প্লে স্টোর উপযোগী'],
      techStack: ['Android Kotlin', 'Jetpack Compose', 'WebView Turbo'],
      demoUrl: '',
      deliveryTime: '24-48 Hours Delivery',
      deliveryTimeBn: '২৪-৪৮ ঘণ্টার মধ্যে ডেলিভারি',
      imageUrl: 'https://images.unsplash.com/photo-1607252650355-f7fd0460ccdb?w=800&auto=format&fit=crop&q=80',
      isPublished: true,
      downloadUrl: '',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'prod_custom_dev_pro',
      title: 'Full-Stack Custom Website Development',
      titleBn: 'সম্পূর্ণ কাস্টম ফুলস্ট্যাক ওয়েবসাইট তৈরি',
      category: 'Custom Website Development',
      priceBdt: 12000,
      shortDesc: 'Tailor-made web application or business portal engineered strictly according to your specifications.',
      shortDescBn: 'আপনার চাহিদামতো স্পেশাল ফুলস্ট্যাক ওয়েবসাইট বা কাস্টম বিজনেস ওয়েব অ্যাপ্লিকেশন তৈরি।',
      fullDesc: 'Our expert engineering team builds your custom application from scratch with modern tech stack, bKash/Nagad payment gateway, database, responsive UI, free deployment, and 30 days free maintenance.',
      fullDescBn: 'আমাদের এক্সপার্ট টিম আপনার সম্পূর্ণ ওয়েবসাইট বানিয়ে দিবে। সাথে থাকছে ফ্রি হোস্টিং এবং ৩০ দিনের ফ্রি মেইনটেনেন্স সাপোর্ট।',
      features: ['Custom Tailored Design', 'Database & Admin Panel', 'bKash/Nagad Integration', 'Free ORVIX Hosting Setup', '30 Days Free Support'],
      featuresBn: ['কাস্টম ডিজাইন', 'ডাটাবেস ও অ্যাডমিন প্যানেল', 'বিকাশ পেমেন্ট গেটওয়ে', 'ফ্রি অরভিক্স হোস্টিং', '৩০ দিন ফ্রি সাপোর্ট'],
      techStack: ['React / Node.js', 'PostgreSQL / SQLite', 'Tailwind CSS'],
      demoUrl: '',
      deliveryTime: '3-7 Days Delivery',
      deliveryTimeBn: '৩-৭ দিনের মধ্যে ডেলিভারি',
      imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop&q=80',
      isPublished: true,
      downloadUrl: '',
      createdAt: new Date().toISOString(),
    }
  ],
  customRequests: [
    {
      id: 'req_001',
      orderId: 'ORV-CUST-8021',
      userId: 'usr_demo_user',
      customerName: 'Tahmid Hasan',
      email: 'creator@orvix.io',
      whatsapp: '01712345678',
      siteType: 'E-commerce & Wholesale Portal',
      features: 'bKash automatic payment, invoice generation, customer SMS notifications, inventory control.',
      designPreferences: 'Deep navy dark theme similar to ORVIX, high contrast cards, mobile-first design.',
      referenceUrl: 'https://example.com/modern-store',
      budgetBdt: 15000,
      preferredDeadline: '7 Days',
      additionalInstructions: 'Need integration with local courier tracking API if possible.',
      status: 'Quotation Sent',
      quotationAmountBdt: 14000,
      adminNotes: 'Reviewed requirements. Can deliver in 6 days with full bKash integration.',
      createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
      updatedAt: new Date(Date.now() - 86400000).toISOString(),
    }
  ],
  orders: [
    {
      id: 'ord_101',
      orderId: 'ORV-ORD-4920',
      userId: 'usr_demo_user',
      userEmail: 'creator@orvix.io',
      productId: 'prod_saas_apex',
      productTitle: 'Apex SaaS Landing & Dashboard Template',
      orderType: 'marketplace',
      amountBdt: 4500,
      paymentStatus: 'Verified',
      fulfillmentStatus: 'Delivered',
      bKashTxId: 'BK9A726190',
      bKashSenderNumber: '01712345678',
      paymentSubmittedAt: new Date(Date.now() - 86400000 * 3).toISOString(),
      adminVerificationNotes: 'Payment verified manually via bKash statement.',
      deliverableLink: 'https://orvix.network/downloads/apex-saas-source-v1.zip',
      createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
      updatedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    }
  ],
  payments: [
    {
      id: 'pay_101',
      orderId: 'ORV-ORD-4920',
      userId: 'usr_demo_user',
      userEmail: 'creator@orvix.io',
      amountBdt: 4500,
      senderNumber: '01712345678',
      transactionId: 'BK9A726190',
      submittedAt: new Date(Date.now() - 86400000 * 3).toISOString(),
      status: 'Verified',
      notes: 'TrxID confirmed in bKash merchant ledger.',
      verifiedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
      verifiedBy: 'businessforworld678@gmail.com',
    }
  ],
  supportTickets: [
    {
      id: 'tkt_001',
      ticketId: 'TKT-8419',
      userId: 'usr_demo_user',
      userEmail: 'creator@orvix.io',
      userName: 'Tahmid Hasan',
      subject: 'Custom domain DNS propagation query',
      category: 'Hosting',
      orderId: '',
      status: 'Answered',
      createdAt: new Date(Date.now() - 86400000).toISOString(),
      updatedAt: new Date().toISOString(),
      messages: [
        {
          id: 'msg_1',
          sender: 'user',
          senderName: 'Tahmid Hasan',
          message: 'Hello, I added my custom domain tahmid.dev with CNAME records. How long does verification usually take?',
          timestamp: new Date(Date.now() - 86400000).toISOString(),
        },
        {
          id: 'msg_2',
          sender: 'admin',
          senderName: 'ORVIX Support (Jubayer)',
          message: 'Hi Tahmid! DNS CNAME records generally propagate within 15 to 45 minutes worldwide. Your records have been detected and the SSL certificate is auto-provisioning.',
          timestamp: new Date(Date.now() - 3600000 * 4).toISOString(),
        }
      ]
    }
  ],
  notifications: [
    {
      id: 'notif_welcome',
      userId: 'usr_demo_user',
      title: 'Welcome to ORVIX!',
      titleBn: 'অরভিক্সে স্বাগতম!',
      message: 'Deploy your first HTML website for free in seconds.',
      messageBn: 'কয়েক সেকেন্ডে সম্পূর্ণ বিনামূল্যে আপনার প্রথম এইচটিএমএল সাইট লাইভ করুন।',
      type: 'success',
      link: '/host',
      isRead: false,
      createdAt: new Date().toISOString(),
    }
  ],
  announcements: [
    {
      id: 'ann_01',
      title: 'Free High-Speed Static Hosting Now Live in Bangladesh!',
      titleBn: 'বাংলাদেশে সম্পূর্ণ ফ্রি হাই-স্পিড স্ট্যাটিক হোস্টিং চালু হয়েছে!',
      message: 'Deploy your HTML/CSS/JS websites with instant global CDN and custom subdomain at zero cost.',
      messageBn: 'জিরো খরচে আপনার এইচটিএমএল/সিএসএস/জাভাস্ক্রিপ্ট ওয়েবসাইট ইনস্ট্যান্ট গ্লোবাল সিডিএন ও কাস্টম সাবডোমেইনে লাইভ করুন।',
      badge: 'NEW',
      isActive: true,
      createdAt: new Date().toISOString(),
    }
  ],
  auditLogs: [
    {
      id: 'aud_01',
      adminEmail: 'businessforworld678@gmail.com',
      action: 'PLATFORM_INITIALIZED',
      targetType: 'SYSTEM',
      targetId: 'ORVIX_CORE',
      details: 'Platform initialized with bKash 01344495081 payment and static deployment engine.',
      timestamp: new Date().toISOString(),
    }
  ],
  platformSettings: {
    freeTierLimitMB: 5,
    maxProjectsPerUser: 10,
    bKashNumber: '01344495081',
    supportEmail: 'businessforworld678@gmail.com',
    supportPhone: '01344495081',
    telegramUrl: 'https://t.me/jubayerahamed8',
  }
};

class Database {
  private data: DatabaseSchema;

  constructor() {
    ensureDbDirectory();
    this.data = this.load();
  }

  private load(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        return JSON.parse(raw);
      }
    } catch (e) {
      console.error('Error loading DB file, fallback to initial seed:', e);
    }
    this.save(INITIAL_DB);
    return INITIAL_DB;
  }

  private save(dataToSave: DatabaseSchema) {
    try {
      ensureDbDirectory();
      fs.writeFileSync(DB_FILE, JSON.stringify(dataToSave, null, 2), 'utf-8');
    } catch (e) {
      console.error('Error saving DB file:', e);
    }
  }

  public get(): DatabaseSchema {
    return this.data;
  }

  public update(updater: (db: DatabaseSchema) => void): DatabaseSchema {
    updater(this.data);
    this.save(this.data);
    return this.data;
  }
}

export const db = new Database();
