import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { db, User } from './server/db.js';
import {
  deployProjectFiles,
  rollbackProject,
  seedDefaultHostingProjects,
  MIME_TYPES,
  unpackZipArchive,
} from './server/hosting.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const IS_PROD = process.env.NODE_ENV === 'production';

// Increase body limit for static website uploads (5MB upload requires ~7MB in base64/JSON)
app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));

// Seed demo sites
seedDefaultHostingProjects();

// Simple auth helper from Authorization header (token or user ID)
function getAuthUser(req: Request): User | null {
  const authHeader = req.headers.authorization;
  if (!authHeader) return null;
  const token = authHeader.replace(/^Bearer\s+/i, '').trim();
  const currentDb = db.get();
  // Find by user id or email directly
  const user = currentDb.users.find(u => u.id === token || u.email === token);
  return user || null;
}

// -------------------------------------------------------------
// 1. SERVE HOSTED USER WEBSITES (/sites/:slug/*)
// -------------------------------------------------------------
app.use('/sites/:slug', (req: Request, res: Response, next: NextFunction) => {
  const { slug } = req.params;
  const currentDb = db.get();
  const project = currentDb.hostingProjects.find(p => p.slug === slug);

  if (!project) {
    res.status(404).send(`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>404 — Site Not Found | ORVIX</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
          body { background: #070b14; color: #f1f5f9; font-family: system-ui, sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }
          .card { background: #0f172a; padding: 2.5rem; border-radius: 1rem; border: 1px solid #1e293b; max-width: 480px; text-align: center; }
          h1 { color: #38bdf8; margin: 0 0 1rem; font-size: 2rem; }
          p { color: #94a3b8; font-size: 0.95rem; line-height: 1.6; }
          a { color: #06b6d4; text-decoration: none; font-weight: 600; }
        </style>
      </head>
      <body>
        <div class="card">
          <h1>ORVIX 404</h1>
          <p>The hosted website <strong>${slug}.orvix</strong> was not found or has been taken down.</p>
          <p><a href="/">Return to ORVIX Home →</a></p>
        </div>
      </body>
      </html>
    `);
    return;
  }

  if (project.status === 'Suspended') {
    res.status(403).send(`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Suspended | ORVIX</title>
        <style>
          body { background: #070b14; color: #f87171; font-family: system-ui, sans-serif; display: grid; place-content: center; min-height: 100vh; margin: 0; text-align: center; }
          .card { background: #1e1b2e; padding: 2rem; border-radius: 1rem; border: 1px solid #7f1d1d; }
        </style>
      </head>
      <body>
        <div class="card">
          <h2>Website Suspended</h2>
          <p>This deployment is temporarily unavailable due to policy review.</p>
        </div>
      </body>
      </html>
    `);
    return;
  }

  // Requested path inside the site
  let reqPath = req.path || '/';
  if (reqPath === '/' || reqPath === '') {
    reqPath = '/index.html';
  }

  // Sanitize path
  const safeRelPath = path.normalize(reqPath).replace(/^(\.\.(\/|\\|$))+/, '').replace(/^[/\\]+/, '');
  const targetFile = path.resolve(process.cwd(), 'data/sites', slug, 'current', safeRelPath);

  if (!fs.existsSync(targetFile) || fs.statSync(targetFile).isDirectory()) {
    // If directory, try index.html inside it
    const indexInDir = path.resolve(targetFile, 'index.html');
    if (fs.existsSync(indexInDir)) {
      sendFileSafely(res, indexInDir);
      return;
    }

    res.status(404).send(`
      <!DOCTYPE html>
      <html>
      <head><title>File Not Found</title></head>
      <body style="background:#070b14;color:#94a3b8;font-family:sans-serif;padding:3rem;text-align:center;">
        <h2 style="color:#f87171;">404 Not Found</h2>
        <p>File <code>/${safeRelPath}</code> was not found on this deployment.</p>
      </body>
      </html>
    `);
    return;
  }

  sendFileSafely(res, targetFile);
});

function sendFileSafely(res: Response, filePath: string) {
  const ext = path.extname(filePath).toLowerCase();
  const contentType = MIME_TYPES[ext] || 'application/octet-stream';

  res.setHeader('Content-Type', contentType);
  // Sandboxing headers: isolate client storage while allowing iframe preview
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Cache-Control', 'public, max-age=60');

  const stream = fs.createReadStream(filePath);
  stream.pipe(res);
}

// -------------------------------------------------------------
// 2. AUTHENTICATION & USERS API
// -------------------------------------------------------------
app.get('/api/auth/me', (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (!user) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }
  res.json({ user });
});

app.post('/api/auth/register', (req: Request, res: Response) => {
  const { email, password, displayName } = req.body;
  if (!email || !email.includes('@')) {
    res.status(400).json({ error: 'Valid email is required.' });
    return;
  }

  const currentDb = db.get();
  const existing = currentDb.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  if (existing) {
    res.status(400).json({ error: 'An account with this email already exists.' });
    return;
  }

  const isPlatformOwner = email.toLowerCase() === 'businessforworld678@gmail.com';
  const role = isPlatformOwner ? 'admin' : 'user';

  const newUser: User = {
    id: `usr_${Date.now()}`,
    email: email.toLowerCase(),
    displayName: displayName || email.split('@')[0],
    role,
    status: 'active',
    avatarUrl: `https://api.dicebear.com/7.x/identicon/svg?seed=${encodeURIComponent(email)}`,
    createdAt: new Date().toISOString(),
    quotaMB: isPlatformOwner ? 50 : 5,
    usedStorageBytes: 0,
    language: 'bn',
    theme: 'dark',
    isVerified: true,
  };

  db.update(draft => {
    draft.users.unshift(newUser);
    draft.notifications.unshift({
      id: `notif_${Date.now()}`,
      userId: newUser.id,
      title: 'Registration Successful',
      titleBn: 'অ্যাকাউন্ট তৈরি সম্পন্ন হয়েছে',
      message: 'Welcome to ORVIX. Your free static hosting tier is ready.',
      messageBn: 'অরভিক্সে স্বাগতম। আপনার ফ্রি স্ট্যাটিক হোস্টিং প্ল্যান সক্রিয় হয়েছে।',
      type: 'success',
      link: '/host',
      isRead: false,
      createdAt: new Date().toISOString(),
    });
  });

  res.json({ user: newUser, token: newUser.id });
});

app.post('/api/auth/login', (req: Request, res: Response) => {
  const { email, password } = req.body;
  if (!email) {
    res.status(400).json({ error: 'Email is required.' });
    return;
  }

  const currentDb = db.get();
  let user = currentDb.users.find(u => u.email.toLowerCase() === email.toLowerCase());

  // Auto-provision admin if the platform owner signs in
  if (!user && email.toLowerCase() === 'businessforworld678@gmail.com') {
    user = {
      id: 'usr_admin_01',
      email: 'businessforworld678@gmail.com',
      displayName: 'ORVIX Admin',
      role: 'admin',
      status: 'active',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      createdAt: new Date().toISOString(),
      quotaMB: 50,
      usedStorageBytes: 1024 * 1024 * 3.4,
      language: 'bn',
      theme: 'dark',
      isVerified: true,
    };
    db.update(draft => {
      draft.users.unshift(user!);
    });
  }

  if (!user) {
    res.status(401).json({ error: 'Invalid credentials. User not found.' });
    return;
  }

  if (user.status === 'suspended') {
    res.status(403).json({ error: 'Your account has been suspended. Please contact support.' });
    return;
  }

  res.json({ user, token: user.id });
});

app.post('/api/auth/google', (req: Request, res: Response) => {
  const { email, displayName, avatarUrl } = req.body;
  const targetEmail = (email || 'businessforworld678@gmail.com').toLowerCase();

  const currentDb = db.get();
  let user = currentDb.users.find(u => u.email.toLowerCase() === targetEmail);

  if (!user) {
    const isPlatformOwner = targetEmail === 'businessforworld678@gmail.com';
    user = {
      id: `usr_g_${Date.now()}`,
      email: targetEmail,
      displayName: displayName || targetEmail.split('@')[0],
      role: isPlatformOwner ? 'admin' : 'user',
      status: 'active',
      avatarUrl: avatarUrl || `https://api.dicebear.com/7.x/identicon/svg?seed=${encodeURIComponent(targetEmail)}`,
      createdAt: new Date().toISOString(),
      quotaMB: isPlatformOwner ? 50 : 5,
      usedStorageBytes: 0,
      language: 'bn',
      theme: 'dark',
      isVerified: true,
    };
    db.update(draft => {
      draft.users.unshift(user!);
    });
  }

  res.json({ user, token: user.id });
});

app.patch('/api/auth/profile', (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (!user) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }

  const { displayName, avatarUrl, language, theme } = req.body;

  db.update(draft => {
    const found = draft.users.find(u => u.id === user.id);
    if (found) {
      if (displayName) found.displayName = displayName;
      if (avatarUrl) found.avatarUrl = avatarUrl;
      if (language) found.language = language;
      if (theme) found.theme = theme;
    }
  });

  const updated = db.get().users.find(u => u.id === user.id);
  res.json({ user: updated });
});

// -------------------------------------------------------------
// 3. FREE HOSTING & DEPLOYMENT API
// -------------------------------------------------------------
app.get('/api/hosting/projects', (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const currentDb = db.get();

  if (user && user.role === 'admin' && req.query.all === 'true') {
    res.json({ projects: currentDb.hostingProjects });
    return;
  }

  if (!user) {
    // Return sample public showcase projects
    res.json({ projects: currentDb.hostingProjects.slice(0, 3) });
    return;
  }

  const userProjects = currentDb.hostingProjects.filter(p => p.userId === user.id);
  res.json({ projects: userProjects });
});

app.get('/api/hosting/check-slug', (req: Request, res: Response) => {
  const slug = (req.query.slug as string || '').toLowerCase().trim();
  if (!slug || slug.length < 3) {
    res.json({ available: false, error: 'Slug must be at least 3 characters' });
    return;
  }

  const currentDb = db.get();
  const existing = currentDb.hostingProjects.find(p => p.slug === slug);
  res.json({
    slug,
    available: !existing,
    subdomain: `${slug}.orvix`,
  });
});

app.post('/api/hosting/deploy', async (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (!user) {
    res.status(401).json({ error: 'Please login to deploy website.' });
    return;
  }

  const { projectName, slug, files, zipBase64, notes, projectId } = req.body;

  let fileList = files || [];

  // If a ZIP archive was uploaded
  if (zipBase64) {
    try {
      const zipBuffer = Buffer.from(zipBase64, 'base64');
      fileList = await unpackZipArchive(zipBuffer);
    } catch (err: any) {
      res.status(400).json({ error: `Failed to extract ZIP archive: ${err.message}` });
      return;
    }
  }

  if (!fileList || fileList.length === 0) {
    res.status(400).json({ error: 'No files provided for deployment.' });
    return;
  }

  const result = await deployProjectFiles({
    projectId,
    projectName,
    slug,
    userId: user.id,
    userEmail: user.email,
    files: fileList,
    notes,
  });

  if (!result.success) {
    res.status(400).json({ error: result.error });
    return;
  }

  res.json({
    success: true,
    project: result.project,
    publicUrl: result.project?.publicUrl,
    subdomain: result.project?.subdomain,
  });
});

app.post('/api/hosting/rollback', async (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (!user) {
    res.status(401).json({ error: 'Authentication required' });
    return;
  }

  const { projectId, targetVersion } = req.body;
  const result = await rollbackProject(projectId, targetVersion, user.id, user.role === 'admin');

  if (!result.success) {
    res.status(400).json({ error: result.error });
    return;
  }

  const currentDb = db.get();
  const proj = currentDb.hostingProjects.find(p => p.id === projectId);
  res.json({ success: true, project: proj });
});

app.delete('/api/hosting/projects/:id', (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (!user) {
    res.status(401).json({ error: 'Authentication required' });
    return;
  }

  const { id } = req.params;
  const currentDb = db.get();
  const project = currentDb.hostingProjects.find(p => p.id === id);

  if (!project) {
    res.status(404).json({ error: 'Project not found' });
    return;
  }

  if (project.userId !== user.id && user.role !== 'admin') {
    res.status(403).json({ error: 'Access denied' });
    return;
  }

  // Remove files from disk
  const siteDir = path.resolve(process.cwd(), 'data/sites', project.slug);
  if (fs.existsSync(siteDir)) {
    try {
      fs.rmSync(siteDir, { recursive: true, force: true });
    } catch (e) {
      console.error('Error removing site directory:', e);
    }
  }

  db.update(draft => {
    draft.hostingProjects = draft.hostingProjects.filter(p => p.id !== id);
    draft.auditLogs.unshift({
      id: `aud_${Date.now()}`,
      adminEmail: user.email,
      action: 'DELETE_PROJECT',
      targetType: 'PROJECT',
      targetId: id,
      details: `Project ${project.name} (${project.slug}) deleted.`,
      timestamp: new Date().toISOString(),
    });
  });

  res.json({ success: true, message: 'Project successfully deleted.' });
});

app.post('/api/hosting/custom-domain', (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (!user) {
    res.status(401).json({ error: 'Authentication required' });
    return;
  }

  const { projectId, domain } = req.body;
  if (!domain || !domain.includes('.')) {
    res.status(400).json({ error: 'Invalid domain name format.' });
    return;
  }

  db.update(draft => {
    const proj = draft.hostingProjects.find(p => p.id === projectId);
    if (proj && (proj.userId === user.id || user.role === 'admin')) {
      proj.customDomain = domain.toLowerCase().trim();
      proj.customDomainVerified = false;
    }
  });

  res.json({
    success: true,
    domain,
    dnsInstructions: {
      cnameRecord: { host: '@ or www', type: 'CNAME', value: 'cname.orvix.network' },
      aRecord: { host: '@', type: 'A', value: '199.36.158.100' },
      status: 'Pending DNS verification (Usually propagates within 15-30 minutes)',
    }
  });
});

// -------------------------------------------------------------
// 4. MARKETPLACE & PRODUCTS API
// -------------------------------------------------------------
app.get('/api/marketplace/products', (req: Request, res: Response) => {
  const currentDb = db.get();
  const { category, search } = req.query;

  let products = currentDb.marketplaceProducts.filter(p => p.isPublished);

  if (category && category !== 'All') {
    products = products.filter(p => p.category.toLowerCase() === (category as string).toLowerCase());
  }

  if (search) {
    const q = (search as string).toLowerCase();
    products = products.filter(p =>
      p.title.toLowerCase().includes(q) ||
      p.shortDesc.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q)
    );
  }

  res.json({ products });
});

app.post('/api/marketplace/products', (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (!user || user.role !== 'admin') {
    res.status(403).json({ error: 'Admin access required' });
    return;
  }

  const { title, titleBn, category, priceBdt, shortDesc, shortDescBn, fullDesc, fullDescBn, features, featuresBn, techStack, demoUrl, deliveryTime, deliveryTimeBn, imageUrl } = req.body;

  const newProduct = {
    id: `prod_${Date.now()}`,
    title,
    titleBn: titleBn || title,
    category,
    priceBdt: Number(priceBdt) || 0,
    shortDesc,
    shortDescBn: shortDescBn || shortDesc,
    fullDesc: fullDesc || shortDesc,
    fullDescBn: fullDescBn || shortDescBn || shortDesc,
    features: Array.isArray(features) ? features : [features].filter(Boolean),
    featuresBn: Array.isArray(featuresBn) ? featuresBn : [featuresBn].filter(Boolean),
    techStack: Array.isArray(techStack) ? techStack : ['React', 'Tailwind CSS'],
    demoUrl: demoUrl || '',
    deliveryTime: deliveryTime || 'Instant',
    deliveryTimeBn: deliveryTimeBn || 'তাৎক্ষণিক',
    imageUrl: imageUrl || 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop&q=80',
    isPublished: true,
    downloadUrl: '#',
    createdAt: new Date().toISOString(),
  };

  db.update(draft => {
    draft.marketplaceProducts.unshift(newProduct);
  });

  res.json({ success: true, product: newProduct });
});

// -------------------------------------------------------------
// 5. ORDERS & BKASH PAYMENT SUBMISSION
// -------------------------------------------------------------
app.get('/api/orders', (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (!user) {
    res.status(401).json({ error: 'Authentication required' });
    return;
  }

  const currentDb = db.get();
  if (user.role === 'admin' && req.query.all === 'true') {
    res.json({ orders: currentDb.orders, customRequests: currentDb.customRequests });
    return;
  }

  const userOrders = currentDb.orders.filter(o => o.userId === user.id);
  const userCustomRequests = currentDb.customRequests.filter(r => r.userId === user.id);
  res.json({ orders: userOrders, customRequests: userCustomRequests });
});

app.post('/api/orders/create', (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (!user) {
    res.status(401).json({ error: 'Please login to place an order.' });
    return;
  }

  const { productId } = req.body;
  const currentDb = db.get();
  const product = currentDb.marketplaceProducts.find(p => p.id === productId);

  if (!product) {
    res.status(404).json({ error: 'Product not found.' });
    return;
  }

  const orderId = `ORV-ORD-${Math.floor(1000 + Math.random() * 9000)}`;

  const newOrder = {
    id: `ord_${Date.now()}`,
    orderId,
    userId: user.id,
    userEmail: user.email,
    productId: product.id,
    productTitle: product.title,
    orderType: 'marketplace' as const,
    amountBdt: product.priceBdt,
    paymentStatus: 'Awaiting Payment' as const,
    fulfillmentStatus: 'Pending' as const,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  db.update(draft => {
    draft.orders.unshift(newOrder);
    draft.notifications.unshift({
      id: `notif_${Date.now()}`,
      userId: user.id,
      title: 'Order Created',
      titleBn: 'অর্ডার সফলভাবে তৈরি হয়েছে',
      message: `Order #${orderId} created for ${product.title}. Please submit bKash payment to complete.`,
      messageBn: `অর্ডার #${orderId} তৈরি করা হয়েছে। অর্ডারটি সক্রিয় করতে বিকাশ পেমেন্ট সম্পন্ন করুন।`,
      type: 'info',
      link: '/orders',
      isRead: false,
      createdAt: new Date().toISOString(),
    });
  });

  res.json({ success: true, order: newOrder });
});

app.post('/api/orders/custom-request', (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (!user) {
    res.status(401).json({ error: 'Please login to submit custom website request.' });
    return;
  }

  const { customerName, email, whatsapp, siteType, features, designPreferences, referenceUrl, budgetBdt, preferredDeadline, additionalInstructions } = req.body;

  const orderId = `ORV-CUST-${Math.floor(1000 + Math.random() * 9000)}`;

  const newRequest = {
    id: `req_${Date.now()}`,
    orderId,
    userId: user.id,
    customerName: customerName || user.displayName,
    email: email || user.email,
    whatsapp,
    siteType: siteType || 'Custom Website',
    features: features || '',
    designPreferences: designPreferences || '',
    referenceUrl,
    budgetBdt: Number(budgetBdt) || 10000,
    preferredDeadline: preferredDeadline || '7 Days',
    additionalInstructions,
    status: 'Requested' as const,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  db.update(draft => {
    draft.customRequests.unshift(newRequest);
    draft.notifications.unshift({
      id: `notif_${Date.now()}`,
      userId: user.id,
      title: 'Custom Website Request Submitted',
      titleBn: 'কাস্টম ওয়েবসাইট রিকোয়েস্ট জমা হয়েছে',
      message: `Your custom request #${orderId} has been sent to ORVIX engineering team.`,
      messageBn: `আপনার রিকোয়েস্ট #${orderId} অরভিক্স ইঞ্জিনিয়ারিং টিমের কাছে জমা হয়েছে। শীঘ্রই কোটেশন পাঠানো হবে।`,
      type: 'success',
      link: '/orders',
      isRead: false,
      createdAt: new Date().toISOString(),
    });
  });

  res.json({ success: true, customRequest: newRequest });
});

// bKash Manual Payment Submission
app.post('/api/payments/submit', (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (!user) {
    res.status(401).json({ error: 'Authentication required' });
    return;
  }

  const { orderId, amountBdt, senderNumber, transactionId } = req.body;

  if (!orderId || !senderNumber || !transactionId) {
    res.status(400).json({ error: 'Order ID, Sender bKash Number, and Transaction ID are required.' });
    return;
  }

  const cleanTxId = transactionId.trim().toUpperCase();
  const cleanSender = senderNumber.trim();

  const submission = {
    id: `pay_${Date.now()}`,
    orderId,
    userId: user.id,
    userEmail: user.email,
    amountBdt: Number(amountBdt) || 0,
    senderNumber: cleanSender,
    transactionId: cleanTxId,
    submittedAt: new Date().toISOString(),
    status: 'Submitted for Verification' as const,
  };

  db.update(draft => {
    draft.payments.unshift(submission);

    // Update order status
    const order = draft.orders.find(o => o.orderId === orderId);
    if (order) {
      order.paymentStatus = 'Submitted for Verification';
      order.bKashTxId = cleanTxId;
      order.bKashSenderNumber = cleanSender;
      order.paymentSubmittedAt = new Date().toISOString();
      order.updatedAt = new Date().toISOString();
    }

    draft.notifications.unshift({
      id: `notif_${Date.now()}`,
      userId: user.id,
      title: 'bKash Payment Submitted',
      titleBn: 'বিকাশ পেমেন্ট তথ্য জমা হয়েছে',
      message: `Transaction ${cleanTxId} for order ${orderId} is being verified by admin.`,
      messageBn: `অর্ডার ${orderId}-এর ট্রানজেকশন ${cleanTxId} ভেরিফিকেশন প্রসেসে আছে।`,
      type: 'info',
      link: '/orders',
      isRead: false,
      createdAt: new Date().toISOString(),
    });
  });

  res.json({ success: true, submission });
});

// Admin verify/reject payment
app.post('/api/payments/verify', (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (!user || user.role !== 'admin') {
    res.status(403).json({ error: 'Admin access required' });
    return;
  }

  const { paymentId, orderId, approved, notes, deliverableLink } = req.body;

  db.update(draft => {
    const pay = draft.payments.find(p => p.id === paymentId || p.orderId === orderId);
    const order = draft.orders.find(o => o.orderId === orderId);

    const status = approved ? 'Verified' : 'Rejected';

    if (pay) {
      pay.status = status;
      pay.notes = notes;
      pay.verifiedAt = new Date().toISOString();
      pay.verifiedBy = user.email;
    }

    if (order) {
      order.paymentStatus = status;
      order.adminVerificationNotes = notes;
      if (approved) {
        order.fulfillmentStatus = deliverableLink ? 'Delivered' : 'In Progress';
        if (deliverableLink) order.deliverableLink = deliverableLink;
      }
      order.updatedAt = new Date().toISOString();

      draft.notifications.unshift({
        id: `notif_${Date.now()}`,
        userId: order.userId,
        title: approved ? 'Payment Verified!' : 'Payment Verification Issue',
        titleBn: approved ? 'পেমেন্ট সফলভাবে ভেরিফাইড হয়েছে!' : 'পেমেন্ট ভেরিফিকেশনে সমস্যা হয়েছে',
        message: approved
          ? `Your bKash payment for order ${order.orderId} was verified.`
          : `Payment for order ${order.orderId} was rejected: ${notes || 'Transaction ID mismatch'}.`,
        messageBn: approved
          ? `অর্ডার ${order.orderId}-এর বিকাশ পেমেন্ট অ্যাপ্রুভ হয়েছে।`
          : `অর্ডার ${order.orderId}-এর পেমেন্ট বাতিল করা হয়েছে: ${notes || 'তথ্য অমিল'}`,
        type: approved ? 'success' : 'error',
        link: '/orders',
        isRead: false,
        createdAt: new Date().toISOString(),
      });
    }

    draft.auditLogs.unshift({
      id: `aud_${Date.now()}`,
      adminEmail: user.email,
      action: approved ? 'PAYMENT_APPROVED' : 'PAYMENT_REJECTED',
      targetType: 'PAYMENT',
      targetId: orderId,
      details: `Payment for ${orderId} marked as ${status}. Notes: ${notes || 'N/A'}`,
      timestamp: new Date().toISOString(),
    });
  });

  res.json({ success: true });
});

// -------------------------------------------------------------
// 6. SUPPORT TICKETS API
// -------------------------------------------------------------
app.get('/api/support/tickets', (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (!user) {
    res.status(401).json({ error: 'Authentication required' });
    return;
  }

  const currentDb = db.get();
  if (user.role === 'admin' && req.query.all === 'true') {
    res.json({ tickets: currentDb.supportTickets });
    return;
  }

  const userTickets = currentDb.supportTickets.filter(t => t.userId === user.id);
  res.json({ tickets: userTickets });
});

app.post('/api/support/tickets', (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (!user) {
    res.status(401).json({ error: 'Authentication required' });
    return;
  }

  const { subject, category, message, orderId } = req.body;
  if (!subject || !message) {
    res.status(400).json({ error: 'Subject and message are required.' });
    return;
  }

  const ticketId = `TKT-${Math.floor(1000 + Math.random() * 9000)}`;

  const newTicket = {
    id: `tkt_${Date.now()}`,
    ticketId,
    userId: user.id,
    userEmail: user.email,
    userName: user.displayName,
    subject,
    category: category || 'Hosting',
    orderId,
    status: 'Open' as const,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    messages: [
      {
        id: `msg_${Date.now()}`,
        sender: 'user' as const,
        senderName: user.displayName,
        message,
        timestamp: new Date().toISOString(),
      }
    ]
  };

  db.update(draft => {
    draft.supportTickets.unshift(newTicket);
  });

  res.json({ success: true, ticket: newTicket });
});

app.post('/api/support/tickets/:id/reply', (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (!user) {
    res.status(401).json({ error: 'Authentication required' });
    return;
  }

  const { id } = req.params;
  const { message } = req.body;
  if (!message) {
    res.status(400).json({ error: 'Message cannot be empty.' });
    return;
  }

  const isAdmin = user.role === 'admin';

  db.update(draft => {
    const ticket = draft.supportTickets.find(t => t.id === id || t.ticketId === id);
    if (!ticket) return;

    ticket.messages.push({
      id: `msg_${Date.now()}`,
      sender: isAdmin ? 'admin' : 'user',
      senderName: isAdmin ? `ORVIX Support (${user.displayName})` : user.displayName,
      message,
      timestamp: new Date().toISOString(),
    });

    ticket.status = isAdmin ? 'Answered' : 'In Progress';
    ticket.updatedAt = new Date().toISOString();

    if (isAdmin) {
      draft.notifications.unshift({
        id: `notif_${Date.now()}`,
        userId: ticket.userId,
        title: `Reply on Ticket #${ticket.ticketId}`,
        titleBn: `টিকেট #${ticket.ticketId}-এ নতুন রিপ্লাই`,
        message: `ORVIX support replied: "${message.substring(0, 50)}..."`,
        messageBn: `অরভিক্স সাপোর্ট টিম আপনার টিকেটে রিপ্লাই দিয়েছে।`,
        type: 'info',
        link: '/support',
        isRead: false,
        createdAt: new Date().toISOString(),
      });
    }
  });

  res.json({ success: true });
});

// -------------------------------------------------------------
// 7. NOTIFICATIONS & ANNOUNCEMENTS
// -------------------------------------------------------------
app.get('/api/notifications', (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (!user) {
    res.json({ notifications: [] });
    return;
  }

  const currentDb = db.get();
  const list = currentDb.notifications.filter(n => n.userId === user.id);
  res.json({ notifications: list });
});

app.post('/api/notifications/mark-read', (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (!user) {
    res.status(401).json({ error: 'Authentication required' });
    return;
  }

  db.update(draft => {
    draft.notifications.forEach(n => {
      if (n.userId === user.id) n.isRead = true;
    });
  });

  res.json({ success: true });
});

app.get('/api/announcements', (_req: Request, res: Response) => {
  const currentDb = db.get();
  res.json({ announcements: currentDb.announcements.filter(a => a.isActive) });
});

// -------------------------------------------------------------
// 8. ADMIN DASHBOARD & AUDIT LOGS
// -------------------------------------------------------------
app.get('/api/admin/stats', (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (!user || user.role !== 'admin') {
    res.status(403).json({ error: 'Admin access required' });
    return;
  }

  const currentDb = db.get();
  const totalUsers = currentDb.users.length;
  const activeUsers = currentDb.users.filter(u => u.status === 'active').length;
  const totalProjects = currentDb.hostingProjects.length;
  const publishedProjects = currentDb.hostingProjects.filter(p => p.status === 'Published').length;
  const totalOrders = currentDb.orders.length;
  const pendingPayments = currentDb.payments.filter(p => p.status === 'Submitted for Verification').length;
  const openTickets = currentDb.supportTickets.filter(t => t.status === 'Open' || t.status === 'In Progress').length;
  const totalStorageBytes = currentDb.hostingProjects.reduce((acc, p) => acc + (p.totalSizeBytes || 0), 0);

  res.json({
    stats: {
      totalUsers,
      activeUsers,
      totalProjects,
      publishedProjects,
      totalProducts: currentDb.marketplaceProducts.length,
      totalOrders,
      pendingPayments,
      openTickets,
      totalStorageBytes,
      bKashNumber: currentDb.platformSettings.bKashNumber,
      supportEmail: currentDb.platformSettings.supportEmail,
    }
  });
});

app.get('/api/admin/users', (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (!user || user.role !== 'admin') {
    res.status(403).json({ error: 'Admin access required' });
    return;
  }
  const currentDb = db.get();
  res.json({ users: currentDb.users });
});

app.patch('/api/admin/users/:id', (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (!user || user.role !== 'admin') {
    res.status(403).json({ error: 'Admin access required' });
    return;
  }

  const { id } = req.params;
  const { status, quotaMB, role } = req.body;

  db.update(draft => {
    const target = draft.users.find(u => u.id === id);
    if (target) {
      if (status) target.status = status;
      if (quotaMB) target.quotaMB = Number(quotaMB);
      if (role) target.role = role;
    }
  });

  res.json({ success: true });
});

app.get('/api/admin/audit-logs', (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (!user || user.role !== 'admin') {
    res.status(403).json({ error: 'Admin access required' });
    return;
  }
  const currentDb = db.get();
  res.json({ logs: currentDb.auditLogs });
});

// -------------------------------------------------------------
// 9. VITE DEV MIDDLEWARE OR PRODUCTION STATIC SERVING
// -------------------------------------------------------------
async function startServer() {
  if (!IS_PROD) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(process.cwd(), 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(process.cwd(), 'dist/index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ORVIX full-stack platform running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Fatal server boot error:', err);
});
