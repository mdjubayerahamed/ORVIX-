import React, { useState, useEffect } from 'react';
import { LanguageProvider } from './context/LanguageContext.js';
import { ThemeProvider } from './context/ThemeContext.js';
import { AuthProvider, useAuth } from './context/AuthContext.js';
import { LoadingScreen } from './components/LoadingScreen.js';
import { Navbar } from './components/Navbar.js';
import { MobileBottomNav } from './components/MobileBottomNav.js';
import { LiveSitePreviewModal } from './components/LiveSitePreviewModal.js';
import { BkashPaymentModal } from './components/BkashPaymentModal.js';
import { AuthModal } from './components/AuthModal.js';
import { NotificationModal } from './components/NotificationModal.js';
import { HomePage } from './pages/HomePage.js';
import { HostSitePage } from './pages/HostSitePage.js';
import { MarketplacePage } from './pages/MarketplacePage.js';
import { CustomRequestPage } from './pages/CustomRequestPage.js';
import { OrdersPage } from './pages/OrdersPage.js';
import { SupportPage } from './pages/SupportPage.js';
import { ProfilePage } from './pages/ProfilePage.js';
import { HostingProject, MarketplaceProduct, NotificationItem } from './types/index.js';

function MainApp() {
  const { user, token } = useAuth();
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [showLoadingScreen, setShowLoadingScreen] = useState<boolean>(true);

  // Modals state
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register'>('login');
  const [previewProject, setPreviewProject] = useState<HostingProject | null>(null);
  const [bkashModalData, setBkashModalData] = useState<{
    orderId: string;
    amount: number;
    title: string;
  } | null>(null);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);

  // Fetch notifications gently (only when user has active token)
  const fetchNotifications = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/notifications', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setNotifications(data.notifications || []);
      }
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    if (!token) return;
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 30000);
    return () => clearInterval(interval);
  }, [token]);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const handleMarkAllRead = async () => {
    if (!token) return;
    try {
      await fetch('/api/notifications/mark-read', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchNotifications();
    } catch {
      // ignore
    }
  };

  const handleOpenAuth = (mode: 'login' | 'register' = 'login') => {
    setAuthModalMode(mode);
    setAuthModalOpen(true);
  };

  // Order creation from marketplace
  const handleMarketplaceOrder = async (product: MarketplaceProduct) => {
    if (!token) {
      handleOpenAuth('login');
      return;
    }

    try {
      const res = await fetch('/api/orders/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ productId: product.id }),
      });
      const data = await res.json();
      if (res.ok && data.order) {
        setBkashModalData({
          orderId: data.order.orderId,
          amount: data.order.amountBdt,
          title: product.title,
        });
      }
    } catch (e) {
      console.error('Order creation error:', e);
    }
  };

  return (
    <div className="min-h-screen bg-[#040711] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200 cyber-grid-bg">
      {/* Brand Loading Intro */}
      {showLoadingScreen && (
        <LoadingScreen onComplete={() => setShowLoadingScreen(false)} />
      )}

      {/* Top Navbar for Public User Website */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        openAuthModal={() => handleOpenAuth('login')}
        openNotifications={() => setNotificationsOpen(true)}
        unreadNotificationsCount={unreadCount}
      />

      {/* Main Content Area with fluid animation transition */}
      <main className="flex-1 w-full relative">
        {currentTab === 'home' && (
          <div key="home" className="animate-fade-up">
            <HomePage
              onNavigateTab={setCurrentTab}
              onPreviewProject={(proj) => setPreviewProject(proj)}
              onOpenProductDetails={(prod) => handleMarketplaceOrder(prod)}
            />
          </div>
        )}

        {currentTab === 'host' && (
          <div key="host" className="animate-fade-up">
            <HostSitePage
              onPreviewProject={(proj) => setPreviewProject(proj)}
              openAuthModal={() => handleOpenAuth('login')}
            />
          </div>
        )}

        {currentTab === 'marketplace' && (
          <div key="marketplace" className="animate-fade-up">
            <MarketplacePage
              onOrderProduct={handleMarketplaceOrder}
              openAuthModal={() => handleOpenAuth('login')}
            />
          </div>
        )}

        {currentTab === 'custom-request' && (
          <div key="custom-request" className="animate-fade-up">
            <CustomRequestPage
              onOrderCreated={() => setCurrentTab('orders')}
              openAuthModal={() => handleOpenAuth('login')}
            />
          </div>
        )}

        {currentTab === 'orders' && (
          <div key="orders" className="animate-fade-up">
            <OrdersPage
              onOpenBkashModal={(orderId, amount, title) =>
                setBkashModalData({ orderId, amount, title })
              }
              openAuthModal={() => handleOpenAuth('login')}
              onNavigateTab={setCurrentTab}
            />
          </div>
        )}

        {currentTab === 'support' && (
          <div key="support" className="animate-fade-up">
            <SupportPage openAuthModal={() => handleOpenAuth('login')} />
          </div>
        )}

        {currentTab === 'profile' && (
          <div key="profile" className="animate-fade-up">
            <ProfilePage
              openAuthModal={() => handleOpenAuth('login')}
              onNavigateTab={setCurrentTab}
            />
          </div>
        )}
      </main>

      {/* Mobile Fixed 5-Option Bottom Navigation */}
      <MobileBottomNav
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        ordersBadge={0}
      />

      {/* Modals */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        defaultMode={authModalMode}
      />

      <LiveSitePreviewModal
        project={previewProject}
        onClose={() => setPreviewProject(null)}
      />

      {bkashModalData && (
        <BkashPaymentModal
          orderId={bkashModalData.orderId}
          amountBdt={bkashModalData.amount}
          productTitle={bkashModalData.title}
          onClose={() => setBkashModalData(null)}
          onPaymentSubmitted={() => {
            setBkashModalData(null);
            setCurrentTab('orders');
          }}
        />
      )}

      {notificationsOpen && (
        <NotificationModal
          notifications={notifications}
          onClose={() => setNotificationsOpen(false)}
          onMarkAllAsRead={handleMarkAllRead}
          onNavigateTab={setCurrentTab}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <ThemeProvider>
        <AuthProvider>
          <MainApp />
        </AuthProvider>
      </ThemeProvider>
    </LanguageProvider>
  );
}
