import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  sendPasswordResetEmail,
  signOut,
  updateProfile as firebaseUpdateProfile,
  onAuthStateChanged,
  User as FirebaseUser,
} from 'firebase/auth';
import { doc, getDoc, setDoc, serverTimestamp, updateDoc } from 'firebase/firestore';
import { auth, db, googleProvider } from '../lib/firebase.js';
import { User } from '../types/index.js';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  isAdmin: boolean;
  login: (email: string, password?: string) => Promise<{ success: boolean; error?: string }>;
  register: (email: string, password?: string, displayName?: string) => Promise<{ success: boolean; error?: string }>;
  loginWithGoogle: (email?: string, name?: string) => Promise<{ success: boolean; error?: string }>;
  quickSwitchAccount: (target: 'admin' | 'user') => Promise<void>;
  logout: () => void;
  updateProfile: (data: Partial<User>) => Promise<boolean>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

function readableError(error: unknown): string {
  const code = (error as { code?: string })?.code || '';
  const messages: Record<string, string> = {
    'auth/invalid-credential': 'ইমেইল বা পাসওয়ার্ড সঠিক নয়।',
    'auth/user-not-found': 'এই ইমেইলে কোনো অ্যাকাউন্ট পাওয়া যায়নি।',
    'auth/wrong-password': 'পাসওয়ার্ড সঠিক নয়।',
    'auth/email-already-in-use': 'এই ইমেইল দিয়ে আগে থেকেই অ্যাকাউন্ট আছে।',
    'auth/weak-password': 'কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন।',
    'auth/invalid-email': 'সঠিক ইমেইল ঠিকানা দিন।',
    'auth/popup-closed-by-user': 'Google sign-in বন্ধ করা হয়েছে।',
    'auth/operation-not-allowed': 'Firebase Console-এ এই sign-in পদ্ধতি চালু করুন।',
    'auth/network-request-failed': 'ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।',
    'auth/too-many-requests': 'অনেকবার চেষ্টা হয়েছে। কিছুক্ষণ পরে আবার চেষ্টা করুন।',
  };
  return messages[code] || (error instanceof Error ? error.message : 'কাজটি সম্পন্ন করা যায়নি।');
}

async function makeAppUser(fbUser: FirebaseUser): Promise<User> {
  const ref = doc(db, 'users', fbUser.uid);
  const snap = await getDoc(ref);
  const tokenResult = await fbUser.getIdTokenResult(true);
  // Admin access comes only from a trusted Firebase custom claim, never a client-editable profile field.
  const role = tokenResult.claims.admin === true ? 'admin' : 'user';

  if (!snap.exists()) {
    await setDoc(ref, {
      displayName: fbUser.displayName || '',
      email: fbUser.email || '',
      avatarUrl: fbUser.photoURL || '',
      role: 'user',
      createdAt: serverTimestamp(),
    });
  } else {
    await setDoc(ref, {
      displayName: fbUser.displayName || snap.data().displayName || '',
      email: fbUser.email || '',
      avatarUrl: fbUser.photoURL || '',
      lastLoginAt: serverTimestamp(),
    }, { merge: true });
  }

  return {
    id: fbUser.uid,
    uid: fbUser.uid,
    email: fbUser.email || '',
    displayName: fbUser.displayName || '',
    name: fbUser.displayName || '',
    avatarUrl: fbUser.photoURL || '',
    photoURL: fbUser.photoURL || '',
    role,
  } as unknown as User;
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const syncUser = async (fbUser: FirebaseUser | null) => {
    if (!fbUser) {
      setUser(null);
      setToken(null);
      setIsLoading(false);
      return;
    }
    try {
      const idToken = await fbUser.getIdToken();
      const appUser = await makeAppUser(fbUser);
      setToken(idToken);
      setUser(appUser);
    } catch (e) {
      console.error('Firebase user sync failed:', e);
      setUser(null);
      setToken(null);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => onAuthStateChanged(auth, (fbUser) => { void syncUser(fbUser); }), []);

  const login = async (email: string, password?: string) => {
    if (!password) return { success: false, error: 'পাসওয়ার্ড দিন।' };
    try {
      await signInWithEmailAndPassword(auth, email.trim(), password);
      return { success: true };
    } catch (e) { return { success: false, error: readableError(e) }; }
  };

  const register = async (email: string, password?: string, displayName?: string) => {
    if (!password || password.length < 6) return { success: false, error: 'কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন।' };
    try {
      const credential = await createUserWithEmailAndPassword(auth, email.trim(), password);
      if (displayName?.trim()) await firebaseUpdateProfile(credential.user, { displayName: displayName.trim() });
      await setDoc(doc(db, 'users', credential.user.uid), {
        displayName: displayName?.trim() || '',
        email: credential.user.email || email.trim(),
        avatarUrl: credential.user.photoURL || '',
        role: 'user',
        createdAt: serverTimestamp(),
      }, { merge: true });
      await credential.user.getIdToken(true);
      return { success: true };
    } catch (e) { return { success: false, error: readableError(e) }; }
  };

  const loginWithGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
      return { success: true };
    } catch (e) { return { success: false, error: readableError(e) }; }
  };

  const quickSwitchAccount = async () => {
    // Deliberately disabled: demo account switching is not safe for a real platform.
    console.warn('Quick account switching is disabled. Sign in with your own account.');
  };

  const logout = () => { void signOut(auth); };

  const updateProfile = async (data: Partial<User>) => {
    const fbUser = auth.currentUser;
    if (!fbUser) return false;
    try {
      const patch: Record<string, unknown> = {};
      if (typeof data.displayName === 'string') patch.displayName = data.displayName;
      if (typeof data.name === 'string') patch.displayName = data.name;
      if (typeof data.avatarUrl === 'string') patch.avatarUrl = data.avatarUrl;
      if (typeof data.photoURL === 'string') patch.avatarUrl = data.photoURL;
      if (typeof data.displayName === 'string' || typeof data.name === 'string') {
        await firebaseUpdateProfile(fbUser, { displayName: String(data.displayName || data.name) });
      }
      if (typeof data.avatarUrl === 'string' || typeof data.photoURL === 'string') {
        await firebaseUpdateProfile(fbUser, { photoURL: String(data.avatarUrl || data.photoURL) });
      }
      if (Object.keys(patch).length) await updateDoc(doc(db, 'users', fbUser.uid), patch);
      await syncUser(fbUser);
      return true;
    } catch (e) {
      console.error('Profile update failed:', e);
      return false;
    }
  };

  const refreshUser = async () => {
    if (auth.currentUser) await syncUser(auth.currentUser);
  };

  const isAdmin = user?.role === 'admin';

  return (
    <AuthContext.Provider value={{ user, token, isLoading, isAdmin, login, register, loginWithGoogle, quickSwitchAccount, logout, updateProfile, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};

export async function sendResetEmail(email: string): Promise<{ success: boolean; error?: string }> {
  try {
    await sendPasswordResetEmail(auth, email.trim());
    return { success: true };
  } catch (e) { return { success: false, error: readableError(e) }; }
}
