import { initializeApp, getApp, getApps } from 'firebase/app';
import { getAnalytics, isSupported } from 'firebase/analytics';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || 'AIzaSyAZTl4ZxIx-UsbvboT-EQfdVzZh7Czmdy4',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || 'orvix-6198e.firebaseapp.com',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || 'orvix-6198e',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || 'orvix-6198e.firebasestorage.app',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '227388881654',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || '1:227388881654:web:91147b35dfc8597f764ad7',
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || 'G-745D3CZJ3W',
};

export const firebaseApp = getApps().length ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(firebaseApp);
export const db = getFirestore(firebaseApp);
export const googleProvider = new GoogleAuthProvider();

// Analytics is optional and may be unsupported in some browsers/previews.
export const analyticsReady = isSupported()
  .then((supported) => supported ? getAnalytics(firebaseApp) : null)
  .catch(() => null);
