import React, { useState } from 'react';
import { X, ExternalLink, Copy, Check, RotateCw, Monitor, Tablet, Smartphone, ShieldCheck } from 'lucide-react';
import { HostingProject } from '../types/index.js';

interface LiveSitePreviewModalProps {
  project: HostingProject | null;
  onClose: () => void;
}

export const LiveSitePreviewModal: React.FC<LiveSitePreviewModalProps> = ({ project, onClose }) => {
  const [viewport, setViewport] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [copied, setCopied] = useState(false);
  const [iframeKey, setIframeKey] = useState(0);

  if (!project) return null;

  // Real hosted URL on backend
  const liveUrl = `${window.location.origin}${project.publicUrl}`;

  const copyUrl = () => {
    navigator.clipboard.writeText(liveUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getViewportWidth = () => {
    switch (viewport) {
      case 'mobile':
        return 'max-w-[390px]';
      case 'tablet':
        return 'max-w-[768px]';
      default:
        return 'w-full';
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex flex-col p-2 sm:p-4 animate-in fade-in duration-200">
      {/* Top Bar */}
      <div className="bg-[#0b1120] border border-slate-800 rounded-2xl p-3 mb-2 flex items-center justify-between gap-3 shadow-2xl">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse shrink-0" />
          <div className="truncate">
            <h3 className="text-sm font-bold text-white truncate flex items-center gap-2">
              <span>{project.name}</span>
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-cyan-950 border border-cyan-800/80 text-cyan-300">
                {project.subdomain}
              </span>
            </h3>
            <p className="text-[11px] text-slate-400 font-mono truncate">{liveUrl}</p>
          </div>
        </div>

        {/* Viewport Toggles (Desktop / Tablet / Mobile) */}
        <div className="hidden md:flex items-center gap-1 bg-slate-900 border border-slate-800 p-1 rounded-xl">
          <button
            onClick={() => setViewport('desktop')}
            className={`p-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1.5 ${
              viewport === 'desktop' ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400 hover:text-white'
            }`}
            title="Desktop view"
          >
            <Monitor className="w-4 h-4" />
            <span className="text-[11px]">Desktop</span>
          </button>
          <button
            onClick={() => setViewport('tablet')}
            className={`p-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1.5 ${
              viewport === 'tablet' ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400 hover:text-white'
            }`}
            title="Tablet view (768px)"
          >
            <Tablet className="w-4 h-4" />
            <span className="text-[11px]">Tablet</span>
          </button>
          <button
            onClick={() => setViewport('mobile')}
            className={`p-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1.5 ${
              viewport === 'mobile' ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400 hover:text-white'
            }`}
            title="Mobile view (390px)"
          >
            <Smartphone className="w-4 h-4" />
            <span className="text-[11px]">Mobile</span>
          </button>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => setIframeKey((k) => k + 1)}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-cyan-300 transition"
            title="Reload website"
          >
            <RotateCw className="w-4 h-4" />
          </button>

          <button
            onClick={copyUrl}
            className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-slate-200 hover:text-white transition flex items-center gap-1.5"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-cyan-400" />}
            <span className="hidden sm:inline">{copied ? 'Copied!' : 'Copy Link'}</span>
          </button>

          <a
            href={project.publicUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition flex items-center gap-1.5 shadow-lg shadow-cyan-500/20"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Open Live</span>
          </a>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-900 hover:bg-rose-950/40 border border-slate-700 text-slate-400 hover:text-rose-400 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Frame Container */}
      <div className="flex-1 w-full flex items-center justify-center overflow-hidden">
        <div
          className={`h-full bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl transition-all duration-300 flex flex-col ${getViewportWidth()}`}
        >
          {/* Simulated Browser Address Bar */}
          <div className="bg-[#0f172a] px-4 py-2 border-b border-slate-800 flex items-center gap-2">
            <div className="flex gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
              <div className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
            </div>
            <div className="flex-1 mx-3 bg-[#070b14] px-3 py-1 rounded-lg border border-slate-800 text-[11px] font-mono text-slate-300 flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-emerald-400">
                <ShieldCheck className="w-3 h-3" />
                https://{project.subdomain}
              </span>
              <span className="text-[10px] text-slate-500">ORVIX CDN Edge</span>
            </div>
          </div>

          {/* Real Live Iframe */}
          <iframe
            key={iframeKey}
            src={project.publicUrl}
            title={project.name}
            className="w-full flex-1 border-0 bg-white"
            sandbox="allow-scripts allow-forms allow-same-origin allow-popups"
          />
        </div>
      </div>
    </div>
  );
};
