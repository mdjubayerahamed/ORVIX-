import React, { useEffect, useState } from 'react';
import { OrvixLogo } from './OrvixLogo.js';

interface LoadingScreenProps {
  onComplete: () => void;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(30);

  useEffect(() => {
    const timer1 = setTimeout(() => {
      setProgress(80);
    }, 120);

    const timer2 = setTimeout(() => {
      setProgress(100);
    }, 240);

    const timer3 = setTimeout(() => {
      onComplete();
    }, 380);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-50 bg-[#030712] flex flex-col items-center justify-center p-6 text-white overflow-hidden select-none transition-opacity duration-200">
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[450px] h-[450px] bg-gradient-to-tr from-cyan-500/20 via-blue-600/10 to-purple-600/20 rounded-full blur-3xl pointer-events-none animate-pulse-subtle" />

      {/* Grid texture */}
      <div className="absolute inset-0 bg-cyber-grid opacity-35 pointer-events-none" />

      <div className="relative z-10 flex flex-col items-center max-w-xs w-full text-center space-y-6">
        {/* Animated Brand Logo */}
        <div className="transform scale-110 transition-transform duration-300">
          <OrvixLogo size="lg" showTagline={true} animated={true} />
        </div>

        {/* Snappy Progress Bar */}
        <div className="w-full space-y-2 pt-2">
          <div className="w-full h-1 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
            <div
              className="h-full bg-gradient-to-r from-cyan-400 via-sky-400 to-purple-500 rounded-full transition-all duration-150 ease-out shadow-[0_0_12px_rgba(6,182,212,0.8)]"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex justify-between items-center text-[11px] font-mono text-slate-500">
            <span>Fast Cloud Init</span>
            <span className="text-cyan-400 font-bold">{progress}%</span>
          </div>
        </div>
      </div>
    </div>
  );
};
