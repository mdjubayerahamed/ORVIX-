import React, { useState } from 'react';
import { X, Copy, Check, AlertCircle, ArrowRight, ShieldCheck, Clock } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext.js';
import { useAuth } from '../context/AuthContext.js';

interface BkashPaymentModalProps {
  orderId: string;
  amountBdt: number;
  productTitle: string;
  onClose: () => void;
  onPaymentSubmitted: () => void;
}

export const BkashPaymentModal: React.FC<BkashPaymentModalProps> = ({
  orderId,
  amountBdt,
  productTitle,
  onClose,
  onPaymentSubmitted,
}) => {
  const { t, language } = useLanguage();
  const { token } = useAuth();
  const [senderNumber, setSenderNumber] = useState('');
  const [trxId, setTrxId] = useState('');
  const [copiedNumber, setCopiedNumber] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const bkashNumber = '01344495081';

  const copyBkashNumber = () => {
    navigator.clipboard.writeText(bkashNumber);
    setCopiedNumber(true);
    setTimeout(() => setCopiedNumber(false), 2000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!senderNumber || senderNumber.trim().length < 11) {
      setError(language === 'bn' ? 'সঠিক ১১ ডিজিটের বিকাশ নম্বর দিন।' : 'Please enter a valid 11-digit bKash number.');
      return;
    }

    if (!trxId || trxId.trim().length < 6) {
      setError(language === 'bn' ? 'সঠিক Transaction ID (TrxID) প্রদান করুন।' : 'Please enter a valid Transaction ID.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/payments/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          orderId,
          amountBdt,
          senderNumber: senderNumber.trim(),
          transactionId: trxId.trim().toUpperCase(),
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Payment submission failed.');
      }

      setSuccess(true);
      setTimeout(() => {
        onPaymentSubmitted();
      }, 1500);
    } catch (err: any) {
      setError(err.message || 'Error submitting payment details.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-[#0b1120] border border-slate-800 rounded-3xl max-w-lg w-full p-6 shadow-2xl relative overflow-hidden">
        {/* Top Accent Gradient */}
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-pink-500 via-rose-500 to-purple-600" />

        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-pink-600/20 border border-pink-500/30 flex items-center justify-center font-black text-pink-400 text-lg">
              ৳
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">{t('bkashTitle')}</h3>
              <p className="text-xs text-slate-400">Order: <span className="font-mono text-cyan-400 font-semibold">#{orderId}</span></p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {success ? (
          <div className="py-10 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto animate-bounce">
              <Check className="w-8 h-8" />
            </div>
            <h4 className="text-xl font-bold text-white">
              {language === 'bn' ? 'পেমেন্ট তথ্য সফলভাবে জমা হয়েছে!' : 'Payment Details Submitted!'}
            </h4>
            <p className="text-sm text-slate-300 max-w-sm mx-auto leading-relaxed">
              {t('paymentPendingNotice')}
            </p>
          </div>
        ) : (
          <div className="space-y-6 pt-4">
            {/* Amount Summary Box */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-400">{productTitle}</p>
                <p className="text-xs font-mono text-slate-500 mt-0.5">Order ID: {orderId}</p>
              </div>
              <div className="text-right">
                <span className="text-xs text-slate-400 block">{language === 'bn' ? 'পরিশোধযোগ্য টাকা' : 'Payable Amount'}</span>
                <span className="text-2xl font-black text-pink-400">৳ {amountBdt.toLocaleString()}</span>
              </div>
            </div>

            {/* bKash Instructions Box */}
            <div className="p-4 rounded-2xl bg-pink-950/20 border border-pink-900/40 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-pink-300 uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-pink-400" />
                  {t('bkashAccountType')}
                </span>
                <span className="text-xs font-semibold text-pink-400">Send Money</span>
              </div>

              {/* Number Copy Box */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/80 border border-pink-500/30">
                <span className="font-mono text-lg font-bold text-white tracking-widest">{bkashNumber}</span>
                <button
                  type="button"
                  onClick={copyBkashNumber}
                  className="px-3 py-1.5 rounded-lg bg-pink-600/30 hover:bg-pink-600/50 text-pink-300 text-xs font-bold flex items-center gap-1.5 transition"
                >
                  {copiedNumber ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedNumber ? 'কপি হয়েছে' : 'কপি করুন'}</span>
                </button>
              </div>

              {/* Steps Guide */}
              <div className="text-[12px] text-slate-300 space-y-1.5 pt-1">
                <p>{t('bkashStep1')}</p>
                <p>{t('bkashStep2')}</p>
                <p>{t('bkashStep3')}</p>
                <p>{t('bkashStep4')}</p>
                <p>{t('bkashStep5')}</p>
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-800/80 text-rose-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  {t('senderNumberLabel')} *
                </label>
                <input
                  type="tel"
                  placeholder="01XXXXXXXXX"
                  value={senderNumber}
                  onChange={(e) => setSenderNumber(e.target.value)}
                  required
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700/80 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-pink-500 transition"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  {t('trxIdLabel')} *
                </label>
                <input
                  type="text"
                  placeholder="e.g. BK8X92M4Q1"
                  value={trxId}
                  onChange={(e) => setTrxId(e.target.value)}
                  required
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700/80 text-white placeholder-slate-500 font-mono text-sm uppercase focus:outline-none focus:border-pink-500 transition"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-pink-500 via-rose-500 to-purple-600 hover:from-pink-400 hover:to-purple-500 text-white font-bold text-sm shadow-xl shadow-pink-500/25 transition disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <Clock className="w-4 h-4 animate-spin" />
                    <span>যাচাই করা হচ্ছে...</span>
                  </>
                ) : (
                  <>
                    <span>{t('submitPaymentBtn')}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
