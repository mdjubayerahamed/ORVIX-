import React from 'react';
import { Home, Server, Package, User, HelpCircle } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext.js';

interface MobileBottomNavProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  ordersBadge?: number;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  currentTab,
  setCurrentTab,
  ordersBadge = 0,
}) => {
  const { t } = useLanguage();

  const tabs = [
    { id: 'home', label: t('navHome'), icon: Home },
    { id: 'host', label: t('navHost'), icon: Server },
    { id: 'orders', label: t('navOrders'), icon: Package, badge: ordersBadge },
    { id: 'profile', label: t('navProfile'), icon: User },
    { id: 'support', label: t('navSupport'), icon: HelpCircle },
  ];

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#070b14]/95 backdrop-blur-xl border-t border-slate-800/90 pb-safe transition-all">
      <nav className="flex items-center justify-around h-16 max-w-lg mx-auto px-2">
        {tabs.map((tab) => {
          const isActive = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setCurrentTab(tab.id)}
              className={`flex flex-col items-center justify-center flex-1 py-1 relative transition-colors ${
                isActive ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <tab.icon
                  className={`w-5 h-5 transition-transform duration-200 ${
                    isActive ? 'scale-110 text-cyan-400 drop-shadow-[0_0_8px_rgba(6,182,212,0.8)]' : ''
                  }`}
                />
                {tab.badge && tab.badge > 0 ? (
                  <span className="absolute -top-1 -right-2 w-4 h-4 rounded-full bg-cyan-500 text-slate-950 font-bold text-[10px] flex items-center justify-center">
                    {tab.badge}
                  </span>
                ) : null}
              </div>

              <span
                className={`text-[11px] font-medium mt-1 truncate max-w-[65px] ${
                  isActive ? 'font-bold text-cyan-300' : 'text-slate-400'
                }`}
              >
                {tab.label}
              </span>

              {isActive && (
                <span className="absolute bottom-0 w-8 h-0.5 bg-gradient-to-r from-cyan-400 to-purple-500 rounded-full shadow-[0_0_8px_#22d3ee]" />
              )}
            </button>
          );
        })}
      </nav>
    </div>
  );
};
