import React from 'react';

interface OrvixLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'hero';
  showTagline?: boolean;
  showWordmark?: boolean;
  animated?: boolean;
  className?: string;
}

export const OrvixLogo: React.FC<OrvixLogoProps> = ({
  size = 'md',
  showTagline = false,
  showWordmark = true,
  animated = false,
  className = '',
}) => {
  // Dimensions mapping
  const sizeMap = {
    sm: { icon: 28, text: 'text-lg', dot: 'w-1 h-1', sub: 'text-[9px]' },
    md: { icon: 38, text: 'text-2xl', dot: 'w-1.5 h-1.5', sub: 'text-[11px]' },
    lg: { icon: 54, text: 'text-3xl', dot: 'w-2 h-2', sub: 'text-xs' },
    xl: { icon: 80, text: 'text-5xl', dot: 'w-2.5 h-2.5', sub: 'text-sm' },
    hero: { icon: 110, text: 'text-6xl', dot: 'w-3 h-3', sub: 'text-base' },
  };

  const current = sizeMap[size];

  return (
    <div className={`inline-flex flex-col items-center select-none ${className}`}>
      <div className="flex items-center gap-3">
        {/* Futuristic 3D Icon */}
        <div
          className={`relative flex items-center justify-center shrink-0 ${
            animated ? 'animate-pulse' : ''
          }`}
          style={{ width: current.icon, height: current.icon }}
        >
          {/* Subtle Ambient Glow */}
          <div
            className="absolute inset-0 rounded-full blur-md opacity-75"
            style={{
              background: 'radial-gradient(circle, rgba(0,210,255,0.4) 0%, rgba(168,85,247,0.4) 60%, transparent 100%)',
            }}
          />

          <svg
            viewBox="0 0 100 100"
            className="w-full h-full relative z-10 filter drop-shadow-[0_0_12px_rgba(0,210,255,0.5)]"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              {/* Outer Ring Gradient */}
              <linearGradient id="orvixRingGrad" x1="10%" y1="10%" x2="90%" y2="90%">
                <stop offset="0%" stopColor="#00f2fe" />
                <stop offset="35%" stopColor="#0072ff" />
                <stop offset="70%" stopColor="#7928ca" />
                <stop offset="100%" stopColor="#b829f7" />
              </linearGradient>

              {/* Inner Rim Light */}
              <linearGradient id="orvixRim" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ffffff" stopOpacity="0.8" />
                <stop offset="50%" stopColor="#00c6ff" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#a855f7" stopOpacity="0.1" />
              </linearGradient>

              {/* Angled Energy Blade */}
              <linearGradient id="bladeGrad" x1="0%" y1="100%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#00c6ff" stopOpacity="0.8" />
                <stop offset="45%" stopColor="#38bdf8" />
                <stop offset="80%" stopColor="#818cf8" />
                <stop offset="100%" stopColor="#c084fc" />
              </linearGradient>

              {/* Blade Glow */}
              <filter id="bladeGlow" x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="0" dy="0" stdDeviation="2.5" floodColor="#38bdf8" floodOpacity="0.9" />
              </filter>
            </defs>

            {/* Main Ring Outer */}
            <circle
              cx="50"
              cy="50"
              r="36"
              stroke="url(#orvixRingGrad)"
              strokeWidth="11"
              strokeLinecap="round"
            />

            {/* Metallic Inner Highlight */}
            <circle
              cx="50"
              cy="50"
              r="31"
              stroke="url(#orvixRim)"
              strokeWidth="1.5"
              fill="none"
            />

            {/* Center Dark Core with Soft Shadow */}
            <circle
              cx="50"
              cy="50"
              r="24"
              fill="#060913"
              className="dark:fill-[#070b14]"
            />

            {/* Dynamic Angled Slash Blade Crossing the Ring */}
            <path
              d="M 16 66 L 44 48 L 88 28 L 52 46 Z"
              fill="url(#bladeGrad)"
              filter="url(#bladeGlow)"
            />

            {/* High-speed Blade Spine Highlight */}
            <line
              x1="18"
              y1="65"
              x2="88"
              y2="28"
              stroke="#ffffff"
              strokeWidth="1.8"
              strokeLinecap="round"
              className="drop-shadow-[0_0_4px_#ffffff]"
            />
          </svg>
        </div>

        {/* Wordmark */}
        {showWordmark && (
          <div className="flex flex-col">
            <div className={`font-black tracking-wider leading-none ${current.text} flex items-center`}>
              <span className="text-white drop-shadow-[0_2px_10px_rgba(255,255,255,0.2)]">
                ORVI
              </span>
              <span className="bg-gradient-to-tr from-cyan-400 via-sky-300 to-purple-500 bg-clip-text text-transparent drop-shadow-[0_0_12px_rgba(6,182,212,0.6)]">
                X
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Tagline */}
      {showTagline && (
        <div className={`flex items-center gap-2 font-medium tracking-[0.25em] text-slate-300 uppercase mt-2 ${current.sub}`}>
          <span>Build</span>
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee]"></span>
          <span>Host</span>
          <span className="w-1.5 h-1.5 rounded-full bg-purple-500 shadow-[0_0_8px_#a855f7]"></span>
          <span>Grow</span>
        </div>
      )}
    </div>
  );
};
