import React from 'react';
import { X, CheckCheck, Bell, ExternalLink, Info, CheckCircle2, AlertTriangle, AlertCircle } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext.js';
import { NotificationItem } from '../types/index.js';

interface NotificationModalProps {
  notifications: NotificationItem[];
  onClose: () => void;
  onMarkAllAsRead: () => void;
  onNavigateTab: (tab: string) => void;
}

export const NotificationModal: React.FC<NotificationModalProps> = ({
  notifications,
  onClose,
  onMarkAllAsRead,
  onNavigateTab,
}) => {
  const { t, language } = useLanguage();

  const getIcon = (type: string) => {
    switch (type) {
      case 'success':
        return <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />;
      case 'warning':
        return <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />;
      case 'error':
        return <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />;
      default:
        return <Info className="w-4 h-4 text-cyan-400 shrink-0" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-[#0b1120] border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl relative max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-950/60 border border-cyan-800/80 flex items-center justify-center text-cyan-400">
              <Bell className="w-4 h-4" />
            </div>
            <h3 className="text-base font-bold text-white">{t('notificationsTitle')}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Action button */}
        {notifications.length > 0 && (
          <div className="pt-3 pb-2 flex justify-end">
            <button
              onClick={onMarkAllAsRead}
              className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1.5 transition"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span>{t('markAllRead')}</span>
            </button>
          </div>
        )}

        {/* Notifications list */}
        <div className="flex-1 overflow-y-auto space-y-2.5 py-2 pr-1">
          {notifications.length === 0 ? (
            <div className="py-12 text-center text-slate-400 space-y-2">
              <Bell className="w-8 h-8 mx-auto opacity-30" />
              <p className="text-xs">{t('noNotifications')}</p>
            </div>
          ) : (
            notifications.map((n) => {
              const title = language === 'bn' ? (n.titleBn || n.title) : n.title;
              const msg = language === 'bn' ? (n.messageBn || n.message) : n.message;

              return (
                <div
                  key={n.id}
                  className={`p-3.5 rounded-2xl border transition-all ${
                    !n.isRead
                      ? 'bg-slate-900/90 border-cyan-500/30 shadow-[0_0_15px_-4px_rgba(6,182,212,0.15)]'
                      : 'bg-slate-950/40 border-slate-800/60 opacity-80'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {getIcon(n.type)}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <h4 className="text-xs font-bold text-slate-200 truncate">{title}</h4>
                        <span className="text-[10px] text-slate-500 shrink-0 font-mono">
                          {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-[12px] text-slate-400 mt-1 leading-relaxed">{msg}</p>
                      {n.link && (
                        <button
                          onClick={() => {
                            if (n.link?.startsWith('/')) {
                              const tab = n.link.replace('/', '');
                              onNavigateTab(tab);
                              onClose();
                            } else {
                              window.open(n.link, '_blank');
                            }
                          }}
                          className="mt-2 text-[11px] font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition"
                        >
                          <span>{language === 'bn' ? 'দেখুন' : 'View'}</span>
                          <ExternalLink className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
