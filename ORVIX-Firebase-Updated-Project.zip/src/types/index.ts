export interface User {
  id: string;
  email: string;
  displayName: string;
  role: 'admin' | 'user';
  status: 'active' | 'suspended';
  avatarUrl: string;
  createdAt: string;
  quotaMB: number;
  usedStorageBytes: number;
  language: 'bn' | 'en';
  theme: 'dark' | 'light';
  isVerified: boolean;
}

export interface DeploymentRecord {
  id: string;
  projectId: string;
  version: number;
  status: 'Building' | 'Published' | 'Failed';
  fileCount: number;
  totalSizeBytes: number;
  deployedAt: string;
  notes?: string;
  log?: string;
}

export interface HostingProject {
  id: string;
  userId: string;
  userEmail: string;
  name: string;
  slug: string;
  subdomain: string;
  status: 'Published' | 'Building' | 'Failed' | 'Draft' | 'Suspended';
  currentVersion: number;
  totalSizeBytes: number;
  fileCount: number;
  customDomain?: string;
  customDomainVerified?: boolean;
  createdAt: string;
  updatedAt: string;
  deployments: DeploymentRecord[];
  publicUrl: string;
}

export interface MarketplaceProduct {
  id: string;
  title: string;
  titleBn: string;
  category: string;
  priceBdt: number;
  shortDesc: string;
  shortDescBn: string;
  fullDesc: string;
  fullDescBn: string;
  features: string[];
  featuresBn: string[];
  techStack: string[];
  demoUrl?: string;
  deliveryTime: string;
  deliveryTimeBn: string;
  imageUrl: string;
  isPublished: boolean;
  downloadUrl?: string;
  createdAt: string;
}

export interface CustomWebsiteRequest {
  id: string;
  orderId: string;
  userId: string;
  customerName: string;
  email: string;
  whatsapp?: string;
  siteType: string;
  features: string;
  designPreferences: string;
  referenceUrl?: string;
  budgetBdt: number;
  preferredDeadline: string;
  additionalInstructions?: string;
  status: 'Requested' | 'Quotation Sent' | 'Awaiting Payment' | 'In Progress' | 'Waiting for Customer' | 'Delivered' | 'Completed' | 'Cancelled' | 'Refunded';
  quotationAmountBdt?: number;
  adminNotes?: string;
  deliverableLink?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Order {
  id: string;
  orderId: string;
  userId: string;
  userEmail: string;
  productId?: string;
  productTitle: string;
  orderType: 'marketplace' | 'custom_service';
  amountBdt: number;
  paymentStatus: 'Awaiting Payment' | 'Submitted for Verification' | 'Verified' | 'Rejected' | 'Refunded';
  fulfillmentStatus: 'Pending' | 'In Progress' | 'Delivered' | 'Completed' | 'Cancelled';
  bKashTxId?: string;
  bKashSenderNumber?: string;
  paymentSubmittedAt?: string;
  adminVerificationNotes?: string;
  deliverableLink?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PaymentSubmission {
  id: string;
  orderId: string;
  userId: string;
  userEmail: string;
  amountBdt: number;
  senderNumber: string;
  transactionId: string;
  submittedAt: string;
  status: 'Submitted for Verification' | 'Verified' | 'Rejected';
  notes?: string;
  verifiedAt?: string;
  verifiedBy?: string;
}

export interface SupportTicket {
  id: string;
  ticketId: string;
  userId: string;
  userEmail: string;
  userName: string;
  subject: string;
  category: 'Hosting' | 'Marketplace' | 'Payment' | 'Custom Request' | 'Other';
  orderId?: string;
  status: 'Open' | 'In Progress' | 'Answered' | 'Closed';
  createdAt: string;
  updatedAt: string;
  messages: Array<{
    id: string;
    sender: 'user' | 'admin';
    senderName: string;
    message: string;
    timestamp: string;
  }>;
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  titleBn: string;
  message: string;
  messageBn: string;
  type: 'info' | 'success' | 'warning' | 'error';
  link?: string;
  isRead: boolean;
  createdAt: string;
}

export interface Announcement {
  id: string;
  title: string;
  titleBn: string;
  message: string;
  messageBn: string;
  badge: string;
  isActive: boolean;
  createdAt: string;
}

export interface AdminStats {
  totalUsers: number;
  activeUsers: number;
  totalProjects: number;
  publishedProjects: number;
  totalProducts: number;
  totalOrders: number;
  pendingPayments: number;
  openTickets: number;
  totalStorageBytes: number;
  bKashNumber: string;
  supportEmail: string;
}
