import React, { useState, useEffect } from 'react';
import {
  Package,
  Clock,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Download,
  CreditCard,
  FileCode2,
  RefreshCw,
  ArrowRight,
  ShieldCheck,
  Send
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext.js';
import { useAuth } from '../context/AuthContext.js';
import { Order, CustomWebsiteRequest } from '../types/index.js';

interface OrdersPageProps {
  onOpenBkashModal: (orderId: string, amount: number, title: string) => void;
  openAuthModal: () => void;
  onNavigateTab: (tab: string) => void;
}

export const OrdersPage: React.FC<OrdersPageProps> = ({
  onOpenBkashModal,
  openAuthModal,
  onNavigateTab,
}) => {
  const { t, language } = useLanguage();
  const { user, token } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [customRequests, setCustomRequests] = useState<CustomWebsiteRequest[]>([]);
  const [filterTab, setFilterTab] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  const fetchOrders = async () => {
    if (!token) {
      setLoading(false);
      return;
    }
    try {
      const res = await fetch('/api/orders', {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      setOrders(data.orders || []);
      setCustomRequests(data.customRequests || []);
    } catch (e) {
      console.error('Failed to load orders:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, [token]);

  const getPaymentStatusBadge = (status: string) => {
    switch (status) {
      case 'Verified':
        return (
          <span className="px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>{t('statusVerified')}</span>
          </span>
        );
      case 'Submitted for Verification':
        return (
          <span className="px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-400 text-xs font-bold flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 animate-pulse" />
            <span>{t('statusSubmittedVerification')}</span>
          </span>
        );
      case 'Rejected':
        return (
          <span className="px-3 py-1 rounded-full bg-rose-500/15 border border-rose-500/30 text-rose-400 text-xs font-bold flex items-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5" />
            <span>{t('statusRejected')}</span>
          </span>
        );
      default:
        return (
          <span className="px-3 py-1 rounded-full bg-pink-500/15 border border-pink-500/30 text-pink-400 text-xs font-bold flex items-center gap-1.5">
            <CreditCard className="w-3.5 h-3.5" />
            <span>{t('statusAwaitingPayment')}</span>
          </span>
        );
    }
  };

  if (!user) {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center space-y-4">
        <Package className="w-16 h-16 text-slate-600 mx-auto" />
        <h2 className="text-xl font-bold text-white">
          {language === 'bn' ? 'অর্ডার দেখতে লগইন করুন' : 'Sign in to view orders'}
        </h2>
        <p className="text-xs text-slate-400">
          {language === 'bn' ? 'আপনার ডিজিটাল কেনাকাটা এবং কাস্টম অর্ডারের অগ্রগতি দেখতে একাউন্টে প্রবেশ করুন।' : 'Track purchases and custom requests.'}
        </p>
        <button
          onClick={openAuthModal}
          className="px-6 py-2.5 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs"
        >
          {t('login')}
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8 pb-24">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-end gap-4 border-b border-slate-800 pb-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/60 border border-cyan-800/80 text-cyan-300 text-xs font-mono font-bold mb-2">
            <Package className="w-3.5 h-3.5" />
            <span>PURCHASES & COMMISSIONS</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-white">{t('ordersTitle')}</h1>
        </div>

        <button
          onClick={fetchOrders}
          className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition self-start sm:self-auto flex items-center gap-1.5 text-xs"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setFilterTab('all')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
            filterTab === 'all' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-white'
          }`}
        >
          All Orders ({orders.length + customRequests.length})
        </button>
        <button
          onClick={() => setFilterTab('marketplace')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
            filterTab === 'marketplace' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-white'
          }`}
        >
          Marketplace ({orders.length})
        </button>
        <button
          onClick={() => setFilterTab('custom')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
            filterTab === 'custom' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-white'
          }`}
        >
          Custom Requests ({customRequests.length})
        </button>
      </div>

      {/* Orders List */}
      <div className="space-y-4">
        {filterTab !== 'custom' &&
          orders.map((order) => (
            <div
              key={order.id}
              className="p-6 rounded-3xl bg-[#0b1120] border border-slate-800 hover:border-slate-700 transition space-y-4 shadow-xl"
            >
              <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-cyan-950/60 border border-cyan-800/80 text-cyan-400 flex items-center justify-center font-bold text-xs">
                    PKG
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">{order.productTitle}</h3>
                    <p className="text-xs font-mono text-slate-400">
                      ID: <span className="text-cyan-400 font-semibold">{order.orderId}</span> • {new Date(order.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <span className="text-xl font-black text-pink-400 font-mono">৳ {order.amountBdt.toLocaleString()}</span>
                  {getPaymentStatusBadge(order.paymentStatus)}
                </div>
              </div>

              {/* bKash Payment Details / Feedback */}
              {order.bKashTxId && (
                <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 text-xs font-mono text-slate-300 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-4">
                    <span>Sender: <strong>{order.bKashSenderNumber}</strong></span>
                    <span>TrxID: <strong className="text-pink-400">{order.bKashTxId}</strong></span>
                  </div>
                  {order.adminVerificationNotes && (
                    <span className="text-slate-400 text-[11px]">Note: {order.adminVerificationNotes}</span>
                  )}
                </div>
              )}

              {/* Action Buttons */}
              <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-slate-800/80">
                <div className="text-xs text-slate-400">
                  Fulfillment: <strong className="text-white">{order.fulfillmentStatus}</strong>
                </div>

                <div className="flex items-center gap-2">
                  {order.paymentStatus === 'Awaiting Payment' && (
                    <button
                      onClick={() => onOpenBkashModal(order.orderId, order.amountBdt, order.productTitle)}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-400 hover:to-rose-500 text-white font-bold text-xs shadow-lg shadow-pink-500/20 flex items-center gap-1.5"
                    >
                      <CreditCard className="w-3.5 h-3.5" />
                      <span>{t('payWithBkash')} (01344495081)</span>
                    </button>
                  )}

                  {order.paymentStatus === 'Submitted for Verification' && (
                    <span className="text-xs text-amber-300 font-mono py-1 px-2 rounded bg-amber-950/30 border border-amber-900/40">
                      Payment submitted. Verification in progress.
                    </span>
                  )}

                  {order.deliverableLink && (
                    <a
                      href={order.deliverableLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition flex items-center gap-1.5 shadow-lg shadow-emerald-500/20"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>{t('downloadDeliverable')}</span>
                    </a>
                  )}
                </div>
              </div>
            </div>
          ))}

        {/* Custom Requests List */}
        {filterTab !== 'marketplace' &&
          customRequests.map((req) => (
            <div
              key={req.id}
              className="p-6 rounded-3xl bg-[#0b1120] border border-purple-500/30 space-y-4 shadow-xl"
            >
              <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-purple-950/60 border border-purple-800 text-purple-400 flex items-center justify-center font-bold text-xs">
                    REQ
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">{req.siteType}</h3>
                    <p className="text-xs font-mono text-slate-400">
                      ID: <span className="text-purple-400 font-semibold">{req.orderId}</span> • {new Date(req.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-xs font-bold text-slate-300">
                    Budget: <strong className="text-white font-mono">৳ {req.budgetBdt.toLocaleString()}</strong>
                  </span>
                  <span className="px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 text-xs font-bold border border-purple-500/30">
                    {req.status}
                  </span>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 text-xs text-slate-300 space-y-2">
                <p><strong>Requirements:</strong> {req.features}</p>
                {req.adminNotes && (
                  <p className="text-cyan-300 pt-1 border-t border-slate-800">
                    <strong>ORVIX Engineering Lead Note:</strong> {req.adminNotes}
                  </p>
                )}
                {req.quotationAmountBdt && (
                  <p className="text-pink-400 font-bold font-mono">
                    Official Quotation: ৳ {req.quotationAmountBdt.toLocaleString()}
                  </p>
                )}
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <a
                  href={`https://wa.me/8801344495081?text=Hello%20ORVIX,%20following%20up%20on%20quote%20${req.orderId}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-200 text-xs font-semibold hover:text-white transition flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Chat on WhatsApp</span>
                </a>
              </div>
            </div>
          ))}

        {orders.length === 0 && customRequests.length === 0 && (
          <div className="p-16 text-center bg-slate-900/30 border border-slate-800 rounded-3xl space-y-4">
            <Package className="w-12 h-12 text-slate-600 mx-auto" />
            <h3 className="text-base font-bold text-white">No Orders Yet</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              Ready to launch your digital store or commission an application? Explore our marketplace or request a custom quote.
            </p>
            <div className="flex justify-center gap-3 pt-2">
              <button
                onClick={() => onNavigateTab('marketplace')}
                className="px-4 py-2 rounded-xl bg-purple-600 text-white font-bold text-xs"
              >
                Explore Marketplace
              </button>
              <button
                onClick={() => onNavigateTab('custom-request')}
                className="px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-200 font-bold text-xs"
              >
                Custom Order
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
