import React, { useState, useEffect, useRef } from 'react';
import {
  Server,
  FileCode,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  RotateCcw,
  Sparkles,
  RefreshCw,
  ShieldCheck,
  Eye,
  ArrowUpRight,
  Code2,
  Infinity as InfinityIcon,
  Check,
  Trash2,
  Globe
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useLanguage } from '../context/LanguageContext.js';
import { useAuth } from '../context/AuthContext.js';
import { HostingProject } from '../types/index.js';

interface HostSitePageProps {
  onPreviewProject: (proj: HostingProject) => void;
  openAuthModal: () => void;
}

export const HostSitePage: React.FC<HostSitePageProps> = ({ onPreviewProject, openAuthModal }) => {
  const { t, language } = useLanguage();
  const { user, token } = useAuth();
  const [projects, setProjects] = useState<HostingProject[]>([]);
  const [loading, setLoading] = useState(true);

  // Deploy Form State - Strictly HTML file only
  const [projectName, setProjectName] = useState('');
  const [slug, setSlug] = useState('');
  const [slugAvailable, setSlugAvailable] = useState<boolean | null>(null);
  const [checkingSlug, setCheckingSlug] = useState(false);
  const [htmlContent, setHtmlContent] = useState<string>('');
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  const [totalSizeKb, setTotalSizeKb] = useState<number>(0);
  const [lineCount, setLineCount] = useState<number>(0);
  const [deployStep, setDeployStep] = useState<'idle' | 'validating' | 'building' | 'published' | 'failed'>('idle');
  const [deployError, setDeployError] = useState<string | null>(null);
  const [deployedProject, setDeployedProject] = useState<HostingProject | null>(null);
  const [showHtmlPreview, setShowHtmlPreview] = useState(false);

  // Updating existing project state
  const [updatingProjectId, setUpdatingProjectId] = useState<string | null>(null);

  // Rollback Modal State
  const [rollbackProjectTarget, setRollbackProjectTarget] = useState<HostingProject | null>(null);
  const [selectedRollbackVersion, setSelectedRollbackVersion] = useState<number>(1);
  const [rollingBack, setRollingBack] = useState(false);

  // Custom Domain State
  const [customDomainTarget, setCustomDomainTarget] = useState<HostingProject | null>(null);
  const [customDomainInput, setCustomDomainInput] = useState('');
  const [customDomainResult, setCustomDomainResult] = useState<any>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Fetch projects
  const fetchProjects = async () => {
    try {
      const res = await fetch('/api/hosting/projects', {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      const data = await res.json();
      setProjects(data.projects || []);
    } catch (e) {
      console.error('Failed to load projects:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, [token]);

  // Slug auto-generator and checker
  useEffect(() => {
    if (updatingProjectId) return; // don't change slug during update
    const autoSlug = projectName.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
    setSlug(autoSlug);
  }, [projectName, updatingProjectId]);

  useEffect(() => {
    if (!slug || slug.length < 3) {
      setSlugAvailable(null);
      return;
    }

    const timer = setTimeout(async () => {
      setCheckingSlug(true);
      try {
        const res = await fetch(`/api/hosting/check-slug?slug=${encodeURIComponent(slug)}`);
        const data = await res.json();
        setSlugAvailable(data.available);
      } catch {
        setSlugAvailable(null);
      } finally {
        setCheckingSlug(false);
      }
    }, 250);

    return () => clearTimeout(timer);
  }, [slug]);

  // File Upload Handler (Strictly HTML files only)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processHtmlFile(file);
  };

  const processHtmlFile = (file: File) => {
    setDeployError(null);
    const isHtml = file.name.toLowerCase().endsWith('.html') || file.name.toLowerCase().endsWith('.htm');

    if (!isHtml) {
      setDeployError(
        language === 'bn'
          ? 'শুধুমাত্র .html ফাইল আপলোড গ্রহণযোগ্য (যেমন: index.html)।'
          : 'Only .html files are supported (e.g. index.html).'
      );
      return;
    }

    setUploadedFileName(file.name);
    setTotalSizeKb(Math.max(0.1, Number((file.size / 1024).toFixed(1))));

    const reader = new FileReader();
    reader.onload = () => {
      const text = reader.result as string;
      setHtmlContent(text);
      setLineCount(text.split('\n').length);
    };
    reader.readAsText(file);
  };

  // 1-Click Starter HTML Templates
  const handleLoadStarter = (type: 'portfolio' | 'agency') => {
    if (type === 'portfolio') {
      const code = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Creative Portfolio | Live on ORVIX</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#090d16] text-slate-100 min-h-screen flex items-center justify-center p-6 font-sans">
  <div class="max-w-lg w-full bg-slate-900/90 p-8 rounded-3xl border border-cyan-500/30 text-center space-y-6 shadow-2xl">
    <div class="w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-400 to-purple-600 mx-auto flex items-center justify-center text-2xl font-black text-slate-950">
      ⚡
    </div>
    <h1 class="text-3xl font-black text-white">Hi, I'm a Creator</h1>
    <p class="text-slate-300 text-sm leading-relaxed">
      Welcome to my personal static website! Deployed seamlessly via ORVIX free edge cloud hosting.
    </p>
    <div class="flex justify-center gap-3">
      <span class="px-3 py-1 rounded-full bg-cyan-950 text-cyan-400 text-xs font-mono font-bold">Fast CDN</span>
      <span class="px-3 py-1 rounded-full bg-purple-950 text-purple-400 text-xs font-mono font-bold">Unlimited Storage</span>
    </div>
  </div>
</body>
</html>`;
      setProjectName('My Creative Portfolio');
      setHtmlContent(code);
      setUploadedFileName('starter-portfolio.html');
      setTotalSizeKb(1.2);
      setLineCount(code.split('\n').length);
    } else {
      const code = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>HyperPulse Agency | ORVIX Host</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#050811] text-slate-200 min-h-screen p-8 flex flex-col justify-between font-sans">
  <header class="flex justify-between items-center max-w-4xl mx-auto w-full border-b border-slate-800 pb-4">
    <div class="text-xl font-black text-cyan-400">HYPER<span class="text-purple-400">PULSE</span></div>
    <span class="text-xs text-slate-400 font-mono">Live on ORVIX</span>
  </header>
  <main class="max-w-4xl mx-auto text-center space-y-4 my-16">
    <h1 class="text-4xl sm:text-6xl font-black text-white">Digital Craftsmanship</h1>
    <p class="text-slate-400 text-base max-w-xl mx-auto">We engineer digital products with speed, elegance, and scale.</p>
  </main>
  <footer class="text-center text-xs text-slate-600">© 2026 HyperPulse. Hosted Free on ORVIX.</footer>
</body>
</html>`;
      setProjectName('HyperPulse Agency');
      setHtmlContent(code);
      setUploadedFileName('starter-agency.html');
      setTotalSizeKb(1.5);
      setLineCount(code.split('\n').length);
    }
  };

  // Deploy Action
  const handleDeploy = async () => {
    if (!user) {
      openAuthModal();
      return;
    }

    if (!projectName.trim()) {
      setDeployError(language === 'bn' ? 'অনুগ্রহ করে প্রজেক্টের নাম লিখুন।' : 'Please enter project name.');
      return;
    }

    if (!htmlContent.trim()) {
      setDeployError(language === 'bn' ? 'অনুগ্রহ করে একটি .html ফাইল আপলোড করুন।' : 'Please upload an HTML file.');
      return;
    }

    setDeployError(null);
    setDeployStep('validating');

    setTimeout(async () => {
      setDeployStep('building');
      try {
        const payload = {
          projectName: projectName.trim(),
          slug: slug.trim(),
          files: [
            {
              path: 'index.html',
              content: htmlContent,
              isBase64: false,
            }
          ],
          notes: updatingProjectId ? 'Updated HTML version' : 'Initial launch',
          projectId: updatingProjectId || undefined,
        };

        const res = await fetch('/api/hosting/deploy', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(payload),
        });

        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || 'Deployment failed');
        }

        setDeployStep('published');
        setDeployedProject(data.project);
        confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
        fetchProjects();

        // Reset inputs
        setProjectName('');
        setHtmlContent('');
        setUploadedFileName(null);
        setUpdatingProjectId(null);
      } catch (err: any) {
        setDeployStep('failed');
        setDeployError(err.message || 'Error occurred during deployment');
      }
    }, 450);
  };

  // Start Update
  const handleStartUpdate = (p: HostingProject) => {
    setUpdatingProjectId(p.id);
    setProjectName(p.name);
    setSlug(p.slug);
    setDeployStep('idle');
    setDeployedProject(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Rollback Action
  const handleRollback = async () => {
    if (!rollbackProjectTarget) return;
    setRollingBack(true);
    try {
      const res = await fetch('/api/hosting/rollback', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          projectId: rollbackProjectTarget.id,
          targetVersion: selectedRollbackVersion,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Rollback failed');

      alert(language === 'bn' ? 'সফলভাবে আগের ভার্সনে রোলব্যাক করা হয়েছে!' : 'Successfully rolled back to earlier version!');
      setRollbackProjectTarget(null);
      fetchProjects();
    } catch (err: any) {
      alert(err.message || 'Rollback error');
    } finally {
      setRollingBack(false);
    }
  };

  // Delete Action
  const handleDeleteProject = async (p: HostingProject) => {
    const confirmMsg = language === 'bn'
      ? `আপনি কি নিশ্চিত "${p.name}" (${p.subdomain}) স্থায়ীভাবে মুছে ফেলতে চান?`
      : `Are you sure you want to permanently delete "${p.name}" (${p.subdomain})?`;

    if (!window.confirm(confirmMsg)) return;

    try {
      const res = await fetch(`/api/hosting/projects/${p.id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        fetchProjects();
      }
    } catch (e) {
      console.error('Delete project failed:', e);
    }
  };

  // Custom Domain Configuration
  const handleSaveCustomDomain = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customDomainTarget || !customDomainInput) return;

    try {
      const res = await fetch('/api/hosting/custom-domain', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          projectId: customDomainTarget.id,
          domain: customDomainInput,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setCustomDomainResult(data);
        fetchProjects();
      }
    } catch (err) {
      console.error('Custom domain error:', err);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-12 pb-24">
      {/* Header with Scroll Animation */}
      <div
        className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 border-b border-slate-800 pb-6 animate-fade-up"
      >
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/60 border border-cyan-800/80 text-cyan-300 text-xs font-mono font-bold mb-2 animate-border-glow">
            <Server className="w-3.5 h-3.5 text-cyan-400" />
            <span>ORVIX FREE HOSTING CLOUD</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-white">{t('hostTitle')}</h1>
          <p className="text-slate-400 text-sm mt-1">{t('hostSubtitle')}</p>
        </div>

        {/* Storage status - Completely Unlimited */}
        <div className="bg-[#090e1d]/90 border border-cyan-500/30 px-5 py-3 rounded-2xl flex items-center gap-3 text-xs shadow-lg backdrop-blur-md interactive-card">
          <div className="w-8 h-8 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <InfinityIcon className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <span className="text-slate-400 block text-[11px] font-medium">
              {language === 'bn' ? 'হোস্টিং স্টোরেজ' : 'Cloud Storage'}
            </span>
            <span className="font-bold text-cyan-300 font-mono text-xs">
              {language === 'bn' ? 'আনলিমিটেড স্টোরেজ (নো লিমিট)' : 'Unlimited Free (No Limits)'}
            </span>
          </div>
        </div>
      </div>

      {/* Deploy Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Form (8 cols) */}
        <div
          className="lg:col-span-8 space-y-6 animate-fade-up"
        >
          <div className="bg-[#090e1d]/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden backdrop-blur-xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-6">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-cyan-400" />
                <span>
                  {updatingProjectId
                    ? (language === 'bn' ? `ওয়েবসাইট আপডেট: ${projectName}` : `Update Website: ${projectName}`)
                    : (language === 'bn' ? 'HTML ওয়েবসাইট আপলোড ও ডিপ্লয়' : 'HTML Website Deployment')}
                </span>
              </h2>
              {updatingProjectId && (
                <button
                  onClick={() => { setUpdatingProjectId(null); setProjectName(''); }}
                  className="text-xs text-rose-400 hover:underline cursor-pointer"
                >
                  Cancel Update
                </button>
              )}
            </div>

            {/* Error banner */}
            {deployError && (
              <div className="p-4 mb-6 rounded-2xl bg-rose-950/40 border border-rose-800 text-rose-300 text-xs flex items-center gap-3">
                <AlertCircle className="w-5 h-5 shrink-0" />
                <span>{deployError}</span>
              </div>
            )}

            {/* Success Card when published */}
            {deployStep === 'published' && deployedProject && (
              <div className="p-6 mb-6 rounded-2xl bg-cyan-950/30 border border-cyan-500/40 space-y-4 animate-in zoom-in-95">
                <div className="flex items-center gap-3 text-emerald-400 font-bold">
                  <CheckCircle2 className="w-6 h-6" />
                  <span className="text-base">
                    {language === 'bn' ? 'সাইট সফলভাবে ডিপ্লয় হয়েছে!' : 'Deployment Published Successfully!'}
                  </span>
                </div>
                <div className="p-3 bg-slate-950/80 rounded-xl border border-cyan-500/30 flex items-center justify-between">
                  <span className="font-mono text-cyan-300 text-sm font-semibold truncate">
                    https://{deployedProject.subdomain}
                  </span>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => onPreviewProject(deployedProject)}
                      className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>{language === 'bn' ? 'প্রিভিউ' : 'Preview'}</span>
                    </button>
                    <a
                      href={deployedProject.publicUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              </div>
            )}

            {/* Form Fields */}
            <div className="space-y-5">
              {/* Project Name */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                  {t('projectNameLabel')} *
                </label>
                <input
                  type="text"
                  placeholder={t('projectNamePlaceholder')}
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  disabled={!!updatingProjectId}
                  className="w-full px-4 py-3 rounded-2xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-500 transition"
                />
              </div>

              {/* Subdomain slug preview */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                  {t('slugLabel')}
                </label>
                <div className="flex items-center">
                  <div className="flex-1 px-4 py-3 rounded-l-2xl bg-slate-900/90 border border-r-0 border-slate-700 text-sm font-mono text-cyan-300 truncate">
                    {slug || 'your-project-name'}
                  </div>
                  <div className="px-4 py-3 rounded-r-2xl bg-slate-800 border border-slate-700 text-xs font-mono font-bold text-slate-400">
                    .orvix
                  </div>
                </div>

                <div className="mt-1.5 flex items-center justify-between text-[11px] font-mono">
                  {checkingSlug ? (
                    <span className="text-slate-400">{t('slugChecking')}</span>
                  ) : slugAvailable === true ? (
                    <span className="text-emerald-400 flex items-center gap-1">
                      <Check className="w-3 h-3" />
                      {t('slugAvailable')}
                    </span>
                  ) : slugAvailable === false && !updatingProjectId ? (
                    <span className="text-rose-400">{t('slugTaken')}</span>
                  ) : (
                    <span className="text-slate-500">Free Subdomain Included</span>
                  )}
                  <span className="text-cyan-400 font-mono">Unlimited Storage</span>
                </div>
              </div>

              {/* Upload Dropzone - STRICTLY HTML FILE ONLY */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                    {language === 'bn' ? 'HTML ফাইল আপলোড (index.html)' : 'Upload HTML File (.html only)'} *
                  </label>
                  <span className="text-[11px] text-cyan-400 font-mono font-medium">
                    {language === 'bn' ? 'শুধু .html ফাইল সমর্থিত' : 'Strictly .html files'}
                  </span>
                </div>

                <div
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-3xl p-8 text-center cursor-pointer transition-all duration-200 ${
                    uploadedFileName
                      ? 'border-cyan-500 bg-cyan-950/20 shadow-[0_0_25px_rgba(6,182,212,0.18)]'
                      : 'border-slate-700/80 hover:border-cyan-500/60 bg-slate-900/40 hover:bg-slate-900/70'
                  }`}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".html,.htm"
                    onChange={handleFileUpload}
                    className="hidden"
                  />

                  {uploadedFileName ? (
                    <div className="space-y-3">
                      <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center mx-auto shadow-md shadow-cyan-500/20">
                        <FileCode className="w-6 h-6" />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-white font-mono">{uploadedFileName}</p>
                        <p className="text-xs text-cyan-400 font-mono mt-1">
                          {totalSizeKb} KB • {lineCount} lines • HTML Validated
                        </p>
                      </div>
                      <p className="text-[11px] text-slate-400">Click to change HTML file</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="w-12 h-12 rounded-2xl bg-cyan-950/40 border border-cyan-800/40 text-cyan-400 flex items-center justify-center mx-auto">
                        <FileCode className="w-6 h-6" />
                      </div>
                      <p className="text-sm font-bold text-slate-200">
                        {language === 'bn' ? 'এখানে আপনার .html ফাইল ড্রপ করুন' : 'Drop your .html file here'}
                      </p>
                      <p className="text-xs text-slate-400">
                        {language === 'bn' ? 'বা ফাইল নির্বাচন করতে ক্লিক করুন (আনলিমিটেড স্টোরেজ)' : 'or click to browse HTML file (Unlimited storage)'}
                      </p>
                    </div>
                  )}
                </div>

                {/* HTML Code Preview Toggle */}
                {htmlContent && (
                  <div className="mt-3">
                    <button
                      type="button"
                      onClick={() => setShowHtmlPreview(!showHtmlPreview)}
                      className="text-xs text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1 cursor-pointer"
                    >
                      <Code2 className="w-3.5 h-3.5" />
                      <span>{showHtmlPreview ? 'Hide HTML Code' : 'Preview HTML Code'} ({lineCount} lines)</span>
                    </button>

                    {showHtmlPreview && (
                      <div className="mt-2 p-3 bg-slate-950 rounded-2xl border border-slate-800 max-h-48 overflow-y-auto font-mono text-[11px] text-slate-300 leading-relaxed">
                        <pre>{htmlContent.slice(0, 1500)}{htmlContent.length > 1500 ? '\n... (truncated)' : ''}</pre>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Starter HTML Templates */}
              <div className="pt-2">
                <span className="text-xs text-slate-400 block mb-2 font-medium">{t('starterTemplatesTitle')}</span>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => handleLoadStarter('portfolio')}
                    className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 text-left transition group cursor-pointer"
                  >
                    <span className="text-xs font-bold text-white group-hover:text-cyan-300 block">
                      ⚡ {t('templateDev')}
                    </span>
                    <span className="text-[11px] text-slate-400">1-Click HTML Template</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleLoadStarter('agency')}
                    className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 text-left transition group cursor-pointer"
                  >
                    <span className="text-xs font-bold text-white group-hover:text-purple-300 block">
                      🚀 {t('templateAgency')}
                    </span>
                    <span className="text-[11px] text-slate-400">1-Click Agency Showcase</span>
                  </button>
                </div>
              </div>

              {/* Deploy Button */}
              <button
                type="button"
                onClick={handleDeploy}
                disabled={deployStep === 'validating' || deployStep === 'building'}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-cyan-500 via-sky-400 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-base shadow-xl shadow-cyan-500/25 transition disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
              >
                {deployStep === 'validating' || deployStep === 'building' ? (
                  <>
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    <span>{t('deploying')}</span>
                  </>
                ) : (
                  <>
                    <span>
                      {updatingProjectId
                        ? (language === 'bn' ? 'আপডেট ডিপ্লয় করুন 🚀' : 'Deploy Update 🚀')
                        : (language === 'bn' ? 'HTML সাইট ডিপ্লয় করুন 🚀' : 'Deploy HTML Site 🚀')}
                    </span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Right Info Sidebar (4 cols) with Scroll Animation */}
        <div
          className="lg:col-span-4 space-y-6 animate-fade-up"
        >
          {/* Hosting Advantages Card */}
          <div className="bg-[#090e1d]/90 border border-slate-800 rounded-3xl p-6 space-y-4 backdrop-blur-xl">
            <h3 className="text-sm font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4" />
              <span>{language === 'bn' ? 'হোস্টিং সুবিধা ও নিয়ম' : 'Hosting Advantages'}</span>
            </h3>

            <div className="space-y-3.5 text-xs text-slate-300 leading-relaxed">
              <div className="flex items-start gap-2.5">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Pure HTML Upload:</strong> {language === 'bn' ? 'শুধুমাত্র আপনার .html ফাইল আপলোড করেই সম্পূর্ণ সাইট লাইভ করুন।' : 'Direct HTML processing for seamless instant hosting.'}
                </span>
              </div>
              <div className="flex items-start gap-2.5">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Unlimited Cloud Storage:</strong> {language === 'bn' ? 'কোনো স্টোরেজ লিমিট নেই—স্বচ্ছন্দে যেকোনো আকারের ফাইল হোস্ট করুন।' : 'Zero storage limit. Host and update without quota worries.'}
                </span>
              </div>
              <div className="flex items-start gap-2.5">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Same-URL Updates:</strong> {language === 'bn' ? 'সাইটের কোড পরিবর্তন করলে লিংক অপরিবর্তিত থাকবে।' : 'Keep identical public URL across all version updates.'}
                </span>
              </div>
              <div className="flex items-start gap-2.5">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Instant Rollback:</strong> {language === 'bn' ? 'যেকোনো সময় পূর্ববর্তী সফল ডিপ্লয়মেন্টে ফিরে যান।' : 'Roll back to any previous version with 1-click.'}
                </span>
              </div>
            </div>
          </div>

          {/* Need Custom Development Help */}
          <div className="p-6 rounded-3xl bg-gradient-to-br from-purple-950/40 to-slate-900 border border-purple-500/30 space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Code2 className="w-4 h-4 text-purple-400" />
              <span>{language === 'bn' ? 'ওয়েবসাইট বানাতে সাহায্য চান?' : 'Need Help Building a Site?'}</span>
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              {language === 'bn'
                ? 'আমাদের প্রফেশনাল টিম আপনার রিকোয়ারমেন্ট অনুযায়ী সম্পূর্ণ ওয়েবসাইট বা অ্যান্ড্রয়েড অ্যাপ তৈরি করে দিবে।'
                : 'Our engineering team can build your custom website or convert it to an Android App with bKash integration.'}
            </p>
            <a
              href="https://wa.me/8801344495081"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-xs font-bold text-cyan-300 hover:text-cyan-200 pt-1"
            >
              <span>WhatsApp: 01344495081</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>

      {/* Projects Management Section */}
      <div
        className="space-y-6 pt-6 animate-fade-up"
      >
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div>
            <h2 className="text-2xl font-black text-white">
              {language === 'bn' ? 'আমার হোস্টকৃত ওয়েবসাইটসমূহ' : 'Hosted Projects'}
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              {language === 'bn' ? 'লাইভ সাইট দেখুন, কোড আপডেট করুন বা রোলব্যাক চালান' : 'Manage your active deployments and domains'}
            </p>
          </div>
          <span className="text-xs font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-800/80 px-3 py-1 rounded-xl">
            {projects.length} Total Projects
          </span>
        </div>

        {projects.length === 0 ? (
          <div className="p-12 text-center bg-[#090e1d]/50 border border-slate-800 rounded-3xl space-y-3">
            <Server className="w-10 h-10 text-slate-600 mx-auto" />
            <p className="text-slate-400 text-sm">{t('noProjectsYet')}</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((proj) => {
              return (
                <div
                  key={proj.id}
                  className="p-6 rounded-3xl bg-[#090e1d]/90 border border-slate-800 hover:border-cyan-500/40 transition flex flex-col justify-between space-y-5"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[11px] font-mono font-bold flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                        v{proj.currentVersion} {proj.status}
                      </span>
                      <span className="text-[11px] font-mono text-cyan-400">
                        Unlimited Storage
                      </span>
                    </div>

                    <div>
                      <h3 className="text-lg font-bold text-white truncate">{proj.name}</h3>
                      <p className="text-xs font-mono text-cyan-400 truncate mt-0.5">https://{proj.subdomain}</p>
                      {proj.customDomain && (
                        <p className="text-[11px] font-mono text-purple-300 mt-1 flex items-center gap-1">
                          <Globe className="w-3 h-3 text-purple-400" />
                          <span>{proj.customDomain}</span>
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Actions Bar */}
                  <div className="space-y-2 pt-3 border-t border-slate-800/80">
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => onPreviewProject(proj)}
                        className="px-3 py-2 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>{t('actionVisit')}</span>
                      </button>

                      <a
                        href={proj.publicUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-bold transition flex items-center justify-center gap-1.5"
                      >
                        <span>Open Tab</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>

                    <div className="flex items-center justify-between pt-1 text-slate-400 text-xs">
                      {/* Update Button */}
                      <button
                        onClick={() => handleStartUpdate(proj)}
                        className="hover:text-cyan-400 flex items-center gap-1 transition cursor-pointer"
                        title="Upload new HTML version without changing URL"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>{t('actionUpdate')}</span>
                      </button>

                      {/* Rollback */}
                      {proj.deployments && proj.deployments.length > 1 && (
                        <button
                          onClick={() => {
                            setRollbackProjectTarget(proj);
                            setSelectedRollbackVersion(proj.deployments[1]?.version || 1);
                          }}
                          className="hover:text-amber-400 flex items-center gap-1 transition cursor-pointer"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>{t('actionRollback')}</span>
                        </button>
                      )}

                      {/* Delete */}
                      <button
                        onClick={() => handleDeleteProject(proj)}
                        className="hover:text-rose-400 flex items-center gap-1 transition cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>{t('actionDelete')}</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Rollback Modal */}
      {rollbackProjectTarget && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0b1120] border border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-4">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <RotateCcw className="w-5 h-5 text-amber-400" />
              <span>Rollback: {rollbackProjectTarget.name}</span>
            </h3>
            <p className="text-xs text-slate-400">
              Select an earlier version to instantly restore without changing the public URL.
            </p>

            <div className="space-y-2 max-h-48 overflow-y-auto">
              {rollbackProjectTarget.deployments.map((dep) => (
                <label
                  key={dep.id}
                  className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer text-xs ${
                    selectedRollbackVersion === dep.version
                      ? 'border-amber-500 bg-amber-950/20 text-white'
                      : 'border-slate-800 bg-slate-900/60 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <input
                      type="radio"
                      name="rollbackVersion"
                      checked={selectedRollbackVersion === dep.version}
                      onChange={() => setSelectedRollbackVersion(dep.version)}
                      className="accent-amber-500"
                    />
                    <span>v{dep.version} — {dep.notes || 'Deployment'}</span>
                  </div>
                  <span className="text-[10px] text-slate-500">{new Date(dep.deployedAt).toLocaleTimeString()}</span>
                </label>
              ))}
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setRollbackProjectTarget(null)}
                className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-xs font-bold text-slate-300 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleRollback}
                disabled={rollingBack}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black transition cursor-pointer"
              >
                {rollingBack ? 'Restoring...' : 'Confirm Rollback'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
