import React, { useState } from 'react';
import {
  User as UserIcon,
  Mail,
  Shield,
  Calendar,
  HardDrive,
  Globe,
  Sun,
  Moon,
  LogOut,
  Key,
  Save,
  Check,
  Server,
  Package
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext.js';
import { useTheme } from '../context/ThemeContext.js';
import { useAuth } from '../context/AuthContext.js';

interface ProfilePageProps {
  openAuthModal: () => void;
  onNavigateTab: (tab: string) => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({ openAuthModal, onNavigateTab }) => {
  const { t, language, setLanguage } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const { user, logout, updateProfile } = useAuth();

  const [displayName, setDisplayName] = useState(user?.displayName || '');
  const [saving, setSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!user) {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center space-y-4">
        <UserIcon className="w-16 h-16 text-slate-600 mx-auto" />
        <h2 className="text-xl font-bold text-white">Sign In to View Profile</h2>
        <p className="text-xs text-slate-400">Manage your hosting quotas, language and account preferences.</p>
        <button
          onClick={openAuthModal}
          className="px-6 py-2.5 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs"
        >
          {t('login')}
        </button>
      </div>
    );
  }

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const ok = await updateProfile({ displayName });
    setSaving(false);
    if (ok) {
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2000);
    }
  };

  const usedKb = Math.round((user.usedStorageBytes || 0) / 1024);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-8 pb-24">
      {/* Header Profile Card */}
      <div className="p-8 rounded-3xl bg-[#0b1120] border border-slate-800 relative overflow-hidden shadow-2xl flex flex-col sm:flex-row items-center sm:items-start gap-6 text-center sm:text-left">
        <div className="relative">
          <img
            src={user.avatarUrl}
            alt={user.displayName}
            className="w-24 h-24 rounded-3xl object-cover border-2 border-cyan-500/50 shadow-xl bg-slate-900"
          />
          {user.role === 'admin' && (
            <span className="absolute -bottom-2 -right-2 px-2 py-0.5 rounded-full bg-purple-600 text-white font-mono font-bold text-[10px] shadow">
              ADMIN
            </span>
          )}
        </div>

        <div className="space-y-2 flex-1">
          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
            <h1 className="text-2xl font-black text-white">{user.displayName}</h1>
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono font-bold">
              {user.status.toUpperCase()}
            </span>
          </div>

          <p className="text-xs font-mono text-slate-400">{user.email}</p>

          <div className="flex flex-wrap justify-center sm:justify-start gap-4 pt-2 text-xs text-slate-400">
            <span className="flex items-center gap-1 font-mono">
              <Key className="w-3.5 h-3.5 text-cyan-400" />
              ID: {user.id}
            </span>
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-purple-400" />
              Joined: {new Date(user.createdAt).toLocaleDateString()}
            </span>
          </div>
        </div>

        <button
          onClick={logout}
          className="px-4 py-2 rounded-xl bg-rose-950/40 hover:bg-rose-900/50 border border-rose-800 text-rose-300 text-xs font-bold transition flex items-center gap-1.5 self-center sm:self-start"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>{t('logout')}</span>
        </button>
      </div>

      {/* Quota & Quick Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Active Cloud Tier */}
        <div className="p-6 rounded-3xl glass-card space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
              <HardDrive className="w-4 h-4" />
              <span>{language === 'bn' ? 'হোস্টিং স্ট্যাটাস' : 'Hosting Plan'}</span>
            </span>
            <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono text-[10px] font-bold">
              ACTIVE
            </span>
          </div>
          <div className="pt-1">
            <span className="text-xl font-black text-white font-mono">∞ Unlimited Cloud</span>
            <p className="text-[11px] text-slate-400 mt-1 font-mono">
              {language === 'bn' ? 'আনলিমিটেড স্ট্যাটিক HTML হোস্টিং ও গ্লোবাল CDN' : 'Unlimited static HTML hosting & global CDN'}
            </p>
          </div>
        </div>

        {/* Hosted Sites Quick Nav */}
        <div
          onClick={() => onNavigateTab('host')}
          className="p-6 rounded-3xl bg-[#0b1120] border border-slate-800 hover:border-cyan-500/40 transition cursor-pointer space-y-2 group"
        >
          <Server className="w-6 h-6 text-cyan-400 group-hover:scale-110 transition" />
          <h3 className="text-base font-bold text-white">{t('navHost')}</h3>
          <p className="text-xs text-slate-400">Manage all your deployed websites and domains →</p>
        </div>

        {/* Orders Quick Nav */}
        <div
          onClick={() => onNavigateTab('orders')}
          className="p-6 rounded-3xl bg-[#0b1120] border border-slate-800 hover:border-purple-500/40 transition cursor-pointer space-y-2 group"
        >
          <Package className="w-6 h-6 text-purple-400 group-hover:scale-110 transition" />
          <h3 className="text-base font-bold text-white">{t('navOrders')}</h3>
          <p className="text-xs text-slate-400">Track digital purchases and custom requests →</p>
        </div>
      </div>

      {/* Account Settings Form */}
      <form onSubmit={handleSave} className="p-8 rounded-3xl bg-[#0b1120] border border-slate-800 space-y-6 shadow-xl">
        <h2 className="text-lg font-bold text-white border-b border-slate-800 pb-4">
          Account Settings & Preferences
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-300 block mb-2">
              Display Name
            </label>
            <input
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-300 block mb-2">
              Email Address
            </label>
            <input
              type="text"
              disabled
              value={user.email}
              className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 text-xs font-mono cursor-not-allowed"
            />
          </div>

          {/* Language Switcher */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-300 block mb-2">
              {t('languagePref')}
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setLanguage('bn')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition ${
                  language === 'bn'
                    ? 'bg-cyan-500 text-slate-950 font-black'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                বাংলা (Bengali)
              </button>
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition ${
                  language === 'en'
                    ? 'bg-cyan-500 text-slate-950 font-black'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                English
              </button>
            </div>
          </div>

          {/* Theme Switcher */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-300 block mb-2">
              {t('themePref')}
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => { if (theme !== 'dark') toggleTheme(); }}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  theme === 'dark'
                    ? 'bg-purple-600 text-white font-black'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                <Moon className="w-3.5 h-3.5" />
                <span>{t('darkTheme')}</span>
              </button>
              <button
                type="button"
                onClick={() => { if (theme !== 'light') toggleTheme(); }}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  theme === 'light'
                    ? 'bg-amber-500 text-slate-950 font-black'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                <Sun className="w-3.5 h-3.5" />
                <span>{t('lightTheme')}</span>
              </button>
            </div>
          </div>
        </div>

        <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
          {savedSuccess && (
            <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
              <Check className="w-4 h-4" />
              Settings Saved!
            </span>
          )}
          <button
            type="submit"
            disabled={saving}
            className="ml-auto px-6 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-black transition flex items-center gap-1.5"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{saving ? 'Saving...' : 'Save Profile'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
