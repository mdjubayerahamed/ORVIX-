import React, { useState } from 'react';
import {
  FileCode2,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  MessageCircle,
  Clock,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useLanguage } from '../context/LanguageContext.js';
import { useAuth } from '../context/AuthContext.js';

interface CustomRequestPageProps {
  onOrderCreated: () => void;
  openAuthModal: () => void;
}

export const CustomRequestPage: React.FC<CustomRequestPageProps> = ({ onOrderCreated, openAuthModal }) => {
  const { t, language } = useLanguage();
  const { user, token } = useAuth();

  const [customerName, setCustomerName] = useState(user?.displayName || '');
  const [email, setEmail] = useState(user?.email || '');
  const [whatsapp, setWhatsapp] = useState('');
  const [siteType, setSiteType] = useState('E-commerce Website');
  const [features, setFeatures] = useState('');
  const [designPreferences, setDesignPreferences] = useState('');
  const [referenceUrl, setReferenceUrl] = useState('');
  const [budgetBdt, setBudgetBdt] = useState<number>(10000);
  const [preferredDeadline, setPreferredDeadline] = useState('7 Days');
  const [additionalInstructions, setAdditionalInstructions] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submittedOrderId, setSubmittedOrderId] = useState<string | null>(null);

  const websiteTypes = [
    'E-commerce & Online Shop',
    'Custom SaaS Web Application',
    'Business & Corporate Portal',
    'Educational & LMS Platform',
    'Personal & Creative Portfolio',
    'Website to Native Android APK',
    'Blog, News & Media Magazine',
    'Custom Database / Admin Panel',
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      openAuthModal();
      return;
    }

    if (!features.trim()) {
      setError(language === 'bn' ? 'অনুগ্রহ করে প্রয়োজনীয় ফিচারসমূহ উল্লেখ করুন।' : 'Please describe your required features.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/orders/custom-request', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          customerName,
          email,
          whatsapp,
          siteType,
          features,
          designPreferences,
          referenceUrl,
          budgetBdt,
          preferredDeadline,
          additionalInstructions,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to submit request');

      setSubmittedOrderId(data.customRequest.orderId);
      confetti({ particleCount: 70, spread: 60 });
    } catch (err: any) {
      setError(err.message || 'Error submitting quotation request.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-10 pb-24">
      {/* Title Header */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-purple-950/60 border border-purple-800/80 text-purple-300 text-xs font-mono font-bold">
          <FileCode2 className="w-3.5 h-3.5" />
          <span>TAILORED ENGINEERING SERVICES</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-black text-white">{t('customTitle')}</h1>
        <p className="text-slate-400 text-sm max-w-xl mx-auto">{t('customSubtitle')}</p>
      </div>

      {submittedOrderId ? (
        <div className="bg-[#0b1120] border border-cyan-500/40 rounded-3xl p-8 sm:p-12 text-center space-y-6 shadow-2xl animate-in zoom-in-95">
          <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">
              {language === 'bn' ? 'কোটেশন রিকোয়েস্ট সফলভাবে জমা হয়েছে!' : 'Quotation Request Received!'}
            </h2>
            <p className="text-sm font-mono text-cyan-400 mt-2">
              Request ID: <span className="text-white font-bold">{submittedOrderId}</span>
            </p>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 max-w-lg mx-auto leading-relaxed">
            {language === 'bn'
              ? 'আমাদের সিনিয়র সফটওয়্যার ইঞ্জিনিয়ার টিম আপনার রিকোয়েস্ট যাচাই করে অর্ডার ড্যাশবোর্ডে ও ইমেইলে কোটেশন পাঠাবে। জরুরী প্রয়োজনে আমাদের সরাসরি হোয়াটসঅ্যাপ করতে পারেন।'
              : 'Our engineering lead is reviewing your requirements and will issue a formal quotation in your Orders dashboard. You can also message us directly on WhatsApp.'}
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-3 pt-4">
            <button
              onClick={onOrderCreated}
              className="px-6 py-3 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-black transition"
            >
              {language === 'bn' ? 'অর্ডার ড্যাশবোর্ডে যান' : 'Go to Orders Dashboard'}
            </button>
            <a
              href={`https://wa.me/8801344495081?text=Hello%20ORVIX,%20I%20submitted%20request%20${submittedOrderId}`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3 rounded-2xl bg-slate-900 border border-slate-700 text-slate-200 text-xs font-bold transition flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4 text-emerald-400" />
              <span>Contact on WhatsApp</span>
            </a>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="bg-[#0b1120] border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl space-y-6">
          {error && (
            <div className="p-4 rounded-2xl bg-rose-950/40 border border-rose-800 text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                {t('custName')} *
              </label>
              <input
                type="text"
                required
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="e.g. Jubayer Ahamed"
                className="w-full px-4 py-3 rounded-2xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                {t('custEmail')} *
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="e.g. name@example.com"
                className="w-full px-4 py-3 rounded-2xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                {t('custWhatsapp')}
              </label>
              <input
                type="tel"
                value={whatsapp}
                onChange={(e) => setWhatsapp(e.target.value)}
                placeholder="e.g. 01344495081"
                className="w-full px-4 py-3 rounded-2xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                {t('custType')} *
              </label>
              <select
                value={siteType}
                onChange={(e) => setSiteType(e.target.value)}
                className="w-full px-4 py-3 rounded-2xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:border-cyan-500"
              >
                {websiteTypes.map((type) => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
              {t('custFeatures')} *
            </label>
            <textarea
              required
              rows={4}
              value={features}
              onChange={(e) => setFeatures(e.target.value)}
              placeholder="e.g. Need bKash automatic payment, product search filter, customer invoice PDF, and admin order notifications."
              className="w-full px-4 py-3 rounded-2xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                {language === 'bn' ? 'ডিজাইন পছন্দ (কালার/স্টাইল)' : 'Design Preferences'}
              </label>
              <input
                type="text"
                value={designPreferences}
                onChange={(e) => setDesignPreferences(e.target.value)}
                placeholder="e.g. Modern dark theme with neon cyan glow, similar to ORVIX"
                className="w-full px-4 py-3 rounded-2xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                {t('custRefUrl')}
              </label>
              <input
                type="url"
                value={referenceUrl}
                onChange={(e) => setReferenceUrl(e.target.value)}
                placeholder="https://example.com"
                className="w-full px-4 py-3 rounded-2xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                {t('custBudget')} (৳ BDT) *
              </label>
              <input
                type="number"
                required
                min={2000}
                step={500}
                value={budgetBdt}
                onChange={(e) => setBudgetBdt(Number(e.target.value))}
                className="w-full px-4 py-3 rounded-2xl bg-slate-900 border border-slate-700 text-white font-mono text-sm focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                {t('custDeadline')}
              </label>
              <select
                value={preferredDeadline}
                onChange={(e) => setPreferredDeadline(e.target.value)}
                className="w-full px-4 py-3 rounded-2xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:border-cyan-500"
              >
                <option value="3 Days">3 Days (Express)</option>
                <option value="5-7 Days">5-7 Days (Standard)</option>
                <option value="10-14 Days">10-14 Days</option>
                <option value="1 Month">1 Month (Enterprise)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
              {t('custNotes')}
            </label>
            <textarea
              rows={2}
              value={additionalInstructions}
              onChange={(e) => setAdditionalInstructions(e.target.value)}
              placeholder="Any specific delivery instructions, logos, or third-party APIs..."
              className="w-full px-4 py-3 rounded-2xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:border-cyan-500"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-500 hover:from-purple-400 hover:to-cyan-400 text-white font-black text-sm shadow-xl shadow-purple-500/25 transition disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading ? (
              <span>জমা হচ্ছে...</span>
            ) : (
              <>
                <span>{t('custSubmitBtn')}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>
      )}
    </div>
  );
};
