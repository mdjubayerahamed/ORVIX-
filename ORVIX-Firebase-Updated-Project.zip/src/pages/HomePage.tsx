import React, { useEffect, useState } from 'react';
import {
  Server,
  Zap,
  Globe2,
  Shield,
  ArrowRight,
  ExternalLink,
  ShoppingBag,
  Sparkles,
  CheckCircle,
  Code2,
  ChevronDown,
  ChevronUp,
  MessageCircle,
  Mail,
  Send,
  Eye,
  Cpu,
  Layers,
  Infinity as InfinityIcon,
  Flame,
  Check
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext.js';
import { HostingProject, MarketplaceProduct } from '../types/index.js';
import { OrvixLogo } from '../components/OrvixLogo.js';

interface HomePageProps {
  onNavigateTab: (tab: string) => void;
  onPreviewProject: (proj: HostingProject) => void;
  onOpenProductDetails: (prod: MarketplaceProduct) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigateTab,
  onPreviewProject,
  onOpenProductDetails,
}) => {
  const { t, language } = useLanguage();
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [featuredProjects, setFeaturedProjects] = useState<HostingProject[]>([]);
  const [featuredProducts, setFeaturedProducts] = useState<MarketplaceProduct[]>([]);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  useEffect(() => {
    // Fast parallel fetch with safety fallbacks
    Promise.all([
      fetch('/api/announcements').then((r) => r.json()).catch(() => ({ announcements: [] })),
      fetch('/api/hosting/projects').then((r) => r.json()).catch(() => ({ projects: [] })),
      fetch('/api/marketplace/products').then((r) => r.json()).catch(() => ({ products: [] })),
    ]).then(([annData, projData, prodData]) => {
      setAnnouncements(annData.announcements || []);
      setFeaturedProjects((projData.projects || []).slice(0, 3));
      setFeaturedProducts((prodData.products || []).slice(0, 4));
    });
  }, []);

  const faqs = [
    {
      q: language === 'bn' ? 'ORVIX-এ ওয়েবসাইট হোস্টিং কি সত্যিই আজীবন ফ্রি?' : 'Is static website hosting really 100% free on ORVIX?',
      a: language === 'bn'
        ? 'হ্যাঁ! যেকোনো স্ট্যাটিক HTML ওয়েবসাইট সম্পূর্ণ ফ্রিতে আজীবন হোস্ট করা যাবে। কোনো স্টোরেজ লিমিট নেই—সম্পূর্ণ আনলিমিটেড ফ্রি স্টোরেজ, গ্লোবাল CDN স্পিড ও নিজস্ব .orvix সাবডোমেইন পাবেন।'
        : 'Yes! Any static HTML website can be deployed completely free with unlimited cloud storage, ultra-fast global CDN speed, and your own .orvix subdomain with zero cost.'
    },
    {
      q: language === 'bn' ? 'স্টোরেজের কি কোনো নির্দিষ্ট লিমিট আছে?' : 'Is there any storage limit on my hosted sites?',
      a: language === 'bn'
        ? 'না! ORVIX-এ স্টোরেজের ওপর কোনো বিধিনিষেধ বা সীমাবদ্ধতা নেই। আপনি স্বচ্ছন্দে আপনার সম্পূর্ণ ওয়েবসাইট হোস্ট ও আপডেট করতে পারবেন।'
        : 'No! ORVIX provides unlimited cloud storage for your static HTML web projects with no hidden limits.'
    },
    {
      q: language === 'bn' ? 'সাইট আপডেট করলে লিংক কি পরিবর্তন হবে?' : 'Will my website link change when I update files?',
      a: language === 'bn'
        ? 'না! আপনার ওয়েবসাইট লিংক (যেমন yourname.orvix) সবসময় একই থাকবে। এছাড়া আপনি ইচ্ছে করলে আগের যেকোনো ভার্সনে ১-ক্লিকে ইনস্ট্যান্ট রোলব্যাক করতে পারবেন।'
        : 'No! Your website URL remains identical during all updates. Plus, you can roll back to any earlier version with one click.'
    },
    {
      q: language === 'bn' ? 'বিকাশ (bKash) পেমেন্ট কিভাবে সম্পন্ন করব?' : 'How does bKash manual payment work?',
      a: language === 'bn'
        ? 'মার্কেটপ্লেস বা কাস্টম অর্ডারের ক্ষেত্রে আমাদের বিকাশ নম্বর 01344495081-এ Send Money করে আপনার প্রেরক নম্বর ও TrxID সাবমিট করলেই আমাদের টিম ভেরিফাই করে কাজ শুরু করবে।'
        : 'For marketplace purchases or custom services, simply Send Money to our bKash number 01344495081 and submit your Sender Number & TrxID.'
    },
    {
      q: language === 'bn' ? 'কাস্টম ওয়েবসাইট বা অ্যান্ড্রয়েড অ্যাপ বানাতে চাইলে কীভাবে যোগাযোগ করব?' : 'How can I commission a custom website or Android app?',
      a: language === 'bn'
        ? 'আমাদের "কাস্টম ওয়েবসাইট" মেনু থেকে সরাসরি রিকোয়েস্ট পাঠাতে পারেন, অথবা হোয়াটসঅ্যাপ/কল করুন: 01344495081।'
        : 'You can submit specifications via the Custom Order tab, or contact our engineering team directly on WhatsApp at 01344495081.'
    }
  ];

  return (
    <div className="space-y-20 pb-20 overflow-x-hidden">
      {/* 1. Announcement Notice Bar with Shimmer Animation */}
      {announcements.length > 0 && (
        <div className="bg-gradient-to-r from-cyan-950/90 via-slate-900 to-purple-950/90 border-b border-cyan-500/30 py-2.5 px-4 text-center shadow-lg relative overflow-hidden sheen-overlay">
          <div className="max-w-6xl mx-auto flex items-center justify-center gap-2.5 text-xs sm:text-sm font-medium text-cyan-200">
            <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-bold text-[10px] uppercase border border-cyan-500/40 tracking-wider animate-pulse">
              {announcements[0].badge || 'ANNOUNCEMENT'}
            </span>
            <span className="truncate">
              {language === 'bn' ? (announcements[0].messageBn || announcements[0].message) : announcements[0].message}
            </span>
          </div>
        </div>
      )}

      {/* 2. Hero Section with Ultra-Smooth Hardware-Accelerated Floating Animations */}
      <section className="relative px-4 sm:px-6 pt-10 sm:pt-20 max-w-7xl mx-auto">
        {/* Animated Cyber Aura Rings (Zero CPU overhead) */}
        <div className="absolute top-10 left-1/2 -translate-x-1/2 w-80 h-80 rounded-full border border-cyan-500/10 animate-spin-slow pointer-events-none" />
        <div className="absolute top-4 left-1/2 -translate-x-1/2 w-96 h-96 rounded-full border border-purple-500/10 animate-spin-slow pointer-events-none" style={{ animationDirection: 'reverse', animationDuration: '20s' }} />

        {/* Floating Decorative Cyber Badges */}
        <div className="hidden lg:flex items-center gap-2 absolute top-20 left-10 p-2.5 rounded-2xl bg-slate-900/80 border border-cyan-500/30 backdrop-blur-md animate-float shadow-xl text-xs font-mono text-cyan-300">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
          <span>HTML Instant Deploy</span>
        </div>

        <div className="hidden lg:flex items-center gap-2 absolute top-36 right-12 p-2.5 rounded-2xl bg-slate-900/80 border border-purple-500/30 backdrop-blur-md animate-float-reverse shadow-xl text-xs font-mono text-purple-300">
          <InfinityIcon className="w-4 h-4 text-purple-400" />
          <span>Unlimited Cloud</span>
        </div>

        <div className="relative z-10 flex flex-col items-center text-center space-y-7 max-w-4xl mx-auto animate-fade-up">
          {/* Top Pill Badge with Animated Glow Border */}
          <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-slate-900/90 border border-cyan-500/40 animate-border-glow shadow-lg cursor-pointer">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            <span className="text-xs font-bold text-cyan-300 tracking-wide font-mono uppercase">
              {language === 'bn' ? '⚡ আনলিমিটেড ফ্রি ক্লাউড হোস্টিং' : '⚡ UNLIMITED FREE CLOUD HOSTING'}
            </span>
          </div>

          {/* Headline with Moving Gradient Animation */}
          <h1 className="text-4xl sm:text-6xl md:text-7xl font-black tracking-tight text-white leading-[1.12]">
            {language === 'bn' ? (
              <>
                আপনার ওয়েবসাইট। <br className="hidden sm:inline" />
                <span className="bg-gradient-to-r from-cyan-400 via-sky-300 to-purple-400 bg-clip-text text-transparent animate-gradient-text">
                  লাইভ হবে ফ্রিতে।
                </span>
              </>
            ) : (
              <>
                Your Website. <br className="hidden sm:inline" />
                <span className="bg-gradient-to-r from-cyan-400 via-sky-300 to-purple-400 bg-clip-text text-transparent animate-gradient-text">
                  Live for Free.
                </span>
              </>
            )}
          </h1>

          {/* Subtitle */}
          <p className="text-base sm:text-lg text-slate-300/90 max-w-2xl leading-relaxed font-normal">
            {language === 'bn'
              ? 'এইচটিএমএল ওয়েবসাইট বিনামূল্যে হোস্ট করুন সেকেন্ডের মধ্যে। কোনো স্টোরেজ লিমিট নেই—রয়েছে আনলিমিটেড ক্লাউড স্পেস, প্রিমিয়াম মার্কেটপ্লেস ও এক্সপার্ট ডেভেলপমেন্ট সার্ভিস।'
              : 'Deploy HTML static web projects in seconds with zero fees. Experience unlimited cloud storage, ready-made digital templates, and custom engineering services.'}
          </p>

          {/* CTA Buttons with Sheen Sweep and Glow */}
          <div className="flex flex-col sm:flex-row items-center gap-4 pt-3 w-full sm:w-auto">
            <button
              onClick={() => onNavigateTab('host')}
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-cyan-500 via-sky-400 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-sm tracking-wide glow-button sheen-overlay flex items-center justify-center gap-2.5 cursor-pointer"
            >
              <span>{t('heroBtnHost')}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onNavigateTab('marketplace')}
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 hover:border-cyan-500/40 text-slate-200 hover:text-white font-bold text-sm shadow-lg hover:scale-102 transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4 text-cyan-400" />
              <span>{t('heroBtnMarketplace')}</span>
            </button>
          </div>

          {/* Live Hosting Feature Badges with Hover Micro-Animations */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 pt-8 w-full max-w-3xl">
            <div className="p-4 rounded-2xl bg-[#090e1d]/90 border border-slate-800/90 backdrop-blur-md text-center interactive-card">
              <span className="text-xl sm:text-2xl font-black text-cyan-400 font-mono block">100% Free</span>
              <span className="text-[11px] text-slate-400 font-medium">
                {language === 'bn' ? 'আজীবন ফ্রি হোস্টিং' : 'Lifetime Free'}
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-[#090e1d]/90 border border-slate-800/90 backdrop-blur-md text-center interactive-card">
              <div className="flex items-center justify-center gap-1 text-xl sm:text-2xl font-black text-purple-400 font-mono">
                <InfinityIcon className="w-5 h-5 animate-pulse" />
                <span>Storage</span>
              </div>
              <span className="text-[11px] text-slate-400 font-medium">
                {language === 'bn' ? 'কোনো লিমিট নেই' : 'No Storage Limit'}
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-[#090e1d]/90 border border-slate-800/90 backdrop-blur-md text-center interactive-card">
              <span className="text-xl sm:text-2xl font-black text-emerald-400 font-mono block">&lt; 1 Sec</span>
              <span className="text-[11px] text-slate-400 font-medium">
                {language === 'bn' ? 'ইনস্ট্যান্ট লাইভ' : 'Instant Deploy'}
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-[#090e1d]/90 border border-slate-800/90 backdrop-blur-md text-center interactive-card">
              <span className="text-xl sm:text-2xl font-black text-sky-400 font-mono block">.orvix</span>
              <span className="text-[11px] text-slate-400 font-medium">
                {language === 'bn' ? 'ফ্রি সাবডোমেইন' : 'Free Subdomain'}
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Core Features with Interactive Cards & Corner Lights */}
      <section className="px-4 sm:px-6 max-w-7xl mx-auto space-y-10">
        <div className="text-center space-y-3 max-w-2xl mx-auto animate-fade-up">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/60 border border-cyan-800/80 text-cyan-300 text-xs font-mono font-bold animate-border-glow">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-spin-slow" />
            <span>PLATFORM ADVANTAGES</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white">
            {language === 'bn' ? 'কেন বেছে নেবেন ORVIX?' : 'Why Choose ORVIX Platform?'}
          </h2>
          <p className="text-slate-400 text-sm">
            {language === 'bn'
              ? 'সহজ, দ্রুত ও আধুনিক স্ট্যাটিক হোস্টিং আর্কিটেকচার যা সবার জন্য উন্মুক্ত'
              : 'Ultra-fast static web infrastructure engineered for developers and businesses'}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              icon: Zap,
              title: t('feat1Title'),
              desc: t('feat1Desc'),
              badge: 'Fast Deploy',
            },
            {
              icon: Globe2,
              title: t('feat2Title'),
              desc: t('feat2Desc'),
              badge: 'Subdomain',
            },
            {
              icon: InfinityIcon,
              title: language === 'bn' ? 'আনলিমিটেড ফ্রি স্টোরেজ' : 'Unlimited Free Storage',
              desc: language === 'bn' ? 'কোনো স্টোরেজ লিমিট নেই। আপনার এইচটিএমএল সাইট সম্পূর্ণ বাধাহীনভাবে হোস্ট করুন।' : 'Zero quota restrictions. Host your HTML projects with limitless cloud capacity.',
              badge: 'No Limit',
            },
            {
              icon: Shield,
              title: t('feat4Title'),
              desc: t('feat4Desc'),
              badge: 'Safe Rollback',
            },
          ].map((feat, idx) => (
            <div
              key={idx}
              className="p-6 rounded-3xl bg-[#090e1d]/90 border border-slate-800/80 interactive-card relative group overflow-hidden"
            >
              {/* Corner Cyber Accent Light */}
              <div className="absolute top-2 right-2 w-1.5 h-1.5 rounded-full bg-cyan-400/80 group-hover:bg-cyan-300 group-hover:scale-150 transition" />

              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 flex items-center justify-center group-hover:scale-110 group-hover:rotate-6 transition duration-300">
                  <feat.icon className="w-6 h-6" />
                </div>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-slate-900 text-slate-400 border border-slate-800">
                  {feat.badge}
                </span>
              </div>
              <h3 className="text-base font-bold text-white mb-2 group-hover:text-cyan-300 transition duration-200">{feat.title}</h3>
              <p className="text-xs text-slate-400 leading-relaxed">{feat.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 4. How It Works (3 Steps) with Animated Step Glow */}
      <section className="px-4 sm:px-6 max-w-7xl mx-auto space-y-12">
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-950/60 border border-purple-800/80 text-purple-300 text-xs font-mono font-bold">
            <Cpu className="w-3.5 h-3.5" />
            <span>HOW IT WORKS</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white">{t('howItWorksTitle')}</h2>
          <p className="text-slate-400 text-sm">
            {language === 'bn' ? 'কোনো কোডিং বা সার্ভার ঝামেলা নেই—৩টি ক্লিকেই আপনার সাইট রেডি' : 'Simple 3-step deployment with instant domain provisioning'}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          {[
            {
              step: '01',
              title: t('howStep1Title'),
              desc: t('howStep1Desc'),
              badge: 'HTML Ready',
            },
            {
              step: '02',
              title: t('howStep2Title'),
              desc: t('howStep2Desc'),
              badge: 'Drop & Deploy',
            },
            {
              step: '03',
              title: t('howStep3Title'),
              desc: t('howStep3Desc'),
              badge: 'Live on .orvix',
            },
          ].map((item, idx) => (
            <div
              key={idx}
              className="p-8 rounded-3xl bg-[#090e1d]/90 border border-slate-800/90 interactive-card relative overflow-hidden group"
            >
              <span className="text-5xl font-black text-slate-800/40 absolute top-4 right-6 font-mono select-none group-hover:text-cyan-500/20 transition duration-300">
                {item.step}
              </span>
              <div className="inline-block px-3 py-1 rounded-xl bg-purple-500/10 text-purple-400 text-xs font-mono font-bold mb-4 border border-purple-500/20">
                {item.badge}
              </div>
              <h3 className="text-lg font-bold text-white mb-2 group-hover:text-cyan-300 transition">{item.title}</h3>
              <p className="text-xs text-slate-400 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 5. Live Showcase Projects */}
      {featuredProjects.length > 0 && (
        <section className="px-4 sm:px-6 max-w-7xl mx-auto space-y-10">
          <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 border-b border-slate-800 pb-5">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/60 border border-cyan-800/80 text-cyan-300 text-xs font-mono font-bold mb-2">
                <Globe2 className="w-3.5 h-3.5" />
                <span>LIVE PLATFORM SHOWCASE</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-white">
                {language === 'bn' ? 'হোস্টকৃত সাম্প্রতিক ওয়েবসাইট' : 'Recently Hosted Websites'}
              </h2>
            </div>
            <button
              onClick={() => onNavigateTab('host')}
              className="text-xs font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer group"
            >
              <span>{language === 'bn' ? 'হোস্টিং ড্যাশবোর্ড দেখুন' : 'Go to Hosting'}</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition duration-200" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {featuredProjects.map((proj) => (
              <div
                key={proj.id}
                className="p-6 rounded-3xl bg-[#090e1d]/90 border border-slate-800 interactive-card flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-mono font-bold flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                      v{proj.currentVersion} LIVE
                    </span>
                    <span className="text-[11px] font-mono text-cyan-400">Unlimited Cloud</span>
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white truncate">{proj.name}</h3>
                    <p className="text-xs font-mono text-slate-400 truncate mt-0.5">https://{proj.subdomain}</p>
                  </div>
                </div>

                <div className="pt-2 flex items-center gap-2">
                  <button
                    onClick={() => onPreviewProject(proj)}
                    className="flex-1 py-2 px-3 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>{t('actionVisit')}</span>
                  </button>
                  <a
                    href={proj.publicUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition"
                    title="Open in new tab"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 6. Marketplace Spotlight */}
      {featuredProducts.length > 0 && (
        <section className="px-4 sm:px-6 max-w-7xl mx-auto space-y-10">
          <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 border-b border-slate-800 pb-5">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-950/60 border border-purple-800/80 text-purple-300 text-xs font-mono font-bold mb-2">
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>ORVIX MARKETPLACE</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-white">
                {language === 'bn' ? 'রেডিমেড ওয়েবসাইট ও অ্যাপস' : 'Ready-Made Websites & Apps'}
              </h2>
            </div>
            <button
              onClick={() => onNavigateTab('marketplace')}
              className="text-xs font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer group"
            >
              <span>{language === 'bn' ? 'সকল প্রোডাক্ট দেখুন' : 'View All Marketplace'}</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition duration-200" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((prod) => (
              <div
                key={prod.id}
                className="p-5 rounded-3xl bg-[#090e1d]/90 border border-slate-800 interactive-card flex flex-col justify-between space-y-4 group"
              >
                <div className="space-y-3">
                  <div className="aspect-video rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center relative overflow-hidden group-hover:border-purple-500/30 transition">
                    <img
                      src={prod.imageUrl}
                      alt={prod.title}
                      className="w-full h-full object-cover group-hover:scale-108 transition duration-500"
                    />
                    <span className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-slate-950/80 backdrop-blur-md text-[10px] font-mono font-bold text-cyan-300 border border-cyan-500/30">
                      {prod.category}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-sm font-bold text-white line-clamp-1 group-hover:text-cyan-300 transition">{prod.title}</h3>
                    <p className="text-xs text-slate-400 line-clamp-2 mt-1">
                      {language === 'bn' ? prod.shortDescBn : prod.shortDesc}
                    </p>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-slate-500 block uppercase font-mono">Price</span>
                    <span className="text-lg font-black text-white font-mono">৳{prod.priceBdt}</span>
                  </div>

                  <button
                    onClick={() => onOpenProductDetails(prod)}
                    className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs shadow-md hover:scale-105 active:scale-95 transition flex items-center gap-1 cursor-pointer"
                  >
                    <span>{t('orderNow')}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 7. Custom Development Banner with Animated Glow Frame */}
      <section className="px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-br from-slate-900 via-[#0a1122] to-cyan-950/40 border border-cyan-500/30 shadow-2xl relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-8 sheen-overlay">
          <div className="space-y-4 max-w-2xl text-center md:text-left">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono font-bold animate-pulse">
              <Code2 className="w-3.5 h-3.5" />
              <span>CUSTOM SOFTWARE & WEB ENGINEERING</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-black text-white">
              {language === 'bn' ? 'বিশেষ রিকোয়ারমেন্টের ওয়েবসাইট বা অ্যাপ দরকার?' : 'Need a Custom Website or Mobile Application?'}
            </h2>
            <p className="text-slate-300 text-sm leading-relaxed">
              {language === 'bn'
                ? 'ই-কমার্স, এন্টারপ্রাইজ পোর্টাল, ডায়নামিক ওয়েব অ্যাপ্লিকেশন বা অ্যান্ড্রয়েড অ্যাপ তৈরি করতে আমাদের সাথে যোগাযোগ করুন।'
                : 'Commission bespoke web applications, e-commerce stores, SaaS dashboards, or native Android software built to your exact specifications.'}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto shrink-0">
            <button
              onClick={() => onNavigateTab('custom-request')}
              className="px-6 py-3.5 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs shadow-lg shadow-cyan-500/30 hover:scale-105 active:scale-95 transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>{language === 'bn' ? 'অর্ডার ফর্ম পূরণ করুন' : 'Submit Custom Request'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <a
              href="https://wa.me/8801344495081"
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3.5 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-emerald-500/40 text-emerald-300 font-bold text-xs hover:scale-105 active:scale-95 transition flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4 text-emerald-400" />
              <span>WhatsApp: 01344495081</span>
            </a>
          </div>
        </div>
      </section>

      {/* 8. Frequently Asked Questions with Smooth Accordion */}
      <section className="px-4 sm:px-6 max-w-4xl mx-auto space-y-8">
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-black text-white">
            {language === 'bn' ? 'সাধারণ জিজ্ঞাসাসমূহ (FAQ)' : 'Frequently Asked Questions'}
          </h2>
          <p className="text-slate-400 text-xs">
            {language === 'bn' ? 'হোস্টিং, ফাইল আপলোড ও পেমেন্ট সম্পর্কিত সাধারণ প্রশ্নের উত্তর' : 'Common questions regarding static deployment and orders'}
          </p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, idx) => {
            const isOpen = openFaqIndex === idx;
            return (
              <div
                key={idx}
                className={`rounded-2xl bg-[#090e1d]/90 border transition-all duration-200 overflow-hidden ${
                  isOpen ? 'border-cyan-500/50 shadow-lg shadow-cyan-950/20' : 'border-slate-800/90 hover:border-slate-700'
                }`}
              >
                <button
                  onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                  className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4 font-bold text-white text-xs sm:text-sm hover:text-cyan-300 transition cursor-pointer"
                >
                  <span>{faq.q}</span>
                  {isOpen ? (
                    <ChevronUp className="w-4 h-4 text-cyan-400 shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                  )}
                </button>
                {isOpen && (
                  <div className="px-4 pb-4 sm:px-5 sm:pb-5 text-xs text-slate-300 leading-relaxed border-t border-slate-800/60 pt-3 animate-fade-up">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* 9. Support Channels & Contact Info */}
      <section className="px-4 sm:px-6 max-w-7xl mx-auto">
        <div className="p-8 rounded-3xl bg-[#090e1d]/90 border border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
          <a
            href="https://wa.me/8801344495081"
            target="_blank"
            rel="noopener noreferrer"
            className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-emerald-500/40 interactive-card group"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition duration-200">
              <MessageCircle className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-white group-hover:text-emerald-300">WhatsApp</h4>
            <p className="text-xs font-mono text-slate-400 mt-1">01344495081</p>
          </a>

          <a
            href="mailto:businessforworld678@gmail.com"
            className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-cyan-500/40 interactive-card group"
          >
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition duration-200">
              <Mail className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-white group-hover:text-cyan-300">Official Email</h4>
            <p className="text-xs font-mono text-slate-400 mt-1 truncate">businessforworld678@gmail.com</p>
          </a>

          <a
            href="https://t.me/jubayerahamed8"
            target="_blank"
            rel="noopener noreferrer"
            className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-sky-500/40 interactive-card group"
          >
            <div className="w-10 h-10 rounded-xl bg-sky-500/10 text-sky-400 flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition duration-200">
              <Send className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-white group-hover:text-sky-300">Telegram</h4>
            <p className="text-xs font-mono text-slate-400 mt-1">@jubayerahamed8</p>
          </a>
        </div>
      </section>

      {/* 10. Footer - COMPLETELY ZERO ADMIN PANEL MENTIONS OR LINKS */}
      <footer className="border-t border-slate-800/80 pt-12 text-slate-400 text-xs px-4 sm:px-6 max-w-7xl mx-auto space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex flex-col items-center md:items-start space-y-2">
            <OrvixLogo size="md" showTagline={true} />
            <p className="text-slate-500 text-[11px] max-w-xs text-center md:text-left">
              Free static hosting infrastructure, domain deployment, and digital marketplace in Bangladesh.
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-6 text-slate-300 font-medium">
            <button onClick={() => onNavigateTab('host')} className="hover:text-cyan-400 transition cursor-pointer">{t('navHost')}</button>
            <button onClick={() => onNavigateTab('marketplace')} className="hover:text-cyan-400 transition cursor-pointer">{t('navMarketplace')}</button>
            <button onClick={() => onNavigateTab('custom-request')} className="hover:text-cyan-400 transition cursor-pointer">{t('navCustomRequest')}</button>
            <button onClick={() => onNavigateTab('orders')} className="hover:text-cyan-400 transition cursor-pointer">{t('navOrders')}</button>
            <button onClick={() => onNavigateTab('support')} className="hover:text-cyan-400 transition cursor-pointer">{t('navSupport')}</button>
          </div>
        </div>

        <div className="border-t border-slate-900 pt-6 flex flex-col sm:flex-row justify-between items-center text-[11px] text-slate-500 gap-3">
          <p>© 2026 ORVIX Platform. All rights reserved. Powered by High-Speed Static Edge Cloud.</p>
          <div className="flex items-center gap-4">
            <span className="hover:text-slate-400 cursor-pointer">Terms of Service</span>
            <span>•</span>
            <span className="hover:text-slate-400 cursor-pointer">Privacy Policy</span>
            <span>•</span>
            <span className="hover:text-slate-400 cursor-pointer">Hosting Policy</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
