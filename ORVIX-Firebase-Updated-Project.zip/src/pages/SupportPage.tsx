import React, { useState, useEffect } from 'react';
import {
  HelpCircle,
  MessageCircle,
  Mail,
  Send,
  Copy,
  Check,
  ExternalLink,
  Plus,
  Clock,
  CheckCircle2,
  AlertCircle,
  User,
  ShieldCheck
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext.js';
import { useAuth } from '../context/AuthContext.js';
import { SupportTicket } from '../types/index.js';

interface SupportPageProps {
  openAuthModal: () => void;
}

export const SupportPage: React.FC<SupportPageProps> = ({ openAuthModal }) => {
  const { t, language } = useLanguage();
  const { user, token } = useAuth();
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [copiedType, setCopiedType] = useState<string | null>(null);

  // Form State
  const [showNewTicketModal, setShowNewTicketModal] = useState(false);
  const [subject, setSubject] = useState('');
  const [category, setCategory] = useState<'Hosting' | 'Marketplace' | 'Payment' | 'Custom Request' | 'Other'>('Hosting');
  const [orderId, setOrderId] = useState('');
  const [message, setMessage] = useState('');
  const [replyText, setReplyText] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const channels = {
    whatsapp: '01344495081',
    email: 'businessforworld678@gmail.com',
    telegram: 'https://t.me/jubayerahamed8',
  };

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedType(type);
    setTimeout(() => setCopiedType(null), 2000);
  };

  const fetchTickets = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/support/tickets', {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      setTickets(data.tickets || []);
      if (selectedTicket) {
        const updated = (data.tickets || []).find((t: any) => t.id === selectedTicket.id);
        if (updated) setSelectedTicket(updated);
      }
    } catch (e) {
      console.error('Failed to load tickets:', e);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, [token]);

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      openAuthModal();
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch('/api/support/tickets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ subject, category, message, orderId }),
      });
      if (res.ok) {
        setShowNewTicketModal(false);
        setSubject('');
        setMessage('');
        setOrderId('');
        fetchTickets();
      }
    } catch (e) {
      console.error('Error creating ticket:', e);
    } finally {
      setSubmitting(false);
    }
  };

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket || !replyText.trim()) return;

    try {
      const res = await fetch(`/api/support/tickets/${selectedTicket.id}/reply`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ message: replyText.trim() }),
      });
      if (res.ok) {
        setReplyText('');
        fetchTickets();
      }
    } catch (e) {
      console.error('Reply failed:', e);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-10 pb-24">
      {/* Title */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/60 border border-cyan-800/80 text-cyan-300 text-xs font-mono font-bold">
          <HelpCircle className="w-3.5 h-3.5" />
          <span>ORVIX 24/7 SUPPORT CENTER</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-black text-white">{t('supportTitle')}</h1>
        <p className="text-slate-400 text-sm max-w-xl mx-auto">{t('supportSubtitle')}</p>
      </div>

      {/* 3 Support Channel Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* WhatsApp */}
        <div className="p-6 rounded-3xl bg-[#0b1120] border border-slate-800 hover:border-emerald-500/40 transition space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
            <MessageCircle className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">{t('whatsappSupport')}</h3>
            <p className="text-xs text-slate-400 mt-1">Direct instant chat & project inquiries</p>
            <p className="text-sm font-mono text-emerald-400 font-bold mt-2">{channels.whatsapp}</p>
          </div>
          <div className="pt-2 flex gap-2">
            <a
              href={`https://wa.me/88${channels.whatsapp}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 py-2 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs text-center transition flex items-center justify-center gap-1.5"
            >
              <span>Message</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <button
              onClick={() => copyToClipboard(channels.whatsapp, 'wa')}
              className="p-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-white transition"
              title="Copy number"
            >
              {copiedType === 'wa' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Email */}
        <div className="p-6 rounded-3xl bg-[#0b1120] border border-slate-800 hover:border-cyan-500/40 transition space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center">
            <Mail className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">{t('emailSupport')}</h3>
            <p className="text-xs text-slate-400 mt-1">Formal inquiries, quotes & partnerships</p>
            <p className="text-xs font-mono text-cyan-300 font-bold mt-2 truncate">{channels.email}</p>
          </div>
          <div className="pt-2 flex gap-2">
            <a
              href={`mailto:${channels.email}`}
              className="flex-1 py-2 px-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs text-center transition flex items-center justify-center gap-1.5"
            >
              <span>Email Us</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <button
              onClick={() => copyToClipboard(channels.email, 'email')}
              className="p-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-white transition"
              title="Copy email"
            >
              {copiedType === 'email' ? <Check className="w-4 h-4 text-cyan-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Telegram */}
        <div className="p-6 rounded-3xl bg-[#0b1120] border border-slate-800 hover:border-sky-500/40 transition space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-sky-500/10 text-sky-400 flex items-center justify-center">
            <Send className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">{t('telegramSupport')}</h3>
            <p className="text-xs text-slate-400 mt-1">Fast developer support & deployment help</p>
            <p className="text-xs font-mono text-sky-300 font-bold mt-2">@jubayerahamed8</p>
          </div>
          <div className="pt-2 flex gap-2">
            <a
              href={channels.telegram}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 py-2 px-3 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs text-center transition flex items-center justify-center gap-1.5"
            >
              <span>Telegram</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <button
              onClick={() => copyToClipboard(channels.telegram, 'tg')}
              className="p-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-white transition"
              title="Copy link"
            >
              {copiedType === 'tg' ? <Check className="w-4 h-4 text-sky-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Ticket Management Section */}
      <div className="bg-[#0b1120] border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 pb-4 border-b border-slate-800">
          <div>
            <h2 className="text-xl font-bold text-white">Support Tickets & Inquiries</h2>
            <p className="text-xs text-slate-400">Track and respond to your direct queries</p>
          </div>
          <button
            onClick={() => {
              if (!user) openAuthModal();
              else setShowNewTicketModal(true);
            }}
            className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition flex items-center gap-1.5 self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>{t('openTicket')}</span>
          </button>
        </div>

        {tickets.length === 0 ? (
          <div className="p-12 text-center text-slate-400 text-xs">
            No support tickets created yet. Feel free to open a ticket if you need any assistance!
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Ticket List (5 cols) */}
            <div className="lg:col-span-5 space-y-3">
              {tickets.map((tkt) => {
                const isSelected = selectedTicket?.id === tkt.id;
                return (
                  <div
                    key={tkt.id}
                    onClick={() => setSelectedTicket(tkt)}
                    className={`p-4 rounded-2xl border cursor-pointer transition ${
                      isSelected
                        ? 'bg-slate-900 border-cyan-500/60 shadow-lg'
                        : 'bg-slate-950/40 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-mono text-cyan-400 font-bold">#{tkt.ticketId}</span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        tkt.status === 'Answered' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-300'
                      }`}>
                        {tkt.status}
                      </span>
                    </div>
                    <h4 className="text-sm font-bold text-white mt-1 truncate">{tkt.subject}</h4>
                    <p className="text-[11px] text-slate-400 mt-1 line-clamp-1">{tkt.messages[0]?.message}</p>
                  </div>
                );
              })}
            </div>

            {/* Conversation Thread (7 cols) */}
            <div className="lg:col-span-7 bg-slate-950/80 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between min-h-[350px]">
              {selectedTicket ? (
                <div className="flex flex-col h-full justify-between space-y-4">
                  <div className="border-b border-slate-800 pb-3">
                    <div className="flex justify-between items-center">
                      <h3 className="text-base font-bold text-white">{selectedTicket.subject}</h3>
                      <span className="text-xs font-mono text-slate-500">#{selectedTicket.ticketId}</span>
                    </div>
                    <p className="text-xs text-slate-400 mt-1">Category: {selectedTicket.category}</p>
                  </div>

                  {/* Messages */}
                  <div className="flex-1 overflow-y-auto space-y-3 py-2 pr-1 max-h-[300px]">
                    {selectedTicket.messages.map((m) => (
                      <div
                        key={m.id}
                        className={`p-3.5 rounded-2xl text-xs max-w-[85%] ${
                          m.sender === 'admin'
                            ? 'bg-purple-950/40 border border-purple-500/30 text-purple-200 ml-auto'
                            : 'bg-slate-900 border border-slate-800 text-slate-200'
                        }`}
                      >
                        <div className="flex items-center gap-1.5 font-bold mb-1 text-[11px]">
                          {m.sender === 'admin' ? (
                            <ShieldCheck className="w-3.5 h-3.5 text-purple-400" />
                          ) : (
                            <User className="w-3.5 h-3.5 text-cyan-400" />
                          )}
                          <span>{m.senderName}</span>
                          <span className="text-[10px] text-slate-500 font-mono ml-auto">
                            {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <p className="leading-relaxed whitespace-pre-wrap">{m.message}</p>
                      </div>
                    ))}
                  </div>

                  {/* Send Reply */}
                  <form onSubmit={handleSendReply} className="pt-2 border-t border-slate-800 flex gap-2">
                    <input
                      type="text"
                      placeholder="Type your reply..."
                      value={replyText}
                      onChange={(e) => setReplyText(e.target.value)}
                      className="flex-1 px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition flex items-center gap-1"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Reply</span>
                    </button>
                  </form>
                </div>
              ) : (
                <div className="h-full flex items-center justify-center text-xs text-slate-500">
                  Select a ticket on the left to view the conversation.
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* New Ticket Modal */}
      {showNewTicketModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0b1120] border border-slate-800 rounded-3xl max-w-lg w-full p-6 space-y-4">
            <div className="flex justify-between items-center pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">{t('openTicket')}</h3>
              <button onClick={() => setShowNewTicketModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleCreateTicket} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">{t('ticketSubject')} *</label>
                <input
                  type="text"
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="e.g. Website upload error or bKash query"
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">{t('ticketCategory')} *</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs"
                >
                  <option value="Hosting">Hosting</option>
                  <option value="Marketplace">Marketplace</option>
                  <option value="Payment">bKash Payment</option>
                  <option value="Custom Request">Custom Request</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Related Order ID (Optional)</label>
                <input
                  type="text"
                  value={orderId}
                  onChange={(e) => setOrderId(e.target.value)}
                  placeholder="e.g. ORV-ORD-4920"
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-mono"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">{t('ticketMessage')} *</label>
                <textarea
                  required
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Please describe your issue in detail..."
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewTicketModal(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-900 text-slate-300 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex-1 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition"
                >
                  {submitting ? 'Submitting...' : 'Submit Ticket'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
