import React, { useState, useEffect } from 'react';
import {
  ShoppingBag,
  Search,
  Filter,
  Check,
  ExternalLink,
  Clock,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Tag,
  Code2,
  X,
  CreditCard
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext.js';
import { useAuth } from '../context/AuthContext.js';
import { MarketplaceProduct } from '../types/index.js';

interface MarketplacePageProps {
  onOrderProduct: (prod: MarketplaceProduct) => void;
  openAuthModal: () => void;
}

export const MarketplacePage: React.FC<MarketplacePageProps> = ({ onOrderProduct, openAuthModal }) => {
  const { t, language } = useLanguage();
  const { user } = useAuth();
  const [products, setProducts] = useState<MarketplaceProduct[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProductDetails, setSelectedProductDetails] = useState<MarketplaceProduct | null>(null);
  const [loading, setLoading] = useState(true);

  const categories = [
    'All',
    'Business Websites',
    'Portfolio Websites',
    'E-commerce Websites',
    'Landing Pages',
    'Educational Websites',
    'Web Applications',
    'Admin Panels and Dashboards',
    'Android App Development Services',
    'Custom Website Development',
  ];

  const fetchProducts = async () => {
    try {
      let url = '/api/marketplace/products';
      const params = new URLSearchParams();
      if (selectedCategory !== 'All') params.append('category', selectedCategory);
      if (searchQuery.trim()) params.append('search', searchQuery.trim());
      if (params.toString()) url += `?${params.toString()}`;

      const res = await fetch(url);
      const data = await res.json();
      setProducts(data.products || []);
    } catch (e) {
      console.error('Failed to load marketplace products:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, [selectedCategory, searchQuery]);

  const handleOrderClick = (prod: MarketplaceProduct) => {
    if (!user) {
      openAuthModal();
      return;
    }
    onOrderProduct(prod);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-10 pb-24">
      {/* Hero Banner */}
      <div className="relative rounded-3xl bg-gradient-to-r from-purple-950/60 via-slate-900 to-cyan-950/60 border border-slate-800 p-8 sm:p-12 overflow-hidden shadow-2xl">
        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 text-xs font-mono font-bold border border-purple-500/30">
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>ORVIX DIGITAL MARKETPLACE</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black text-white leading-tight">
            {t('marketplaceTitle')}
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            {t('marketplaceSubtitle')}
          </p>
        </div>

        {/* Search & Filter Bar */}
        <div className="mt-8 relative z-10 max-w-xl">
          <div className="relative">
            <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={t('searchPlaceholder')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3.5 rounded-2xl bg-slate-950/90 border border-slate-700/80 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-500 shadow-xl"
            />
          </div>
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {categories.map((cat) => {
          const isSelected = selectedCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                isSelected
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800 hover:border-slate-700'
              }`}
            >
              {cat === 'All' ? t('allCategories') : cat}
            </button>
          );
        })}
      </div>

      {/* Products Grid */}
      {products.length === 0 ? (
        <div className="p-16 text-center bg-slate-900/20 border border-slate-800 rounded-3xl space-y-3">
          <ShoppingBag className="w-12 h-12 text-slate-600 mx-auto" />
          <p className="text-slate-400 text-sm font-medium">
            {language === 'bn' ? 'কোনো প্রোডাক্ট পাওয়া যায়নি।' : 'No products found matching criteria.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((prod) => (
            <div
              key={prod.id}
              className="rounded-3xl bg-[#0b1120] border border-slate-800 hover:border-cyan-500/40 transition-all duration-300 flex flex-col justify-between overflow-hidden group shadow-xl"
            >
              {/* Product Image */}
              <div className="relative aspect-video bg-slate-950 overflow-hidden">
                <img
                  src={prod.imageUrl}
                  alt={prod.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-3 left-3 px-3 py-1 rounded-xl bg-black/80 backdrop-blur-md text-[11px] font-bold text-cyan-300 border border-cyan-500/30">
                  {prod.category}
                </div>
                {prod.deliveryTime && (
                  <div className="absolute bottom-3 right-3 px-2.5 py-1 rounded-xl bg-slate-950/80 backdrop-blur-md text-[10px] font-mono text-slate-300 flex items-center gap-1">
                    <Clock className="w-3 h-3 text-cyan-400" />
                    <span>{language === 'bn' ? prod.deliveryTimeBn : prod.deliveryTime}</span>
                  </div>
                )}
              </div>

              {/* Product Body */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <h3 className="text-lg font-bold text-white group-hover:text-cyan-300 transition">
                    {language === 'bn' ? prod.titleBn : prod.title}
                  </h3>
                  <p className="text-xs text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                    {language === 'bn' ? prod.shortDescBn : prod.shortDesc}
                  </p>

                  {/* Features list */}
                  <div className="mt-4 space-y-1.5">
                    {((language === 'bn' ? prod.featuresBn : prod.features) || []).slice(0, 3).map((f, i) => (
                      <div key={i} className="flex items-center gap-2 text-xs text-slate-300">
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span className="truncate">{f}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Pricing & CTA */}
                <div className="pt-4 border-t border-slate-800/80 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-mono text-slate-500 uppercase">Price in BDT</span>
                      <p className="text-2xl font-black text-pink-400">
                        ৳ {prod.priceBdt.toLocaleString()}
                      </p>
                    </div>

                    <button
                      onClick={() => setSelectedProductDetails(prod)}
                      className="text-xs font-semibold text-slate-400 hover:text-cyan-300 transition"
                    >
                      {t('viewDetails')} →
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    {prod.demoUrl ? (
                      <a
                        href={prod.demoUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-bold text-slate-300 text-center transition flex items-center justify-center gap-1.5"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>{t('liveDemo')}</span>
                      </a>
                    ) : (
                      <button
                        onClick={() => setSelectedProductDetails(prod)}
                        className="py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-bold text-slate-300 text-center transition"
                      >
                        {t('viewDetails')}
                      </button>
                    )}

                    <button
                      onClick={() => handleOrderClick(prod)}
                      className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-400 hover:to-purple-500 text-white text-xs font-black transition shadow-lg shadow-pink-500/20 flex items-center justify-center gap-1"
                    >
                      <CreditCard className="w-3.5 h-3.5" />
                      <span>{t('orderNow')}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Product Details Modal */}
      {selectedProductDetails && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-[#0b1120] border border-slate-800 rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative max-h-[90vh] overflow-y-auto space-y-6">
            <button
              onClick={() => setSelectedProductDetails(null)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-900 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Modal Image */}
            <div className="aspect-video rounded-2xl overflow-hidden bg-slate-950 border border-slate-800">
              <img
                src={selectedProductDetails.imageUrl}
                alt={selectedProductDetails.title}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Info */}
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider">
                    {selectedProductDetails.category}
                  </span>
                  <h2 className="text-2xl font-bold text-white mt-1">
                    {language === 'bn' ? selectedProductDetails.titleBn : selectedProductDetails.title}
                  </h2>
                </div>
                <div className="text-right">
                  <span className="text-2xl font-black text-pink-400">
                    ৳ {selectedProductDetails.priceBdt.toLocaleString()}
                  </span>
                </div>
              </div>

              <p className="text-sm text-slate-300 leading-relaxed">
                {language === 'bn' ? selectedProductDetails.fullDescBn : selectedProductDetails.fullDesc}
              </p>

              {/* Features List */}
              <div className="space-y-2 pt-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  {t('featuresTitle')}
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {((language === 'bn' ? selectedProductDetails.featuresBn : selectedProductDetails.features) || []).map((feat, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs text-slate-200">
                      <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Technologies */}
              {selectedProductDetails.techStack && (
                <div className="space-y-2 pt-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    {t('includedTech')}
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedProductDetails.techStack.map((tech, i) => (
                      <span key={i} className="px-3 py-1 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono text-cyan-300">
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Delivery and terms */}
              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 text-xs text-slate-400 space-y-1.5">
                <p>• Delivery: <strong>{language === 'bn' ? selectedProductDetails.deliveryTimeBn : selectedProductDetails.deliveryTime}</strong></p>
                <p>• Payment: <strong>bKash Manual Verification (01344495081)</strong></p>
                <p>• Support: 30 days installation and deployment guidance included.</p>
              </div>

              {/* Modal CTA */}
              <div className="pt-4 flex gap-3">
                <button
                  onClick={() => setSelectedProductDetails(null)}
                  className="flex-1 py-3 rounded-2xl bg-slate-900 text-slate-300 text-xs font-bold"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    const target = selectedProductDetails;
                    setSelectedProductDetails(null);
                    handleOrderClick(target);
                  }}
                  className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-pink-500 to-purple-600 text-white text-xs font-black shadow-lg shadow-pink-500/25 flex items-center justify-center gap-2"
                >
                  <CreditCard className="w-4 h-4" />
                  <span>{t('orderNow')} (৳ {selectedProductDetails.priceBdt.toLocaleString()})</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
